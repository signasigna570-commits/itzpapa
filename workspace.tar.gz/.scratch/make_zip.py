"""Сборка citlali-src-<hash>.zip: исходники без .git, моделей, бинарников и кэшей."""

from __future__ import annotations

import hashlib
import os
import sys
import zipfile

REV = sys.argv[1]
ROOT = os.path.join("citlali")
OUT = f"citlali-src-{REV}.zip"
EXCL_DIRS = {
    ".git",
    ".venv",
    "__pycache__",
    "models",
    "tools",
    ".eval",
    ".compare",
    ".pytest_cache",
    ".ruff_cache",
    "node_modules",
    "dist",
    "target",
    ".mypy_cache",
}

if os.path.exists(OUT):
    os.remove(OUT)
n = 0
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = [d for d in dirnames if d not in EXCL_DIRS]
        for f in sorted(filenames):
            full = os.path.join(dirpath, f)
            z.write(full, full.replace(os.sep, "/"))
            n += 1
print("entries:", n)
for p in (f"citlali-bundle-{REV}.bundle", OUT):
    data = open(p, "rb").read()
    print(os.path.basename(p), len(data), "bytes", hashlib.sha256(data).hexdigest().upper())
