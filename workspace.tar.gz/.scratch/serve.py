"""СЛУЖЕБНЫЙ ФАЙЛ ПЕСОЧНИЦЫ (не часть продукта).

Поднимает Core с фейковой моделью на 127.0.0.1:8799, чтобы прогнать
scripts/bench.py без llama-server. На целевой Windows-машине не нужен.
"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "citlali"
sys.path.insert(0, str(ROOT / "core"))
sys.path.insert(0, str(ROOT / "core" / "tests"))

from app.config import Config  # noqa: E402
from app.main import create_app  # noqa: E402
from conftest import FakeLLM  # noqa: E402

tmp = Path(tempfile.mkdtemp())
(tmp / "soul").mkdir()
(tmp / "soul" / "SOUL.md").write_text("# Ситлали\nЯ цундере.", encoding="utf-8")
os.environ["CITLALI_CONFIG"] = str(tmp / "cfg.toml")

cfg = Config.load(env=False)
cfg.paths.data_dir = str(tmp)
cfg.paths.soul_file = "soul/SOUL.md"
cfg.paths.db_file = "bench.db"

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        create_app(cfg, llm=FakeLLM(chunks=["Слово " * 30] * 3)),
        host="127.0.0.1",
        port=8799,
        log_level="error",
    )
