import json, threading, time
from http.server import BaseHTTPRequestHandler, HTTPServer

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        self.send_response(200); self.send_header("Content-Type","application/json"); self.end_headers()
        self.wfile.write(b'{"status":"ok"}')
    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0)); self.rfile.read(n)
        self.send_response(200); self.send_header("Content-Type","text/event-stream"); self.end_headers()
        def ev(e, d):
            self.wfile.write(f"event: {e}\ndata: {json.dumps(d)}\n\n".encode()); self.wfile.flush()
        ev("meta", {"session_id":"s","message_id":"m","model":"stub","ts":"now"})
        time.sleep(0.05)
        for i in range(5):
            ev("delta", {"text": f"слово{i} "})
            time.sleep(0.02)
        ev("done", {"stop_reason":"stop","prompt_tokens":10,"completion_tokens":5,"ttft_ms":50.0,"tokens_per_s":40.0,"truncated":False})
    def do_DELETE(self):
        self.send_response(200); self.end_headers()

HTTPServer(("127.0.0.1", 8799), H).serve_forever()
