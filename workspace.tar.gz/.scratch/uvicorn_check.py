import os, sys, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1] / "citlali"
sys.path.insert(0, str(ROOT / "core")); sys.path.insert(0, str(ROOT / "core" / "tests"))
d = Path(tempfile.mkdtemp()); (d / "soul").mkdir()
(d / "soul" / "SOUL.md").write_text("# Ситлали\nЯ цундере.", encoding="utf-8")
os.environ["CITLALI_CONFIG"] = str(d / "cfg.toml")
from app.config import Config
import app.main as m
from conftest import FakeLLM
cfg = Config.load(env=False)
cfg.paths.data_dir = str(d); cfg.paths.soul_file = "soul/SOUL.md"; cfg.paths.db_file = "u.db"
m._app = m.create_app(cfg, llm=FakeLLM(chunks=["Ну ", "привет. ", "Чего хотел?"]))
