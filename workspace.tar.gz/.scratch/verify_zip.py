"""СЛУЖЕБНЫЙ ФАЙЛ ПЕСОЧНИЦЫ: проверка содержимого итогового архива."""

import collections
import zipfile
from pathlib import Path

HOME = Path(__file__).resolve().parents[1]
target = HOME / "citlali-v0.1-stage0-1.zip"

with zipfile.ZipFile(target) as z:
    names = [n for n in z.namelist() if not n.endswith("/")]
    print("архив:", target.name, f"{target.stat().st_size / 1024:.0f} KB")
    print("файлов:", len(names))
    by_dir = collections.Counter(n.split("/")[0] for n in names)
    for d, c in sorted(by_dir.items()):
        print(f"  {d:12s} {c}")
    print()
    for n in sorted(names):
        print("   ", n)
