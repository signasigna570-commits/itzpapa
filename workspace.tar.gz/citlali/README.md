# Citlali

Локальный офлайн-ассистент для Windows с устойчивым характером (цундере) и управлением ПК через инструменты.
Модель работает на вашей видеокарте, данные не покидают машину. Облаков нет — физически.

> **Статус:** Этап 1 (ядро: чат, SSE, память-заготовка, роутер) реализован и покрыт тестами —
> **517 passed** на Windows (в песочнице исполнителя с PowerShell — 516 passed + 1 skipped,
> без PowerShell — 493 + 24 skipped).
> Этап 0 закрыт по модели: **рабочая модель — Qwen3.5-9B Q4_K_M** (решение оператора 19.10.2026, A-19),
> GGUF живут в `C:\citlali-models` вне репозитория; NFR замерены трижды (design §9). Из Этапа 0 осталась установка Rust (T0.2).
> Этапы 2–5 — не начаты. План: `docs/tasks.md`.

## Что это

| | |
|---|---|
| Характер | `soul/SOUL.md` — статическое ядро личности, подставляется в системный промпт |
| Мозг | Qwen3.5-9B Q4_K_M через `llama-server` (llama.cpp b11711, CUDA 12.4, RTX 3060 12 GB) |
| Ядро | Python 3.11 + FastAPI, SSE-стриминг, SQLite (сообщения / факты / журнал действий) |
| Оболочка | Tauri v2 + React/TS (Этап 2), sidecar-процессы и watchdog на стороне Rust |
| Агент | ReAct ≤ 5 шагов, 6 инструментов, серверный HITL-гейт на опасные действия |
| Данные | только `%APPDATA%\Citlali` |

## Документация (читать по порядку)

1. **`docs/spec.md`** — техническое задание + раздел 12 «Поправки» (нормативны, A-1…A-32).
2. **`AGENTS.md`** — как мы работаем: процесс, git, стиль, безопасность, формат ответов.
3. **`docs/design.md`** — архитектура, схема БД, SSE-протокол, HITL, фиксации версий.
4. **`docs/tasks.md`** — декомпозиция на атомы (один атом = один коммит).
5. **`docs/acceptance.md`** — 7 приёмочных тестов v1.0 с командами и критериями.

## Как обновлять проект, не теряя модели

`models\` (19.7 GB) и `tools\llama\` (650 MB) **не входят ни в один архив** — они слишком
большие. Поэтому удалять папку проекта ради обновления нельзя: потеряете и то и другое.

Правильный способ — git. **Однократная настройка** (положите свежий bundle
в `C:\dev` и выполните в уже существующей папке проекта; `<хэш>` в имени —
ревизия, которую сообщил исполнитель, например `4677bd2`):

```bat
cd /d C:\dev\citlali
git init -b main
git remote add origin C:\dev\citlali-bundle-<хэш>.bundle
git fetch origin
git reset --hard origin/main
```

`git reset --hard` заменяет только файлы репозитория. `models\`, `tools\`, `core\.venv`,
`.compare\` и `.eval\` перечислены в `.gitignore`, поэтому git их не видит и не трогает
(проверяется автотестом `test_gitignore_protects_everything_expensive`).

**Каждое следующее обновление** — две команды, модели не страдают:

```bat
git fetch C:\dev\citlali-bundle-<хэш>.bundle main
git reset --hard FETCH_HEAD
git log --oneline -1        :: хэш обязан совпасть с хэшем В ИМЕНИ ФАЙЛА bundle
```

> **Важно:** имя bundle содержит ревизию (`citlali-bundle-4677bd2.bundle`),
> и хэш после `git reset --hard` обязан совпасть с именем файла. Так подлог
> виден сразу: трижды обновление съезжало на старую ревизию, потому что
> браузер при повторной загрузке сохраняет файл как «… (1).bundle», а
> `git fetch` запускали от старого одноимённого файла в `C:\dev`.
> Правило: скачали новый bundle — удалите из `C:\dev` все старые
> `citlali-*.bundle` и запускайте fetch от файла с НОВЫМ хэшем в имени.

### Где живут модели (A-26)

Модели (≈20 GB) трижды пропадали вместе с папкой проекта при её пересоздании.
Чтобы это не повторялось, держите GGUF **вне** `C:\dev\citlali`:

```bat
setx CITLALI_MODELS_DIR C:\citlali-models     :: один раз; действует с НОВОГО терминала
mkdir C:\citlali-models
```

После этого `download_models.cmd`, `pick_model.cmd`, `eval_character.cmd`,
`03_compare_models.cmd`, `run_llama.cmd` и `run_core.cmd` работают с этим
каталогом автоматически. Если модели уже скачаны в `models\` — перенесите
их одной командой (перенос внутри одного диска мгновенный, размеры после
него сверяются побайтово с `bootstrap.json`):

```bat
scripts\move_models.cmd
scripts\pick_model.cmd qwen3.5-9b
```

Если беда уже случилась — модели не пропали, они в Корзине:

```bat
scripts\restore_models.cmd dry   :: показать, что найдено в Корзине
scripts\restore_models.cmd       :: вернуть в models\ без повторной закачки
scripts\restore_llama.cmd        :: вернуть бинарники llama.cpp (~650 MB)
```

## Быстрый старт (Windows, для оператора)

Все команды — из корня репозитория. Каждый шаг присылайте исполнителю целиком.

Если что-то сломалось или непонятно, что вообще стоит и на месте ли модели — начните
с самодиагностики: она ничего не меняет, а печатает состояние и точную команду лечения.

```bat
scripts\doctor.cmd
```

```bat
:: 1. Проверить окружение (что стоит, чего не хватает, сколько места и VRAM)
scripts\00_check_env.cmd

:: 2. Скачать llama.cpp (build b11711, CUDA 12.4) и все три модели (~19.7 GB)
::    Уже скачанное НЕ перекачивается: сверка по точным байтам из bootstrap.json (A-27).
::    Модели ищутся и в CITLALI_MODELS_DIR, и в models\ — куда кладутся новые.
scripts\01_bootstrap.cmd
:: только рабочая модель / весь список / перекачать полный файл:
scripts\01_bootstrap.cmd -Only qwen3.5-9b
scripts\01_bootstrap.cmd -All
scripts\01_bootstrap.cmd -Force
:: только бинарники llama.cpp (из кэша %TEMP%\citlali-dl — около минуты):
scripts\01_bootstrap.cmd -SkipModel
:: если HF API отдаёт 401/308 — аварийный путь без API, только curl:
scripts\download_models.cmd

:: 3. Проверить, что модель грузится в VRAM и отвечает
scripts\02_verify_llama.cmd

:: 4a. Сравнить три модели по железу → сводная таблица
scripts\03_compare_models.cmd

:: 4b. Сравнить их же по характеру (10 провокаций из критерия №3)
scripts\eval_character.cmd
```

Дальше — dev-режим ядра (Python 3.11 или 3.12, x64):

```bat
:: 5. Подготовить окружение ядра: core\.venv + зависимости (делается один раз)
scripts\setup_python.cmd

:: 5b. Тесты ядра (на Windows ожидается: pytest=0 lint=0 format=0, 517 passed
::     часть тестов гоняет настоящий PowerShell — проверяют синтаксис .ps1 и поиск моделей;
::     прогон начинается с проверки свободного места — A-32: на полном диске будет одна
::     строка [FAIL] с командами лечения, а не сотня падений с OSError 28)
scripts\run_tests.cmd

:: 6. Терминал A: локальная модель (путь берётся из config.toml → ждём строку Qwen3.5-9B-Q4_K_M.gguf)
scripts\run_llama.cmd

:: 7. Терминал B: ядро (первый запуск создаст .venv и %APPDATA%\Citlali\config.toml)
scripts\run_core.cmd

:: 8. Терминал C: живость и метрики  (команды — из cmd.exe, не из PowerShell)
::    Терминалы A и B не закрывать: Ctrl+C в них останавливает модель/ядро.
curl.exe http://127.0.0.1:8787/healthz
scripts\bench.cmd --runs 7
```

`bench.cmd` сам проверяет оба порта до первого прогона и называет конкретное окно,
которое не запущено (A-27). Результаты складывает в `.bench\latest.json` — этот
каталог в git не попадает, но именно из него берётся NFR-таблица в `docs/design.md` §9.

Факт замера 19.10.2026 (Qwen3.5-9B, контекст 8192, `-ngl 99`): TTFT медиана **113 ms**
(p95 1386 ms — первый запрос платит за `prompt eval` всего системного промпта),
**44.7 tok/s**, stop=stop 7/7, Core **104.9 MB** при лимите 1024 MB. Все пороги
`docs/spec.md` §6 перекрыты.

Проверить стриминг из консоли без UI:

```bat
curl.exe -N -X POST http://127.0.0.1:8787/v1/chat -H "Content-Type: application/json" ^
     -d "{\"message\":\"привет\"}"
```

Ожидаются SSE-события `meta` → `route` → `status` → `delta`… → `done`.

> В PowerShell `curl` — это псевдоним `Invoke-WebRequest`, поэтому пишите `curl.exe`.
> Эквивалент на PowerShell: `Invoke-RestMethod http://127.0.0.1:8787/healthz`.

## Структура

```
citlali/
├─ AGENTS.md                 конвенции исполнителя
├─ docs/                     spec, design, tasks, acceptance
├─ soul/SOUL.md              ядро личности (≤ 4000 знаков)
├─ core/
│  ├─ app/                   config, prompt, llm, db, router, protocol, main
│  ├─ tests/                 517 тестов, без сети и без модели
│  ├─ config.default.toml    шаблон конфига (копируется в %APPDATA%\Citlali)
│  └─ requirements*.txt
├─ app/                      Tauri v2: src-ui (React), src-tauri (Rust) — Этап 2
├─ scripts/                  check_env / bootstrap / verify / compare_models / setup_python / run / bench
├─ tools/llama/              бинарники llama.cpp (вне git)
└─ models/                   GGUF (вне git)
```

## Разработка (ядро)

```bash
cd core
python -m venv .venv && .venv\Scripts\activate
pip install -r requirements-dev.txt
python -m pytest                         # 517 passed (счёт без -q: его задаёт addopts)
python -m ruff check app tests           # All checks passed
python -m ruff format --check app tests
```

Тесты намеренно не требуют ни сети, ни llama-server: модель подменяется `FakeLLM`,
HTTP — `httpx.MockTransport`, данные — временным каталогом.

## Безопасность (коротко)

- Слушаем только `127.0.0.1`; UI→Core защищён токеном (A-12).
- Опасные действия гейтятся **в ядре**, а не в UI: без `POST /v1/confirm` исполнение не начнётся (A-5).
- Каждое действие пишется в журнал **до** исполнения (AGENTS.md §5).
- Инструмента удаления файлов в v1 нет вообще (A-4).
- Whitelist-папки проверяются после `realpath` (защита от `..`, symlink, junction).
- Никаких внешних сетевых вызовов, кроме `open_url` по явной команде пользователя.

## Лицензия

Личный проект. Модель Qwen3 распространяется на условиях её собственной лицензии — проверьте перед использованием.
