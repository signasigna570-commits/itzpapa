"""Citlali Core — локальное офлайн-ядро ассистента (Python 3.11 + FastAPI)."""

__version__ = "0.1.0"
__all__ = ["__version__"]
