"""Конфигурация Citlali Core.

Источники (по возрастанию приоритета):
  1. значения по умолчанию (схема ниже);
  2. TOML-файл (``%APPDATA%/Citlali/config.toml`` или ``CITLALI_CONFIG``);
  3. переменные окружения ``CITLALI_<SECTION>__<KEY>`` (``__`` — разделитель).

Все строковые пути проходят через :func:`expand_path`: ``%VAR%``/``$VAR``
раскрываются, ``~`` раскрывается, результат нормализуется. Это позволяет
вынести ``models/`` на другой диск (поправка A-3 к ТЗ).
"""

from __future__ import annotations

import logging
import os
import re
import tomllib
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field, ValidationError, field_validator

log = logging.getLogger("citlali.config")

CONFIG_SCHEMA_VERSION = 1

# Ключи, значения которых трактуются как пути (для expand_path).
_PATH_KEYS: dict[str, frozenset[str]] = {
    "paths": frozenset({"data_dir", "soul_file", "model_file", "llama_dir", "log_dir"}),
}


class CoreCfg(BaseModel):
    host: str = "127.0.0.1"  # только loopback (A-12)
    port: int = 8787
    api_token: str | None = None  # None = dev-режим без авторизации
    log_level: str = "INFO"


def default_data_dir() -> str:
    """Каталог данных по умолчанию: ``%APPDATA%/Citlali`` на Windows, XDG — на прочем.

    Вычисляется **в рантайме на машине запуска** — и это принципиально.
    ``config.default.toml`` намеренно НЕ содержит ``data_dir``: однажды
    сгенерированный в Linux-песочнице шаблон унёс ``~/.local/share/Citlali``
    на Windows, и ядро создало базу в ``C:\\Users\\...\\.local\\share\\Citlali``
    вместо ``%APPDATA%``. Пустое значение = «возьми дефолт этой ОС» (A-20).
    """
    if os.name == "nt":
        return r"%APPDATA%\Citlali"
    return "~/.local/share/Citlali"


class PathsCfg(BaseModel):
    # Пустая строка — не «текущий каталог», а «дефолт текущей ОС».
    # Значение намеренно не попадает в config.default.toml (см. default_data_dir).
    data_dir: str = ""

    @field_validator("data_dir", mode="after")
    @classmethod
    def _drop_foreign_data_dir(cls, value: str) -> str:
        """Отбросить значение, заведомо принадлежащее другой ОС (A-20).

        Реальный случай: ``config.default.toml``, сгенерированный в Linux,
        унёс ``~/.local/share/Citlali`` на Windows, и база легла в
        ``C:\\Users\\...\\.local\\share\\Citlali``. Молча терпеть нельзя,
        падать тоже — поэтому сбрасываем в «дефолт этой ОС» и логируем.
        """
        raw = value.strip()
        if not raw:
            return ""
        foreign = raw.startswith("~") or raw.startswith("/")
        if os.name == "nt" and foreign:
            log.warning(
                "paths.data_dir = %r не является путём Windows — использую %%APPDATA%%\\Citlali",
                value,
            )
            return ""
        if os.name != "nt" and re.match(r"^[A-Za-z]:[\\/]", raw):
            log.warning("paths.data_dir = %r — путь Windows на не-Windows ОС, беру дефолт", value)
            return ""
        return value

    soul_file: str = "soul/SOUL.md"
    db_file: str = "citlali.db"
    log_dir: str = "logs"
    model_file: str = "models/Qwen3-14B-Q4_K_M.gguf"
    llama_dir: str = "tools/llama"


class LlamaCfg(BaseModel):
    base_url: str = "http://127.0.0.1:8080"
    host: str = "127.0.0.1"
    port: int = 8080
    model_alias: str = "citlali"
    ctx_size: int = 8192
    ngl: int = 99
    threads: int = 8
    flash_attn: bool = True
    parallel: int = 2
    cache_reuse: int = 256
    startup_timeout_s: int = 120


class LlmCfg(BaseModel):
    temperature: float = 0.7
    max_tokens: int = 1024
    request_timeout_s: int = 180
    thinking: bool = False  # /no_think в системном промпте (A-11)
    tool_fallback_grammar: bool = True


class MemoryCfg(BaseModel):
    history_max_messages: int = 20
    history_token_budget: int = 3200
    facts_max: int = 12
    chars_per_token: float = 3.2
    summary_enabled: bool = True
    fact_extraction_enabled: bool = True


class ToolsCfg(BaseModel):
    enabled: bool = True
    max_steps: int = 5
    confirm_timeout_s: int = 120
    powershell_timeout_s: int = 20
    tool_result_max_chars: int = 2000
    ps_whitelist: list[str] = Field(
        default_factory=lambda: [
            "Get-Date",
            "Get-Volume",
            "Get-Process",
            "Get-Service",
            "Get-ChildItem",
            "Get-Item",
            "Get-Content",
            "Get-ComputerInfo",
            "Get-CimInstance",
            "Get-NetAdapter",
            "Get-Disk",
            "Test-Path",
            "nvidia-smi",
        ]
    )
    url_whitelist: list[str] = Field(
        default_factory=lambda: [
            "youtube.com",
            "google.com",
            "github.com",
            "huggingface.co",
            "localhost",
        ]
    )
    file_whitelist: list[str] = Field(
        default_factory=lambda: [r"%USERPROFILE%\Documents", r"%APPDATA%\Citlali\workspace"]
    )
    app_list: dict[str, str] = Field(
        default_factory=lambda: {
            "блокнот": "notepad.exe",
            "notepad": "notepad.exe",
            "калькулятор": "calc.exe",
            "calculator": "calc.exe",
            "проводник": "explorer.exe",
            "explorer": "explorer.exe",
            "paint": "mspaint.exe",
            "cmd": "cmd.exe",
            "powershell": "powershell.exe",
            "терминал": "wt.exe",
        }
    )


class RouterCfg(BaseModel):
    mode: str = "regex"  # regex | llm (llm — v2)
    command_threshold: int = 1


class WatchdogCfg(BaseModel):
    interval_s: int = 5
    max_failures: int = 3
    max_restarts_per_10min: int = 3


class Config(BaseModel):
    """Корневая конфигурация. Поля вне схемы игнорируются (forward-compat)."""

    model_config = {"extra": "ignore"}

    schema_version: int = CONFIG_SCHEMA_VERSION
    core: CoreCfg = Field(default_factory=CoreCfg)
    paths: PathsCfg = Field(default_factory=PathsCfg)
    llama: LlamaCfg = Field(default_factory=LlamaCfg)
    llm: LlmCfg = Field(default_factory=LlmCfg)
    memory: MemoryCfg = Field(default_factory=MemoryCfg)
    tools: ToolsCfg = Field(default_factory=ToolsCfg)
    router: RouterCfg = Field(default_factory=RouterCfg)
    watchdog: WatchdogCfg = Field(default_factory=WatchdogCfg)

    # ---------------------------------------------------------------- пути

    @property
    def app_dir(self) -> Path:
        """Каталог данных приложения: ``%APPDATA%/Citlali`` на Windows, XDG — на прочем.

        Пустое или неизвестное значение ``paths.data_dir`` означает «дефолт этой ОС»,
        а не «текущий каталог» — иначе данные уезжают в непредсказуемое место (A-20).
        """
        raw = self.paths.data_dir.strip()
        if not raw:
            return expand_path(default_data_dir())
        try:
            return expand_path(raw)
        except ConfigError:
            log.warning(
                "paths.data_dir = %r не раскрылся (нет такой переменной окружения) — "
                "беру дефолт этой ОС",
                raw,
            )
            return expand_path(default_data_dir())

    @property
    def db_path(self) -> Path:
        return self._resolve(self.paths.db_file)

    @property
    def soul_path(self) -> Path:
        return self._resolve(self.paths.soul_file)

    @property
    def log_path(self) -> Path:
        return self._resolve(self.paths.log_dir)

    @property
    def model_path(self) -> Path:
        return self._resolve(self.paths.model_file)

    @property
    def llama_dir_path(self) -> Path:
        return self._resolve(self.paths.llama_dir)

    def _resolve(self, raw: str) -> Path:
        """Абсолютный путь; относительные пути считаются от ``app_dir``.

        Windows-путь с буквой диска (``C:\\...``) считается абсолютным на любой ОС:
        конфиг, созданный на Windows, должны уметь читать тесты и в Linux-CI,
        иначе ``app_dir / "C:\\x"`` молча склеится в бессмыслицу.
        """
        p = expand_path(raw)
        if p.is_absolute() or _is_windows_absolute(str(p)):
            return p
        return self.app_dir / p

    # -------------------------------------------------------------- загрузка

    @classmethod
    def load(cls, path: str | os.PathLike[str] | None = None, *, env: bool = True) -> Config:
        cfg_file = Path(path) if path else default_config_path()
        data: dict[str, Any] = {}
        if cfg_file and cfg_file.is_file():
            with open(cfg_file, "rb") as fh:
                data = tomllib.load(fh)
        merged = _deep_merge(defaults_dict(), data)
        if env:
            merged = _apply_env(merged)
        try:
            return cls.model_validate(merged)
        except ValidationError as exc:  # pragma: no cover - защитная ветка
            raise ConfigError(f"Некорректный конфиг {cfg_file}: {exc}") from exc


class ConfigError(RuntimeError):
    """Ошибка чтения/валидации конфигурации."""


# ------------------------------------------------------------------ helpers


_WINVAR_RE = re.compile(r"%([A-Za-z_][A-Za-z0-9_]*)%")


_WIN_ABS_RE = re.compile(r"^[A-Za-z]:[\\/]")
_UNEXPANDED_RE = re.compile(r"%[A-Za-z_][A-Za-z0-9_]*%")


def _is_windows_absolute(text: str) -> bool:
    """``C:\\path`` или ``C:/path`` — абсолютный путь Windows (важно на любой ОС)."""
    return bool(_WIN_ABS_RE.match(text))


def expand_path(raw: str | os.PathLike[str]) -> Path:
    """Раскрыть переменные окружения и ``~``, нормализовать путь.

    Поддерживаются и ``%VAR%`` (Windows-стиль, работает на любой ОС —
    конфиг переносим), и ``$VAR``. Намеренно НЕ делает ``realpath``:
    симлинки разрешаются в момент проверки whitelist (вопрос безопасности).
    Неизвестная переменная остаётся как есть (видна в логе пути).
    """
    text = os.fspath(raw)
    text = _WINVAR_RE.sub(lambda m: os.environ.get(m.group(1), m.group(0)), text)
    text = os.path.expandvars(text)
    if text.startswith("~"):
        home = os.path.expanduser("~")
        if home and not home.startswith("~"):
            text = home + text[1:]
    leftovers = _UNEXPANDED_RE.findall(text)
    if leftovers:
        # Молча создать каталог с именем "%APPDATA%\Citlali" — худший из исходов:
        # данные уедут не туда, и найти их будет почти невозможно.
        raise ConfigError(
            f"В пути не раскрыта переменная окружения {leftovers[0]}: {text!r}. "
            f"Переменная не задана в этой ОС или опечатка в config.toml."
        )
    if os.name == "nt":
        text = normalize_windows_separators(text)
    return Path(os.path.normpath(os.path.expanduser(text)))


def normalize_windows_separators(text: str) -> str:
    """Привести Windows-путь к обратным слэшам.

    Отдельная чистая функция — чтобы её можно было тестировать на Linux:
    ``monkeypatch.setattr(os, "name", "nt")`` ломает сам pytest (pathlib
    отказывается создавать WindowsPath на чужой ОС).

    Конфиг хранит пути прямыми слэшами (``C:/dev/...``): тогда в TOML не нужно
    экранирование, и сырые читатели конфига (`.cmd`) получают валидный путь.
    """
    if _WIN_ABS_RE.match(text):
        return text.replace("/", "\\")
    return text


def defaults_dict() -> dict[str, Any]:
    """Значения по умолчанию в виде dict (для слияния с TOML)."""
    return Config.model_construct().model_dump()


def default_config_path() -> Path:
    """``%CITLALI_CONFIG%`` или ``<каталог данных>/config.toml``.

    Каталог данных берётся из :func:`default_data_dir`, поэтому на не-Windows
    (dev/CI) не пытаемся читать ``%APPDATA%``, которого там нет.
    """
    env_path = os.environ.get("CITLALI_CONFIG")
    if env_path:
        return expand_path(env_path)
    return expand_path(default_data_dir()) / "config.toml"


def to_toml(cfg: Config) -> str:
    """Сериализация конфига в TOML (для создания файла при первом старте)."""
    lines: list[str] = [
        "# Citlali — конфигурация. Создаётся из core/config.default.toml.",
        "# Пути поддерживают %APPDATA%, %USERPROFILE% и ~ — можно вынести models/ на другой диск.",
        "# data_dir намеренно отсутствует: каталог данных выбирается по ОС в рантайме",
        '# (Windows: %APPDATA%\\Citlali). Перенос данных: data_dir = "D:/Citlali".',
        "",
    ]

    def emit(table: str, values: dict[str, Any]) -> None:
        if lines and lines[-1] != "":
            lines.append("")
        lines.append(f"[{table}]")
        for key, val in values.items():
            # None = «не задано»; "" у data_dir = «дефолт этой ОС».
            # Ни то ни другое в шаблон не пишем: config.default.toml обязан
            # оставаться межплатформенным (A-20).
            if val is None:
                continue
            if key == "data_dir" and not str(val).strip():
                continue
            lines.append(f"{key} = {_toml_value(val)}")
        lines.append("")

    for name, value in cfg.model_dump().items():
        if isinstance(value, dict):
            emit(name, value)
        elif value is not None:
            lines.append(f"{name} = {_toml_value(value)}")
    return "\n".join(lines)


def _toml_value(val: Any) -> str:
    if isinstance(val, bool):
        return "true" if val else "false"
    if isinstance(val, (int, float)):
        return str(val)
    if isinstance(val, dict):  # app_list
        inner = ", ".join(f"{_toml_value(k)} = {_toml_value(v)}" for k, v in val.items())
        return "{ " + inner + " }"
    if isinstance(val, list):
        return "[" + ", ".join(_toml_value(v) for v in val) + "]"
    if val is None:
        return '""'
    text = str(val).replace("\\", "\\\\").replace('"', '\\"')
    return f'"{text}"'


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    out = dict(base)
    for key, val in override.items():
        if isinstance(val, dict) and isinstance(out.get(key), dict):
            out[key] = _deep_merge(out[key], val)
        else:
            out[key] = val
    return out


def _apply_env(data: dict[str, Any]) -> dict[str, Any]:
    """``CITLALI_LLAMA__PORT=8081`` → ``data['llama']['port'] = '8081'``.

    Типы приводятся pydantic-валидацией, поэтому значения кладём как есть
    (строки), кроме случаев, когда ключ уже имеет числовой/булев тип по умолчанию.
    """
    prefix = "CITLALI_"
    for env_key, env_val in os.environ.items():
        if not env_key.startswith(prefix) or env_key == "CITLALI_CONFIG":
            continue
        parts = env_key[len(prefix) :].lower().split("__")
        if len(parts) != 2:
            continue
        section, key = parts
        if section not in data or not isinstance(data[section], dict):
            continue
        data[section][key] = _coerce(data[section].get(key), env_val)
    return data


def _coerce(current: Any, raw: str) -> Any:
    if isinstance(current, bool):
        return raw.strip().lower() in {"1", "true", "yes", "on"}
    if isinstance(current, int):
        try:
            return int(raw)
        except ValueError:
            return raw
    if isinstance(current, float):
        try:
            return float(raw)
        except ValueError:
            return raw
    return raw
