"""SQLite-слой Citlali: sessions, messages, facts, actions (design.md §2).

Пишем через :mod:`aiosqlite`, один экземпляр :class:`DB` на процесс.
Журнал ``actions`` создаётся **до** исполнения инструмента (статус ``pending``)
и обновляется после — это требование AGENTS.md §5 и поправки A-5.
"""

from __future__ import annotations

import json
import logging
import uuid
from collections.abc import Mapping, Sequence
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import aiosqlite

from .prompt import Fact, Msg

log = logging.getLogger("citlali.db")

SCHEMA_VERSION = 1

_SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
  id          TEXT PRIMARY KEY,
  started_at  TEXT NOT NULL,
  ended_at    TEXT,
  summary     TEXT
);

CREATE TABLE IF NOT EXISTS messages (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id  TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  role        TEXT NOT NULL CHECK (role IN ('user','assistant','system','tool')),
  content     TEXT NOT NULL,
  tokens      INTEGER,
  created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id, id);

CREATE TABLE IF NOT EXISTS facts (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  subject     TEXT NOT NULL DEFAULT 'user',
  key         TEXT NOT NULL,
  value       TEXT NOT NULL,
  source      TEXT NOT NULL DEFAULT 'user_explicit',
  confidence  REAL NOT NULL DEFAULT 1.0,
  created_at  TEXT NOT NULL,
  updated_at  TEXT NOT NULL,
  UNIQUE(subject, key)
);

CREATE TABLE IF NOT EXISTS actions (
  id          TEXT PRIMARY KEY,
  session_id  TEXT,
  ts          TEXT NOT NULL,
  tool        TEXT NOT NULL,
  args_json   TEXT NOT NULL,
  risk        TEXT NOT NULL CHECK (risk IN ('safe','whitelisted','dangerous')),
  status      TEXT NOT NULL CHECK (status IN
                ('pending','approved','denied','timeout','ok','error','refused')),
  reason      TEXT,
  result      TEXT,
  error       TEXT,
  duration_ms INTEGER
);
CREATE INDEX IF NOT EXISTS idx_actions_ts ON actions(ts);
"""


def utcnow() -> str:
    """ISO-8601 UTC с точностью до секунд (лексикографически сортируем)."""
    return datetime.now(UTC).replace(microsecond=0).isoformat()


def new_id() -> str:
    return str(uuid.uuid4())


class DB:
    def __init__(self, path: str | Path = ":memory:") -> None:
        self.path = str(path)
        self._conn: aiosqlite.Connection | None = None

    # ---------------------------------------------------------------- life

    async def connect(self) -> None:
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = await aiosqlite.connect(self.path)
        self._conn.row_factory = aiosqlite.Row
        await self._conn.execute("PRAGMA foreign_keys = ON")
        await self._conn.execute("PRAGMA journal_mode = WAL")
        await self._conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
        await self._conn.executescript(_SCHEMA)
        await self._conn.commit()

    async def close(self) -> None:
        if self._conn is not None:
            await self._conn.close()
            self._conn = None

    @property
    def conn(self) -> aiosqlite.Connection:
        if self._conn is None:
            raise RuntimeError("DB не подключена: сначала await db.connect()")
        return self._conn

    # ------------------------------------------------------------ sessions

    async def create_session(self, session_id: str | None = None) -> str:
        sid = session_id or new_id()
        await self.conn.execute(
            "INSERT INTO sessions (id, started_at) VALUES (?, ?)", (sid, utcnow())
        )
        await self.conn.commit()
        return sid

    async def ensure_session(self, session_id: str | None) -> str:
        """Вернуть существующую сессию или создать новую (идемпотентно)."""
        if session_id:
            async with self.conn.execute(
                "SELECT id FROM sessions WHERE id = ?", (session_id,)
            ) as cur:
                if await cur.fetchone():
                    return session_id
        return await self.create_session(session_id)

    async def end_session(self, session_id: str, summary: str | None = None) -> None:
        await self.conn.execute(
            "UPDATE sessions SET ended_at = ?, summary = COALESCE(?, summary) WHERE id = ?",
            (utcnow(), summary, session_id),
        )
        await self.conn.commit()

    async def get_session(self, session_id: str) -> dict[str, Any] | None:
        async with self.conn.execute("SELECT * FROM sessions WHERE id = ?", (session_id,)) as cur:
            row = await cur.fetchone()
        return dict(row) if row else None

    async def recent_summaries(self, limit: int = 3, *, exclude: str | None = None) -> list[str]:
        query = "SELECT id, summary FROM sessions WHERE summary IS NOT NULL AND summary != ''"
        params: list[Any] = []
        if exclude:
            query += " AND id != ?"
            params.append(exclude)
        query += " ORDER BY started_at DESC LIMIT ?"
        params.append(limit)
        async with self.conn.execute(query, params) as cur:
            rows = await cur.fetchall()
        return [r["summary"] for r in reversed(rows)]

    # ------------------------------------------------------------ messages

    async def append_message(
        self, session_id: str, role: str, content: str, *, tokens: int | None = None
    ) -> int:
        cur = await self.conn.execute(
            "INSERT INTO messages (session_id, role, content, tokens, created_at)"
            " VALUES (?, ?, ?, ?, ?)",
            (session_id, role, content, tokens, utcnow()),
        )
        await self.conn.commit()
        return int(cur.lastrowid or 0)

    async def get_messages(self, session_id: str, limit: int | None = None) -> list[dict[str, Any]]:
        """Сообщения сессии в хронологическом порядке (``limit`` — последние N)."""
        cols = "id, session_id, role, content, tokens, created_at"
        if limit is None:
            query = f"SELECT {cols} FROM messages WHERE session_id = ? ORDER BY id"
            params: list[Any] = [session_id]
        else:
            query = (
                f"SELECT {cols} FROM ("
                "  SELECT * FROM messages WHERE session_id = ? ORDER BY id DESC LIMIT ?"
                ") t ORDER BY t.id"
            )
            params = [session_id, limit]
        async with self.conn.execute(query, params) as cur:
            rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def history_for_prompt(
        self, session_id: str, *, exclude_last_user: bool = True
    ) -> list[Msg]:
        """История без текущего сообщения пользователя.

        Текущая реплика уже сохранена в БД к моменту сборки промпта,
        поэтому последний ``user``-блок исключается (иначе дубль).
        """
        rows = await self.get_messages(session_id)
        msgs = [Msg(role=r["role"], content=r["content"]) for r in rows]  # type: ignore[arg-type]
        if exclude_last_user and msgs and msgs[-1].role == "user":
            msgs.pop()
        return msgs

    async def delete_trailing_assistant(self, session_id: str) -> int:
        """Регенерация: убрать последний ответ ассистента (FR-1)."""
        rows = await self.get_messages(session_id)
        if not rows or rows[-1]["role"] != "assistant":
            return 0
        await self.conn.execute("DELETE FROM messages WHERE id = ?", (rows[-1]["id"],))
        await self.conn.commit()
        return 1

    async def message_count(self, session_id: str) -> int:
        async with self.conn.execute(
            "SELECT COUNT(*) AS n FROM messages WHERE session_id = ?", (session_id,)
        ) as cur:
            row = await cur.fetchone()
        return int(row["n"] if row else 0)

    # --------------------------------------------------------------- facts

    async def upsert_fact(
        self,
        key: str,
        value: str,
        *,
        subject: str = "user",
        source: str = "user_explicit",
        confidence: float = 1.0,
    ) -> None:
        now = utcnow()
        await self.conn.execute(
            """
            INSERT INTO facts (subject, key, value, source, confidence, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(subject, key) DO UPDATE SET
              value      = excluded.value,
              source     = excluded.source,
              confidence = excluded.confidence,
              updated_at = excluded.updated_at
            """,
            (subject, key, value, source, confidence, now, now),
        )
        await self.conn.commit()

    async def upsert_facts(self, facts: Sequence[Mapping[str, Any]]) -> int:
        count = 0
        for item in facts:
            key = str(item.get("key") or "").strip()
            value = str(item.get("value") or "").strip()
            if not key or not value:
                continue
            await self.upsert_fact(
                key,
                value,
                subject=str(item.get("subject") or "user"),
                source=str(item.get("source") or "llm_extracted"),
                confidence=float(item.get("confidence") or 0.8),
            )
            count += 1
        return count

    async def top_facts(self, limit: int = 12, *, subject: str = "user") -> list[Fact]:
        """Приоритет: явно сообщённые пользователем → свежие (design.md §11)."""
        async with self.conn.execute(
            """
            SELECT key, value, source, confidence, updated_at FROM facts
            WHERE subject = ?
            ORDER BY CASE WHEN source = 'user_explicit' THEN 0 ELSE 1 END,
                     updated_at DESC, key
            LIMIT ?
            """,
            (subject, limit),
        ) as cur:
            rows = await cur.fetchall()
        return [
            Fact(
                key=r["key"],
                value=r["value"],
                source=r["source"],
                confidence=r["confidence"],
                updated_at=r["updated_at"],
            )
            for r in rows
        ]

    async def fact_count(self) -> int:
        async with self.conn.execute("SELECT COUNT(*) AS n FROM facts") as cur:
            row = await cur.fetchone()
        return int(row["n"] if row else 0)

    # ------------------------------------------------------------- actions

    async def start_action(
        self,
        *,
        tool: str,
        args: Mapping[str, Any],
        risk: str,
        session_id: str | None = None,
        reason: str = "",
        action_id: str | None = None,
    ) -> str:
        aid = action_id or new_id()
        await self.conn.execute(
            "INSERT INTO actions (id, session_id, ts, tool, args_json, risk, status, reason)"
            " VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)",
            (
                aid,
                session_id,
                utcnow(),
                tool,
                json.dumps(dict(args), ensure_ascii=False),
                risk,
                reason,
            ),
        )
        await self.conn.commit()
        return aid

    async def set_action_status(
        self,
        action_id: str,
        status: str,
        *,
        result: str | None = None,
        error: str | None = None,
        duration_ms: int | None = None,
    ) -> None:
        await self.conn.execute(
            "UPDATE actions SET status = ?, result = COALESCE(?, result),"
            " error = COALESCE(?, error), duration_ms = COALESCE(?, duration_ms) WHERE id = ?",
            (status, result, error, duration_ms, action_id),
        )
        await self.conn.commit()

    async def get_action(self, action_id: str) -> dict[str, Any] | None:
        async with self.conn.execute("SELECT * FROM actions WHERE id = ?", (action_id,)) as cur:
            row = await cur.fetchone()
        return dict(row) if row else None

    async def get_actions(self, limit: int = 100) -> list[dict[str, Any]]:
        async with self.conn.execute(
            "SELECT * FROM actions ORDER BY ts DESC, rowid DESC LIMIT ?", (limit,)
        ) as cur:
            rows = await cur.fetchall()
        return [dict(r) for r in rows]
