"""Клиент llama-server (OpenAI-compatible, streaming).

Отвечает только за транспорт: SSE-парсинг, накопление tool_calls, таймауты,
``/health``, остановку генерации. Промптов, памяти и решений тут нет.
"""

from __future__ import annotations

import json
import logging
import re
from collections.abc import AsyncIterator, Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

import httpx

log = logging.getLogger("citlali.llm")


class LLMError(RuntimeError):
    """Базовая ошибка слоя инференса."""


class LLMUnavailable(LLMError):
    """llama-server не отвечает (не запущен, упал, порт занят)."""


class LLMHTTPError(LLMError):
    """llama-server вернул не-2xx. ``status_code`` + тело — в сообщении."""

    def __init__(self, status_code: int, body: str) -> None:
        self.status_code = status_code
        self.body = body[:2000]
        super().__init__(f"llama-server HTTP {status_code}: {self.body[:300]}")


@dataclass(slots=True)
class ToolCallDelta:
    """Накопленный tool_call из стрима (индексы приходят отдельными чанками)."""

    index: int
    id: str = ""
    name: str = ""
    arguments: str = ""


@dataclass(slots=True)
class StreamChunk:
    """Один шаг разбора SSE-потока.

    ``text`` — кусочек ответа; ``tool_calls`` — накопленные вызовы на момент
    чанка; ``finish_reason`` — только в последнем значимом чанке.
    """

    text: str = ""
    finish_reason: str | None = None
    tool_calls: list[ToolCallDelta] = field(default_factory=list)
    usage: dict[str, Any] | None = None
    raw: dict[str, Any] | None = None

    @property
    def is_final(self) -> bool:
        return self.finish_reason is not None


# Пустые блоки <think> приходят от Qwen3-14B/8B даже при --reasoning-format none
# и /no_think: сервер глушит содержимое, но сами теги шаблон всё равно печатает.
# В UI это выглядело бы как мусор перед каждым ответом.
EMPTY_THINK_RE = re.compile(r"(?i)\s*<think>\s*</think>\s*")


def strip_empty_think(text: str) -> str:
    """Убрать пустые ``<think>``-блоки, оставив текст ответа.

    Непустые блоки НЕ трогаем: если модель действительно рассуждает вслух,
    это надо видеть в логе и в оценке характера, а не прятать.
    """
    return EMPTY_THINK_RE.sub("", text)


def _sse_field(line: str) -> tuple[str, str] | None:
    """Разобрать строку SSE в (поле, значение). Комментарии и пустые — None."""
    if not line or line.startswith(":"):
        return None
    field_name, sep, value = line.partition(":")
    if not sep:
        return field_name, ""
    return field_name, value[1:] if value.startswith(" ") else value


async def parse_sse_stream(
    lines: AsyncIterator[str],
) -> AsyncIterator[dict[str, Any]]:
    """Собрать SSE-строки в JSON-объекты ``data:``.

    Отдельная функция (а не метод клиента) — чтобы её можно было тестировать
    без HTTP-слоя. Переносы ``\\r`` срезаются: Windows + HTTP иногда дают CRLF.
    """
    data_parts: list[str] = []
    async for raw_line in lines:
        line = raw_line.rstrip("\r\n")
        if not line:  # граница события
            if data_parts:
                payload = "\n".join(data_parts)
                data_parts.clear()
                if payload.strip() == "[DONE]":
                    return
                try:
                    yield json.loads(payload)
                except json.JSONDecodeError:
                    log.warning("пропущен невалидный SSE data: %.200s", payload)
            continue
        parsed = _sse_field(line)
        if parsed is None:
            continue
        name, value = parsed
        if name == "data":
            data_parts.append(value)
    if data_parts:  # поток оборвался без пустой строки
        payload = "\n".join(data_parts)
        if payload.strip() and payload.strip() != "[DONE]":
            try:
                yield json.loads(payload)
            except json.JSONDecodeError:
                log.warning("незавершённый SSE data в конце потока: %.200s", payload)


class LLMClient:
    """Асинхронный клиент к ``/v1/chat/completions`` llama-server."""

    def __init__(
        self,
        base_url: str = "http://127.0.0.1:8080",
        model: str = "citlali",
        *,
        timeout_s: float = 180.0,
        api_key: str = "not-needed",
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout_s = timeout_s
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=httpx.Timeout(timeout_s, connect=5.0),
            transport=transport,
        )
        self._headers = {"Authorization": f"Bearer {api_key}"}

    # ---------------------------------------------------------------- life

    async def aclose(self) -> None:
        await self._client.aclose()

    async def health(self) -> bool:
        """``True``, если llama-server загрузил модель и готов."""
        try:
            resp = await self._client.get("/health", timeout=5.0)
        except httpx.HTTPError as exc:
            log.debug("health-check не прошёл: %s", exc)
            return False
        return resp.status_code == 200

    async def stop_generation(self, *, slot: int | None = None) -> bool:
        """Прервать генерацию на стороне сервера (используется при «Стоп»)."""
        payload: dict[str, Any] = {}
        if slot is not None:
            payload["id_slot"] = slot
        try:
            resp = await self._client.post("/completion/stop", json=payload, timeout=5.0)
        except httpx.HTTPError as exc:
            log.warning("не удалось остановить генерацию: %s", exc)
            return False
        return resp.status_code in (200, 204)

    # -------------------------------------------------------------- stream

    async def chat_stream(
        self,
        messages: Sequence[Mapping[str, Any]],
        *,
        temperature: float = 0.7,
        max_tokens: int = 1024,
        tools: Sequence[Mapping[str, Any]] | None = None,
        tool_choice: str | None = "auto",
        model: str | None = None,
        extra: Mapping[str, Any] | None = None,
    ) -> AsyncIterator[StreamChunk]:
        """Стриминговый чат. Исключения — подклассы :class:`LLMError`."""
        payload: dict[str, Any] = {
            "model": model or self.model,
            "messages": [dict(m) for m in messages],
            "stream": True,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if tools:
            payload["tools"] = [dict(t) for t in tools]
            payload["tool_choice"] = tool_choice or "auto"
        if extra:
            payload.update(dict(extra))

        accumulated: dict[int, ToolCallDelta] = {}
        try:
            async with self._client.stream(
                "POST", "/v1/chat/completions", json=payload, headers=self._headers
            ) as resp:
                if resp.status_code != 200:
                    body = (await resp.aread()).decode("utf-8", "replace")
                    raise LLMHTTPError(resp.status_code, body)
                async for obj in parse_sse_stream(resp.aiter_lines()):
                    chunk = _to_chunk(obj, accumulated)
                    if chunk is not None:
                        yield chunk
        except httpx.HTTPError as exc:
            raise LLMUnavailable(f"нет связи с llama-server: {exc}") from exc

    # ------------------------------------------------------- non-streaming

    async def chat_json(
        self,
        messages: Sequence[Mapping[str, Any]],
        *,
        temperature: float = 0.1,
        max_tokens: int = 512,
        response_format: Mapping[str, Any] | None = None,
    ) -> str:
        """Один короткий запрос без стрима (извлечение фактов, саммари)."""
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": [dict(m) for m in messages],
            "stream": False,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if response_format:
            payload["response_format"] = dict(response_format)
        try:
            resp = await self._client.post(
                "/v1/chat/completions", json=payload, headers=self._headers
            )
        except httpx.HTTPError as exc:
            raise LLMUnavailable(f"нет связи с llama-server: {exc}") from exc
        if resp.status_code != 200:
            raise LLMHTTPError(resp.status_code, resp.text)
        data = resp.json()
        try:
            return data["choices"][0]["message"]["content"] or ""
        except (KeyError, IndexError, TypeError) as exc:
            raise LLMError(f"неожиданный ответ llama-server: {str(data)[:300]}") from exc


def _to_chunk(obj: dict[str, Any], accumulated: dict[int, ToolCallDelta]) -> StreamChunk | None:
    """Преобразовать один SSE-объект в :class:`StreamChunk` (или None)."""
    choices = obj.get("choices") or []
    if not choices:
        usage = obj.get("usage")
        return StreamChunk(usage=usage, raw=obj) if usage else None

    choice = choices[0]
    delta = choice.get("delta") or {}
    text = delta.get("content") or ""
    finish = choice.get("finish_reason")

    for tc in delta.get("tool_calls") or []:
        idx = int(tc.get("index") or 0)
        acc = accumulated.setdefault(idx, ToolCallDelta(index=idx))
        if tc.get("id"):
            acc.id = str(tc["id"])
        fn = tc.get("function") or {}
        if fn.get("name"):
            acc.name = str(fn["name"])
        if fn.get("arguments"):
            acc.arguments += str(fn["arguments"])

    usage = obj.get("usage")
    if not text and finish is None and not accumulated and not usage:
        return None
    return StreamChunk(
        text=text,
        finish_reason=finish,
        tool_calls=list(accumulated.values()),
        usage=dict(usage) if usage else None,
        raw=obj,
    )
