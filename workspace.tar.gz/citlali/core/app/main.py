"""FastAPI-приложение Citlali Core (Этап 1: чат + SSE + память-заготовка).

Ответственность: HTTP/SSE-контракт для UI, сборка промпта, стриминг из
llama-server, сохранение диалога в SQLite, stop/regenerate, журнал действий.
Агентский цикл и инструменты — Этап 3 (точки расширения помечены `# STAGE3`).
"""

from __future__ import annotations

import asyncio
import logging
import os
import platform
import time
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager, suppress
from datetime import datetime
from pathlib import Path
from typing import Any

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, Field

from . import __version__
from . import protocol as proto
from .config import Config, ConfigError
from .db import DB, utcnow
from .llm import LLMClient, LLMError, LLMHTTPError, LLMUnavailable, strip_empty_think
from .prompt import PromptBuilder
from .router import Route, Router

log = logging.getLogger("citlali.core")

# Лимит из поправки A-10 (ред. 2): характер обязан помещаться в бюджет промпта.
# 4000 знаков оказалось мало: примеры реплик — самая дорогая часть по знакам
# и самая ценная по эффекту. v2.2 = 5.2k знаков ≈ 1630 токенов = 20% контекста
# 8192; вместе с историей (3200) это 4830, на ответ остаётся ~3300. Запас есть.
SOUL_MAX_CHARS = 5600


class SoulNotFoundError(ConfigError):
    """SOUL.md отсутствует или пуст: запуск ядра запрещён (молчаливых заглушек нет)."""


KEEPALIVE_S = 15.0


# ------------------------------------------------------------------ модели


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=8000)
    session_id: str | None = None
    regenerate: bool = False


class ConfirmRequest(BaseModel):
    request_id: str
    approved: bool
    comment: str | None = None


class SessionStart(BaseModel):
    session_id: str | None = None


class FactIn(BaseModel):
    key: str = Field(min_length=1, max_length=64)
    value: str = Field(min_length=1, max_length=512)
    source: str = "user_explicit"
    confidence: float = 1.0


# ----------------------------------------------------------------- app-factory


def load_soul(path: Path) -> str:
    """Прочитать SOUL.md. Отсутствует или пуст — **fatal**, не заглушка.

    Молчаливый фолбэк на заглушку — худший из возможных исходов: приложение
    выглядит рабочим, `/healthz` отвечает ok, а характера нет (ровно так и
    случилось на первом прогоне у оператора из-за относительного `soul_file`
    в config.toml). Лучше не стартовать вообще и сказать, что чинить.
    """
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise SoulNotFoundError(
            f"SOUL.md не найден: {path}\n"
            f"  причина: {exc}\n"
            f"  что делать: запустите scripts\\setup_config.ps1 (он пропишет абсолютный путь\n"
            f"  к soul\\SOUL.md из репозитория) либо пропишите paths.soul_file руками.\n"
            "  Без SOUL.md ядро не стартует: характер — не опция (A-10)."
        ) from exc
    if not text.strip():
        raise SoulNotFoundError(f"SOUL.md пуст: {path} — ядро не стартует без характера")
    if len(text) > SOUL_MAX_CHARS:
        log.warning(
            "SOUL.md = %d знаков при лимите %d (A-10): системный промпт может не влезть в бюджет",
            len(text),
            SOUL_MAX_CHARS,
        )
    return text


def create_app(config: Config | None = None, *, llm: LLMClient | None = None) -> FastAPI:
    cfg = config or Config.load()
    logging.basicConfig(
        level=os.environ.get("CITLALI_LOG_LEVEL", cfg.core.log_level).upper(),
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
    )

    @asynccontextmanager
    async def lifespan(_: FastAPI) -> AsyncIterator[None]:
        await db.connect()
        log.info(
            "Core v%s запущен: db=%s soul=%d знаков llama=%s",
            __version__,
            cfg.db_path,
            len(soul_text),
            cfg.llama.base_url,
        )
        try:
            yield
        finally:
            with suppress(Exception):
                await llm_client.aclose()
            await db.close()
            log.info("Core остановлен")

    app = FastAPI(
        title="Citlali Core",
        version=__version__,
        lifespan=lifespan,
        docs_url=None,  # офлайн-приложение: Swagger наружу не нужен
        redoc_url=None,
        openapi_url=None,
    )
    # UI живёт в том же процессе машины (WebView2), CORS нужен только для dev-режима Vite.
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["tauri://localhost", "http://localhost:1420", "http://127.0.0.1:1420"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    soul_text = load_soul(cfg.soul_path)  # SoulNotFoundError = не стартуем вовсе
    db = DB(cfg.db_path)
    llm_client = llm or LLMClient(
        cfg.llama.base_url, cfg.llama.model_alias, timeout_s=cfg.llm.request_timeout_s
    )
    builder = PromptBuilder(
        soul_text,
        max_messages=cfg.memory.history_max_messages,
        token_budget=cfg.memory.history_token_budget,
        facts_max=cfg.memory.facts_max,
        chars_per_token=cfg.memory.chars_per_token,
        thinking=cfg.llm.thinking,
    )
    router = Router(mode=cfg.router.mode, threshold=cfg.router.command_threshold)

    app.state.cfg = cfg
    app.state.db = db
    app.state.llm = llm_client
    app.state.builder = builder
    app.state.router = router
    app.state.stop_flags = {}  # session_id -> asyncio.Event

    # ------------------------------------------------------------------ auth

    async def require_token(
        x_citlali_token: str | None = Header(default=None),
    ) -> None:
        """A-12: если токен задан в конфиге — он обязателен для всех /v1/*."""
        expected = app.state.cfg.core.api_token  # читаем в момент запроса (конфиг мог измениться)
        if expected and x_citlali_token != expected:
            raise HTTPException(status_code=401, detail="invalid or missing api token")

    # ------------------------------------------------------------- диагностика

    @app.get("/healthz")
    async def healthz() -> dict[str, Any]:
        """Живость самого Core (llama-server проверяется отдельно)."""
        return {
            "status": "ok",
            "version": __version__,
            "soul_chars": len(soul_text),
            "db_connected": db._conn is not None,
            "ts": utcnow(),
        }

    @app.get("/v1/status", dependencies=[Depends(require_token)])
    async def status() -> dict[str, Any]:
        llama_ok = await llm_client.health()
        return {
            "core": "ok",
            "llama": "ok" if llama_ok else "unavailable",
            "model": cfg.llama.model_alias,
            "model_file": str(cfg.model_path),
            "model_exists": cfg.model_path.is_file(),
            "ctx_size": cfg.llama.ctx_size,
            "python": platform.python_version(),
            "os": f"{platform.system()} {platform.release()}",
            "soul_chars": len(soul_text),
        }

    @app.get("/v1/config/public", dependencies=[Depends(require_token)])
    async def public_config() -> dict[str, Any]:
        """Не-секретная часть конфига для экрана настроек."""
        data = cfg.model_dump()
        data["core"].pop("api_token", None)
        return data

    # ------------------------------------------------------------------ chat

    @app.post("/v1/chat", dependencies=[Depends(require_token)])
    async def chat(req: ChatRequest, request: Request) -> StreamingResponse:
        return StreamingResponse(
            _with_keepalive(_chat_stream(req, request), KEEPALIVE_S),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache, no-transform",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )

    async def _chat_stream(req: ChatRequest, request: Request) -> AsyncIterator[str]:
        session_id = await db.ensure_session(req.session_id)
        stop_event = asyncio.Event()
        app.state.stop_flags[session_id] = stop_event
        started = time.perf_counter()
        ttft_ms = 0
        completion_chars = 0
        answer_parts: list[str] = []
        message_id = 0

        try:
            if req.regenerate:
                await db.delete_trailing_assistant(session_id)
                prior = await db.get_messages(session_id, limit=1)
                message_id = int(prior[-1]["id"]) if prior else 0
            else:
                message_id = await db.append_message(session_id, "user", req.message)

            history = await db.history_for_prompt(session_id)
            facts = await db.top_facts(cfg.memory.facts_max)
            summaries = await db.recent_summaries(exclude=session_id)
            route: Route = router.route(req.message)

            result = builder.build(
                req.message,
                history=history,
                facts=facts,
                summary="\n".join(summaries),
                tool_notes=(),  # STAGE3: описания инструментов при route.kind == "command"
                now=datetime.now(),
                os_name=f"{platform.system()} {platform.release()}",
            )

            yield proto.meta(session_id, message_id, cfg.llama.model_alias, utcnow())
            yield proto.route(route.kind, route.reason, route.matched, route.destructive)
            yield proto.status("llm", f"est_tokens={result.est_total_tokens}")

            if route.destructive:
                # A-4: инструмента удаления в v1 нет. Отказ фиксируем в журнале.
                await db.start_action(
                    tool="none",
                    args={"user_request": req.message[:500]},
                    risk="dangerous",
                    session_id=session_id,
                    reason="destructive_not_in_v1",
                )

            try:
                async for chunk in llm_client.chat_stream(
                    result.messages,
                    temperature=cfg.llm.temperature,
                    max_tokens=cfg.llm.max_tokens,
                ):
                    if stop_event.is_set() or await request.is_disconnected():
                        yield proto.aborted("user_stop")
                        await _save_partial(session_id, answer_parts)
                        return
                    if chunk.text:
                        if not ttft_ms:
                            ttft_ms = int((time.perf_counter() - started) * 1000)
                        completion_chars += len(chunk.text)
                        answer_parts.append(chunk.text)
                        yield proto.delta(chunk.text)
                    if chunk.is_final:
                        break
            except LLMUnavailable as exc:
                yield proto.error("llm_unavailable", str(exc), retryable=True)
                return
            except LLMHTTPError as exc:
                yield proto.error("llm_http", str(exc), retryable=False)
                return
            except LLMError as exc:
                yield proto.error("llm_error", str(exc), retryable=False)
                return

            text = strip_empty_think("".join(answer_parts)).strip()
            elapsed = max(time.perf_counter() - started, 1e-6)
            tokens = max(1, int(completion_chars / cfg.memory.chars_per_token))
            saved_id = await db.append_message(session_id, "assistant", text, tokens=tokens)
            yield proto.done(
                stop_reason="stop",
                session_id=session_id,
                message_id=saved_id,
                prompt_tokens=result.est_total_tokens,
                completion_tokens=tokens,
                ttft_ms=ttft_ms,
                tokens_per_s=tokens / elapsed if elapsed > 0 else 0.0,
                truncated=result.truncated,
                route_kind=route.kind,
            )
        except asyncio.CancelledError:
            yield proto.aborted("cancelled")
            await _save_partial(session_id, answer_parts)
            raise
        except Exception as exc:
            log.exception("необработанная ошибка в /v1/chat")
            yield proto.error("internal", f"{type(exc).__name__}: {exc}", retryable=False)
        finally:
            app.state.stop_flags.pop(session_id, None)

    async def _save_partial(session_id: str, parts: list[str]) -> None:
        text = "".join(parts).strip()
        if text:
            await db.append_message(session_id, "assistant", text + " [прервано]")

    @app.delete("/v1/stop/{session_id}", dependencies=[Depends(require_token)])
    async def stop(session_id: str) -> dict[str, Any]:
        event = app.state.stop_flags.get(session_id)
        if event is None:
            return {"stopped": False, "reason": "no active stream"}
        event.set()
        return {"stopped": True}

    # -------------------------------------------------------------- sessions

    @app.post("/v1/sessions", dependencies=[Depends(require_token)])
    async def start_session(req: SessionStart) -> dict[str, Any]:
        sid = await db.ensure_session(req.session_id)
        return {"session_id": sid, "started_at": utcnow()}

    @app.post("/v1/sessions/{session_id}/end", dependencies=[Depends(require_token)])
    async def end_session(session_id: str) -> dict[str, Any]:
        # STAGE4: здесь появятся роллинг-саммари и извлечение фактов.
        if await db.get_session(session_id) is None:
            raise HTTPException(status_code=404, detail="session not found")
        await db.end_session(session_id)
        return {"session_id": session_id, "ended_at": utcnow()}

    @app.get("/v1/sessions/{session_id}/messages", dependencies=[Depends(require_token)])
    async def session_messages(session_id: str, limit: int = 200) -> list[dict[str, Any]]:
        return await db.get_messages(session_id, limit=limit)

    # ----------------------------------------------------------------- facts

    @app.get("/v1/facts", dependencies=[Depends(require_token)])
    async def list_facts(limit: int = 50) -> list[dict[str, Any]]:
        facts = await db.top_facts(limit)
        return [f.to_dict() for f in facts]

    @app.post("/v1/facts", dependencies=[Depends(require_token)])
    async def add_fact(fact: FactIn) -> dict[str, Any]:
        await db.upsert_fact(fact.key, fact.value, source=fact.source, confidence=fact.confidence)
        return {"ok": True, "key": fact.key}

    # --------------------------------------------------------------- journal

    @app.get("/v1/actions", dependencies=[Depends(require_token)])
    async def list_actions(limit: int = 100) -> list[dict[str, Any]]:
        return await db.get_actions(limit=limit)

    # ---------------------------------------------------------- confirm stub

    @app.post("/v1/confirm", dependencies=[Depends(require_token)])
    async def confirm(req: ConfirmRequest) -> dict[str, Any]:
        """STAGE3: серверный HITL-гейт (A-5). Сейчас — только запись в журнал."""
        action = await db.get_action(req.request_id)
        if action is None:
            raise HTTPException(status_code=404, detail="unknown request_id")
        await db.set_action_status(
            req.request_id, "approved" if req.approved else "denied", result=req.comment
        )
        return {"request_id": req.request_id, "approved": req.approved, "pending": False}

    # --------------------------------------------------------- error handler

    @app.exception_handler(ConfigError)
    async def _config_error(_: Request, exc: ConfigError) -> JSONResponse:
        return JSONResponse(status_code=500, content={"error": "config", "detail": str(exc)})

    return app


async def _with_keepalive(stream: AsyncIterator[str], interval_s: float) -> AsyncIterator[str]:
    """SSE-поток с ``ping`` каждые ``interval_s`` секунд молчания.

    Нужен, потому что в агентском цикле (Этап 3) между событиями бывают
    паузы до ``confirm_timeout_s``: без keep-alive UI решит, что поток умер.
    """
    agen = stream.__aiter__()
    task: asyncio.Task[str] | None = None
    try:
        while True:
            # Задачу НЕ пересоздаём: повторный anext() у уже запущенного
            # генератора дал бы RuntimeError. Между «пингами» она просто ждёт.
            if task is None:
                task = asyncio.ensure_future(agen.__anext__())
            done, _ = await asyncio.wait({task}, timeout=interval_s)
            if not done:
                yield proto.ping()
                continue
            try:
                yield task.result()
            except StopAsyncIteration:
                return
            finally:
                task = None
    finally:
        if task is not None and not task.done():
            task.cancel()
        with suppress(RuntimeError):
            await agen.aclose()


# --------------------------------------------------------------------- entry

# Приложение создаётся лениво: сам импорт модуля не должен читать конфиг,
# логировать и поднимать БД (иначе `import app.main` в тестах/скриптах шумит).
_app: FastAPI | None = None


def get_app() -> FastAPI:
    """Фабрика для uvicorn (``--factory``) и для первого обращения."""
    global _app
    if _app is None:
        _app = create_app()
    return _app


def main() -> None:
    """Точка входа: ``python -m app.main`` (или ``citlali-core.exe`` после 5a)."""
    import uvicorn

    try:
        cfg = Config.load()
    except ConfigError as exc:
        raise SystemExit(f"Конфигурация нечитается: {exc}") from exc
    try:
        application = create_app(cfg)
    except SoulNotFoundError as exc:
        raise SystemExit(f"[Citlali] {exc}") from exc
    except ConfigError as exc:
        raise SystemExit(f"[Citlali] конфигурация нечитается: {exc}") from exc
    uvicorn.run(
        application,
        host=cfg.core.host,
        port=cfg.core.port,
        log_level=cfg.core.log_level.lower(),
        access_log=False,
    )


if __name__ == "__main__":  # pragma: no cover
    main()


__all__ = [
    "KEEPALIVE_S",
    "SOUL_MAX_CHARS",
    "SoulNotFoundError",
    "create_app",
    "get_app",
    "load_soul",
    "main",
]
