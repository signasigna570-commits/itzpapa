"""Сборщик системного промпта и истории (FR-2, поправки A-10, A-11).

Порядок секций системного сообщения фиксирован и покрыт тестами:

    <soul> → <facts> → <memory> → <tools> → <context>

``<soul>`` никогда не урезается: потеря характера хуже потери контекста.
Урезается только история, и факт урезки возвращается наружу (``truncated``).
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field
from datetime import datetime
from typing import Literal

Role = Literal["system", "user", "assistant", "tool"]


@dataclass(slots=True)
class Msg:
    """Сообщение диалога в формате OpenAI chat-completions."""

    role: Role
    content: str

    def to_openai(self) -> dict[str, str]:
        return {"role": self.role, "content": self.content}


@dataclass(slots=True)
class Fact:
    """Факт о пользователе из SQLite (таблица ``facts``)."""

    key: str
    value: str
    source: str = "user_explicit"  # user_explicit | llm_extracted
    confidence: float = 1.0
    updated_at: str = ""

    def to_dict(self) -> dict[str, object]:
        """Сериализация для HTTP (dataclass со ``slots=True`` не имеет ``__dict__``)."""
        return {
            "key": self.key,
            "value": self.value,
            "source": self.source,
            "confidence": self.confidence,
            "updated_at": self.updated_at,
        }


@dataclass(slots=True)
class PromptResult:
    system: str
    history: list[Msg]
    user: Msg
    dropped_messages: int = 0
    truncated: bool = False
    est_system_tokens: int = 0
    est_history_tokens: int = 0
    sections: list[str] = field(default_factory=list)

    @property
    def messages(self) -> list[dict[str, str]]:
        """Готовый список для отправки в llama-server."""
        return [
            {"role": "system", "content": self.system},
            *[m.to_openai() for m in self.history],
            self.user.to_openai(),
        ]

    @property
    def est_total_tokens(self) -> int:
        """Суммарная оценка токенов запроса (system + история + реплика)."""
        return self.est_system_tokens + self.est_history_tokens + est_tokens(self.user.content, 3.2)


# ---------------------------------------------------------------- утилиты


def est_tokens(text: str, chars_per_token: float = 3.2) -> int:
    """Грубая, но детерминированная оценка токенов.

    Точный подсчёт не нужен: llama-server всё равно режет по ``-c``.
    Наша задача — предсказуемо управлять бюджетом и не терять ``<soul>``.
    """
    if chars_per_token <= 0:
        raise ValueError("chars_per_token должен быть > 0")
    if not text:
        return 0
    return max(1, int(len(text) / chars_per_token))


def escape_section(text: str, tag: str) -> str:
    """Защита от инъекции закрывающего тега секции содержимым факта/саммари."""
    return text.replace(f"</{tag}>", f"<\\/{tag}>")


def render_facts(facts: Sequence[Fact], limit: int) -> str:
    """Блок фактов: сначала явно сообщённые пользователем, затем более свежие."""
    if limit <= 0 or not facts:
        return ""
    ordered = sorted(
        facts,
        key=lambda f: (
            0 if f.source == "user_explicit" else 1,
            _invert_iso(f.updated_at),
            f.key,
        ),
    )
    lines = [f"- {f.key}: {escape_section(f.value, 'facts')}" for f in ordered[:limit]]
    return "\n".join(lines)


def _invert_iso(iso: str) -> str:
    """Инверсия ISO-8601 строки для сортировки «свежие выше».

    Лексикографический порядок ISO-дат совпадает с хронологическим,
    поэтому побуквенная инверсия кода символа даёт обратный порядок.
    Пустая дата sort-уется последней (``\\uffff``).
    """
    if not iso:
        return "\uffff"
    return "".join(chr(0x10FFFF - ord(ch)) for ch in iso)


class PromptBuilder:
    """Собирает сообщения для одного запроса к модели."""

    def __init__(
        self,
        soul: str,
        *,
        max_messages: int = 20,
        token_budget: int = 3200,
        facts_max: int = 12,
        chars_per_token: float = 3.2,
        thinking: bool = False,
        persona_name: str = "Ситлали",
    ) -> None:
        if not soul.strip():
            raise ValueError("SOUL.md пуст: характер не задан, запуск запрещён")
        self.soul = soul.strip()
        self.max_messages = max(1, max_messages)
        self.token_budget = max(0, token_budget)
        self.facts_max = max(0, facts_max)
        self.chars_per_token = chars_per_token if chars_per_token > 0 else 3.2
        self.thinking = thinking
        self.persona_name = persona_name

    # ------------------------------------------------------------- система

    def build_system(
        self,
        *,
        facts: Sequence[Fact] = (),
        summary: str = "",
        tool_notes: Sequence[str] = (),
        now: datetime | None = None,
        os_name: str = "Windows",
    ) -> tuple[str, list[str]]:
        """Возвращает (текст системного промпта, список имён секций)."""
        moment = now or datetime.now()
        parts: list[str] = [f"<soul>\n{self.soul}\n</soul>"]
        sections = ["soul"]

        facts_block = render_facts(facts, self.facts_max)
        if facts_block:
            parts.append(f"<facts>\n{facts_block}\n</facts>")
            sections.append("facts")

        if summary.strip():
            parts.append(f"<memory>\n{escape_section(summary.strip(), 'memory')}\n</memory>")
            sections.append("memory")

        if tool_notes:
            notes = "\n".join(f"- {n}" for n in tool_notes)
            parts.append(
                "<tools>\n"
                "Инструменты доступны только когда задача реально требует действия на ПК. "
                "Для разговора инструменты не вызываются.\n"
                f"{notes}\n"
                "</tools>"
            )
            sections.append("tools")

        ctx = [
            f"Сейчас: {moment:%Y-%m-%d %H:%M} ({moment:%A}), локальное время пользователя.",
            f"ОС: {os_name}. Офлайн-режим: сеть используется только по явной команде пользователя.",
        ]
        if not self.thinking:
            ctx.append("/no_think — рассуждения вслух не нужны, отвечай сразу и коротко.")
        parts.append("<context>\n" + "\n".join(ctx) + "\n</context>")
        sections.append("context")

        return "\n\n".join(parts), sections

    # ------------------------------------------------------------- история

    def trim_history(self, history: Sequence[Msg]) -> tuple[list[Msg], bool]:
        """Последние ``max_messages`` сообщений, затем подрезка спереди по бюджету.

        Возвращает (сообщения, truncated). Пустая история → ([], False).
        """
        items = [m for m in history if m.content.strip() or m.role == "assistant"]
        if not items:
            return [], False

        if len(items) > self.max_messages:
            items = items[-self.max_messages :]
            truncated = True
        else:
            truncated = False

        while len(items) > 1 and self._tokens(items) > self.token_budget:
            items.pop(0)
            truncated = True

        return items, truncated

    def _tokens(self, items: Iterable[Msg]) -> int:
        return sum(est_tokens(m.content, self.chars_per_token) for m in items)

    # -------------------------------------------------------------- сборка

    def build(
        self,
        user_text: str,
        *,
        history: Sequence[Msg] = (),
        facts: Sequence[Fact] = (),
        summary: str = "",
        tool_notes: Sequence[str] = (),
        now: datetime | None = None,
        os_name: str = "Windows",
    ) -> PromptResult:
        system, sections = self.build_system(
            facts=facts, summary=summary, tool_notes=tool_notes, now=now, os_name=os_name
        )
        kept, truncated = self.trim_history(history)
        user = Msg(role="user", content=user_text)
        cpt = self.chars_per_token
        return PromptResult(
            system=system,
            history=kept,
            user=user,
            dropped_messages=len(history) - len(kept),
            truncated=truncated,
            est_system_tokens=est_tokens(system, cpt),
            est_history_tokens=sum(est_tokens(m.content, cpt) for m in kept),
            sections=sections,
        )
