"""SSE-протокол Core ↔ UI (design.md §3, поправка A-6).

Единый набор типов событий. UI обязан игнорировать неизвестные типы —
это позволяет расширять ядро без слома оболочки.
"""

from __future__ import annotations

import json
from typing import Any, Literal

EventType = Literal[
    "meta",
    "route",
    "status",
    "delta",
    "tool_call",
    "confirm_required",
    "done",
    "error",
    "aborted",
    "ping",
]

# События, после которых поток обязан закрыться.
TERMINAL_EVENTS: frozenset[str] = frozenset({"done", "error", "aborted"})


def sse(event: str, data: dict[str, Any]) -> str:
    """Сериализовать событие в wire-формат SSE.

    ``ensure_ascii=False`` — кириллица идёт UTF-8, а не ``\\uXXXX``
    (иначе стриминг русского текста раздувает трафик и ломает посимвольный вывод).
    """
    payload = json.dumps(data, ensure_ascii=False, default=str)
    return f"event: {event}\ndata: {payload}\n\n"


def meta(session_id: str, message_id: int, model: str, ts: str) -> str:
    return sse(
        "meta", {"session_id": session_id, "message_id": message_id, "model": model, "ts": ts}
    )


def route(kind: str, reason: str, matched: list[str], destructive: bool = False) -> str:
    return sse(
        "route",
        {"kind": kind, "reason": reason, "matched": matched, "destructive": destructive},
    )


def status(stage: str, detail: str = "") -> str:
    return sse("status", {"stage": stage, "detail": detail})


def delta(text: str) -> str:
    return sse("delta", {"text": text})


def tool_call(call_id: str, name: str, args: dict[str, Any], risk: str, status_: str) -> str:
    return sse(
        "tool_call",
        {"id": call_id, "name": name, "args": args, "risk": risk, "status": status_},
    )


def confirm_required(
    request_id: str,
    tool: str,
    args: dict[str, Any],
    risk: str,
    reason: str,
    expires_at: str,
) -> str:
    return sse(
        "confirm_required",
        {
            "request_id": request_id,
            "tool": tool,
            "args": args,
            "risk": risk,
            "reason": reason,
            "expires_at": expires_at,
        },
    )


def done(
    *,
    stop_reason: str,
    session_id: str,
    message_id: int,
    prompt_tokens: int = 0,
    completion_tokens: int = 0,
    ttft_ms: int = 0,
    tokens_per_s: float = 0.0,
    truncated: bool = False,
    route_kind: str = "chat",
    steps: int = 0,
) -> str:
    return sse(
        "done",
        {
            "stop_reason": stop_reason,
            "session_id": session_id,
            "message_id": message_id,
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "ttft_ms": ttft_ms,
            "tokens_per_s": round(tokens_per_s, 2),
            "truncated": truncated,
            "route_kind": route_kind,
            "steps": steps,
        },
    )


def error(code: str, message: str, *, retryable: bool = True) -> str:
    return sse("error", {"code": code, "message": message, "retryable": retryable})


def aborted(reason: str) -> str:
    return sse("aborted", {"reason": reason})


def ping() -> str:
    return sse("ping", {})


def parse_sse_text(raw: str) -> list[tuple[str, dict[str, Any]]]:
    """Разобрать текстовый SSE-буфер в список ``(event, data)``.

    Хелпер для тестов и для отладки UI (в рантайме UI парсит поток нативно).
    """
    out: list[tuple[str, dict[str, Any]]] = []
    for block in raw.split("\n\n"):
        if not block.strip():
            continue
        event, data_line = "message", ""
        for line in block.splitlines():
            if line.startswith("event:"):
                event = line.split(":", 1)[1].strip()
            elif line.startswith("data:"):
                data_line = line.split(":", 1)[1].strip()
        if data_line:
            try:
                out.append((event, json.loads(data_line)))
            except json.JSONDecodeError:
                continue
    return out
