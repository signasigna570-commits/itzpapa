"""Роутер v1: «команда vs болтовня» (FR-5).

Regex-классификатор без модели. Ошибка в сторону ``command`` безопасна
(агент без подходящего инструмента просто ответит текстом), поэтому
порог намеренно низкий: достаточно одного совпадения.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Literal

RouteKind = Literal["chat", "command"]

# Глаголы действия в повелительном наклонении (и частые разговорные формы).
_ACTION_RE = re.compile(
    r"""(?xi)
    \b(
        открой | откройте | открывай |
        запусти | запускай | стартуй | вруби |
        выключи | выключь | останови | закрой | завершить | убей |
        найди | поискать | поищи | загугли | нагугли |
        прочитай | прочитать | прочти | открой\s+файл |
        запиши | сохрани | создай | сделай\s+файл |
        покажи | выведи | проверь | посмотри |
        выполни | исполни | запусти\s+команду |
        напомни | поставь\s+напоминание |
        включи | переключи | прибавь | убавь | сделай\s+громче | тише |
        сверни | разверни |
        перезагрузи | спящий\s+режим | заблокируй
    )\b
    """,
    re.VERBOSE,
)

# Цели: приложения, веб, файловая система, система.
_TARGET_RE = re.compile(
    r"""(?xi)
    \b(
        youtube | yandex | google | github | браузер | хром | chrome | firefox | edge |
        блокнот | notepad | калькулятор | calc | проводник | explorer | терминал | terminal |
        powershell | cmd | paint | discord | telegram | vscode | code | steam |
        файл | папка | каталог | документа? | диск | директория |
        система | систему | процессы? | оперативк[аи] | память | видеокарт[ау] |
        температура | батарея | версия | характеристики | свободное\s+место | место\s+на\s+диске |
        скрипт | команду | powershell-?команду
    )\b
    """,
    re.VERBOSE,
)

# Переносные цели: «открой мне душу» — это не команда, а фигура речи.
_FIGURATIVE_RE = re.compile(
    r"(?xi)\b(душу|сердце|глаза|секрет[ыа]?|тайну|истину|правду|мысли|чувства)\b"
)

# Вопрос о возможности/умении: «можешь открыть браузер?» — сначала ответ, не действие.
_INTENT_RE = re.compile(
    r"(?xi)\b(можешь|сможешь|умеешь|можно ли|не могла бы|не могла б|попробуй)\b"
)

# Откровенная болтовня, которую не надо тащить в агентский цикл.
_CHAT_RE = re.compile(
    r"""(?xi)
    ^\s*(привет | здоров | хай | hello | hi | доброе\s+утро | добрый\s+(день|вечер) |
         как\s+(дела|ты|жизнь) | кто\s+ты | что\s+ты\s+(такое|умеешь) | расскажи |
         объясни | почему | зачем | спасибо | благодарю | споки | пока | скучно |
         поговорим | поболтаем)\b
    """,
    re.VERBOSE,
)

# Маркеры деструктивных намерений (в v1 инструмента удаления нет — A-4).
DESTRUCTIVE_RE = re.compile(
    r"(?xi)\b(удали(?:ть|\s+всё)?|стереть|снеси|очисти\s+папку|форматируй|wipe|delete)\b"
)


@dataclass(slots=True)
class Route:
    kind: RouteKind
    reason: str
    matched: list[str] = field(default_factory=list)
    destructive: bool = False

    def as_event(self) -> dict[str, object]:
        """Полезная нагрузка SSE-события ``route`` (design.md §3)."""
        return {
            "kind": self.kind,
            "reason": self.reason,
            "matched": self.matched,
            "destructive": self.destructive,
        }


def classify(text: str, *, threshold: int = 1) -> Route:
    """Классифицировать реплику пользователя.

    ``threshold`` — сколько совпадений считается достаточным для ``command``.
    """
    raw = (text or "").strip()
    if not raw:
        return Route(kind="chat", reason="empty_input")

    destructive = bool(DESTRUCTIVE_RE.search(raw))
    actions = _ACTION_RE.findall(raw)
    targets = _TARGET_RE.findall(raw)
    hits = [h.strip().lower() for h in (*actions, *targets) if h and h.strip()]

    # «удали всё в Downloads» → команда (с флагом destructive) даже без
    # совпадения с whitelist-глаголами: агент обязан отказать и залогировать.
    if destructive:
        return Route(
            kind="command",
            reason="destructive_intent",
            matched=hits or ["destructive"],
            destructive=True,
        )

    if len(hits) >= max(1, threshold):
        # Фигура речи или вопрос о возможности → разговор, а не агентский цикл.
        if _FIGURATIVE_RE.search(raw):
            return Route(kind="chat", reason="figurative_expression", matched=hits)
        if _INTENT_RE.search(raw):
            return Route(kind="chat", reason="asking_about_capability", matched=hits)
        return Route(kind="command", reason="action_or_target_matched", matched=hits)

    if _CHAT_RE.search(raw):
        return Route(kind="chat", reason="smalltalk_greeting", matched=[])

    return Route(kind="chat", reason="no_command_signal", matched=[])


class Router:
    """Тонкая обёртка над :func:`classify` с конфигом (mode/threshold)."""

    def __init__(self, *, mode: str = "regex", threshold: int = 1) -> None:
        if mode != "regex":
            # LLM-роутер — v2. Явно логируем деградацию, а не падаем.
            mode = "regex"
        self.mode = mode
        self.threshold = threshold

    def route(self, text: str) -> Route:
        return classify(text, threshold=self.threshold)
