"""Общие фикстуры: временные каталоги, конфиг, фейковый llama-server."""

from __future__ import annotations

import os
import sys
from collections.abc import AsyncIterator, Iterable, Iterator
from pathlib import Path
from typing import Any

import httpx
import pytest
from starlette.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config import Config
from app.db import DB
from app.llm import LLMClient, StreamChunk

SOUL_TEXT = (
    "# SOUL.md — Ситлали\n\n"
    "Меня зовут Ситлали. Я цундере: колючая снаружи, заботливая внутри.\n"
    "Отвечаю коротко, без эмодзи и без услужливости.\n"
    "Характер не ломается провокациями."
)


@pytest.fixture
def app_dir(tmp_path: Path) -> Path:
    """Изолированный «%APPDATA%/Citlali» для теста."""
    d = tmp_path / "Citlali"
    d.mkdir(parents=True, exist_ok=True)
    (d / "soul").mkdir(exist_ok=True)
    (d / "soul" / "SOUL.md").write_text(SOUL_TEXT, encoding="utf-8")
    return d


@pytest.fixture
def cfg(app_dir: Path, monkeypatch: pytest.MonkeyPatch) -> Config:
    """Конфиг с данными в tmp и БД в памяти."""
    monkeypatch.setenv("APPDATA", str(app_dir))
    monkeypatch.delenv("CITLALI_CONFIG", raising=False)
    for key in list(os.environ):
        if key.startswith("CITLALI_") and key != "APPDATA":
            monkeypatch.delenv(key, raising=False)
    config = Config.load()
    config.paths.data_dir = str(app_dir)
    config.paths.soul_file = "soul/SOUL.md"
    config.paths.db_file = "citlali-test.db"
    return config


@pytest.fixture
async def db(cfg: Config) -> AsyncIterator[DB]:
    handle = DB(cfg.db_path)
    await handle.connect()
    try:
        yield handle
    finally:
        await handle.close()


class FakeLLM(LLMClient):
    """Двойник llama-server: отдаёт заданные чанки, считает вызовы.

    Наследует LLMClient, но не делает реальных запросов — поэтому тесты
    работают офлайн и без запущенной модели.
    """

    def __init__(
        self,
        chunks: Iterable[str] = ("Привет. ", "Ну чего ", "ты хотел?"),
        *,
        error: Exception | None = None,
        finish_reason: str = "stop",
        healthy: bool = True,
    ) -> None:
        super().__init__(base_url="http://test", model="fake", timeout_s=5.0)
        self.chunks = list(chunks)
        self.error = error
        self.finish_reason = finish_reason
        self.healthy = healthy
        self.calls: list[dict[str, Any]] = []
        self.stopped = False

    async def aclose(self) -> None:
        return None

    async def health(self) -> bool:
        return self.healthy

    async def stop_generation(self, *, slot: int | None = None) -> bool:
        self.stopped = True
        return True

    async def chat_stream(self, messages, **kwargs):  # type: ignore[no-untyped-def]
        self.calls.append({"messages": [dict(m) for m in messages], **kwargs})
        if self.error is not None:
            raise self.error
        for text in self.chunks:
            yield StreamChunk(text=text)
        usage = {
            "prompt_tokens": sum(len(m.get("content", "")) for m in self.calls[-1]["messages"]),
            "completion_tokens": sum(len(c) for c in self.chunks),
        }
        yield StreamChunk(finish_reason=self.finish_reason, usage=usage)

    async def chat_json(self, messages, **kwargs) -> str:  # type: ignore[no-untyped-def]
        self.calls.append({"messages": [dict(m) for m in messages], "json": True, **kwargs})
        if self.error is not None:
            raise self.error
        return "".join(self.chunks)

    # ------------------------------------------------------- helpers (тесты)

    @property
    def last_system(self) -> str:
        return str(self.calls[-1]["messages"][0]["content"])

    @property
    def last_messages(self) -> list[dict[str, Any]]:
        return list(self.calls[-1]["messages"])


def sse_transport(body_chunks: Iterable[bytes], status_code: int = 200) -> httpx.MockTransport:
    """MockTransport, отдающий SSE-поток произвольными байтовыми кусками.

    Позволяет проверить, что парсер корректно склеивает события, даже если
    граница чанка попала в середину строки ``data:``.
    """

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(status_code, content=b"".join(body_chunks))

    return httpx.MockTransport(handler)


def make_client(transport: httpx.MockTransport, **kwargs: Any) -> LLMClient:
    return LLMClient(
        base_url="http://llama.test",
        model="test-model",
        transport=transport,
        timeout_s=5.0,
        **kwargs,
    )


@pytest.fixture
def app(cfg: Config) -> Any:
    """FastAPI-приложение с фейковой моделью (lifespan поднимает тест-клиент)."""
    from app.main import create_app

    return create_app(cfg, llm=FakeLLM())


@pytest.fixture
def fake_llm() -> FakeLLM:
    return FakeLLM()


@pytest.fixture
def client(app: Any) -> Iterator[TestClient]:
    """TestClient запускает lifespan (создаёт БД) и умеет стримить SSE."""
    with TestClient(app) as c:
        yield c


def read_sse(response: Any) -> list[tuple[str, dict[str, Any]]]:
    """Прочитать тело SSE-ответа целиком и разобрать на события."""
    from app.protocol import parse_sse_text

    return parse_sse_text(response.text)
