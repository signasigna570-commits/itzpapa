# Probe for pytest (core/tests/test_bootstrap_local_first.py).
#
# Why: scripts\01_bootstrap.ps1 has top-level code (disk check, downloads), so it
# cannot be dot-sourced from a test. Instead we parse the file, pull out ONLY the
# function definitions we need and define them here. No network, no side effects.
#
# Output contract (ASCII, one fact per line, parsed by the test):
#   DIRS|<dir1>|<dir2>...
#   HIT|<model name>|<absolute path>|<expected bytes>
#   MISS|<model name>|<expected bytes>
#
# Pure ASCII on purpose: no BOM needed, and pytest reads it as UTF-8.

param(
  [Parameter(Mandatory = $true)][string]$Root,   # fake project root (models\ lives here)
  [Parameter(Mandatory = $true)][string]$Repo     # real repository (scripts\bootstrap.json)
)

$ErrorActionPreference = "Stop"

$src = Join-Path $Repo "scripts\01_bootstrap.ps1"
if (-not (Test-Path -LiteralPath $src)) { Write-Output "ERR|no bootstrap script"; exit 3 }

$tokens = $null
$parseErrors = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile($src, [ref]$tokens, [ref]$parseErrors)
if ($parseErrors -and $parseErrors.Count -gt 0) {
  foreach ($e in $parseErrors) { Write-Output ("ERR|" + $e.Message) }
  exit 4
}

$wanted = @("Get-ModelsDirs", "Find-LocalModel", "Get-ExpectedBytes")
$defs = $ast.FindAll(
  { param($node)
    $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and
    ($wanted -contains $node.Name) }, $true)

if ($defs.Count -lt 3) {
  Write-Output ("ERR|functions not found: " + $defs.Count + " of 3")
  exit 5
}
foreach ($d in $defs) { Invoke-Expression $d.Extent.Text }

$CfgPath = Join-Path $Repo "scripts\bootstrap.json"
$Cfg = Get-Content -LiteralPath $CfgPath -Raw -Encoding UTF8 | ConvertFrom-Json

$dirs = @(Get-ModelsDirs)
Write-Output ("DIRS|" + ($dirs -join "|"))

foreach ($spec in @($Cfg.models)) {
  $expected = Get-ExpectedBytes $spec
  $hit = Find-LocalModel $spec
  if ($hit) {
    Write-Output ("HIT|" + $spec.name + "|" + $hit + "|" + $expected)
  } else {
    Write-Output ("MISS|" + $spec.name + "|" + $expected)
  }
}
exit 0
