# Probe for pytest (core/tests/test_ps_syntax.py).
#
# Parses every .ps1 in the given directory with the REAL PowerShell parser and
# prints one line per file. Static checks (balanced brackets, BOM, ASCII) cannot
# catch broken string escaping, and on 19.10.2026 that is exactly what happened:
# \" does not escape a quote in PowerShell, the string fell apart and the whole
# script stopped parsing.
#
# Output contract (ASCII, parsed by the test):
#   OK|<file name>
#   FAIL|<file name>|<line>|<message>
#   TOTAL|<files>|<files with errors>

param([Parameter(Mandatory = $true)][string]$Dir)

$ErrorActionPreference = "Stop"

if (-not (Test-Path -LiteralPath $Dir)) {
  Write-Output ("ERR|no such directory: " + $Dir)
  exit 3
}

$files = @(Get-ChildItem -LiteralPath $Dir -Filter *.ps1 -File -ErrorAction SilentlyContinue)
$bad = 0
foreach ($f in $files) {
  $errs = $null
  [void][System.Management.Automation.Language.Parser]::ParseFile($f.FullName, [ref]$null, [ref]$errs)
  if ($errs -and $errs.Count -gt 0) {
    $bad = $bad + 1
    foreach ($e in $errs) {
      Write-Output ("FAIL|" + $f.Name + "|" + $e.Extent.StartLineNumber + "|" + $e.Message)
    }
  } else {
    Write-Output ("OK|" + $f.Name)
  }
}
Write-Output ("TOTAL|" + $files.Count + "|" + $bad)
exit 0
