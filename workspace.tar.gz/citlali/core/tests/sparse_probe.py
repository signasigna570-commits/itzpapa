"""Проба: умеет ли том оператора держать большие заглушки бесплатно (T0.38).

Запускается из `scripts\\probe_sparse.cmd` ДО прогона тестов и печатает три числа:
сколько байт том выделил под файл с `st_size = 5 GB`. Если разреженность работает,
дельта — килобайты; если нет — гигабайты, и тесты поиска моделей на этой машине
займут десятки GB в `%TEMP%` (ловушка 25).

Модуль ничего не удаляет кроме собственного временного файла и не трогает
репозиторий. Вывод — ASCII-строки `KEY=value`, их читает `probe_sparse.ps1`.
"""

from __future__ import annotations

import os
import shutil
import sys
import tempfile
from pathlib import Path

# Импорт без пакета `tests`: `tests/__init__.py` и conftest тянут pytest/httpx/
# starlette, а пробу оператор может запустить и системным python (без venv).
sys.path.insert(0, str(Path(__file__).resolve().parent))

from sparsefile import allocated_bytes, filesystem_name, make_sparse_file


def free_bytes(path: str | os.PathLike[str]) -> int:
    """Свободно на томе, где лежит `path` (десятичные байты, как disk_preflight)."""
    usage = shutil.disk_usage(str(path))
    return int(usage.free)


def probe(size: int = 5_000_000_000, directory: str | None = None) -> int:
    root = Path(directory or tempfile.gettempdir())
    root.mkdir(parents=True, exist_ok=True)
    target = root / "citlali-sparse-probe.gguf"
    target.unlink(missing_ok=True)
    print(f"dir={root}")
    print(f"fs={filesystem_name(root) or 'unknown'}")
    print(f"requested_size={size}")
    before = free_bytes(root)
    try:
        make_sparse_file(target, size)
    except Exception as exc:  # диагноз важнее типа исключения: печатаем и возвращаем 1
        print(f"error={type(exc).__name__}: {exc}")
        print("SPARSE=FAIL")
        return 1
    try:
        after = free_bytes(root)
        used = allocated_bytes(target)
        logical = target.stat().st_size
        print(f"logical_size={logical}")
        print(f"allocated={used}")
        print(f"free_before={before}")
        print(f"free_after={after}")
        print(f"free_delta={before - after}")
        print(f"ratio={used / size:.6f}")
        ok = logical == size and used <= 1024 * 1024
        print(f"SPARSE={'OK' if ok else 'FAIL'}")
        return 0 if ok else 1
    finally:
        target.unlink(missing_ok=True)


def main(argv: list[str]) -> int:
    size = 5_000_000_000
    directory: str | None = None
    for arg in argv:
        if arg.startswith("--size="):
            size = int(arg.split("=", 1)[1])
        elif arg.startswith("--dir="):
            directory = arg.split("=", 1)[1]
    return probe(size=size, directory=directory)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
