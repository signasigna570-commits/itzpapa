"""Разреженные файлы-заглушки для тестов: настоящий размер, ноль байт на диске.

Зачем отдельный модуль (ловушка 25, T0.38)
-------------------------------------------
Тесты поиска моделей обязаны сверять байты с ``bootstrap.json``: файл 5 680 522 464
байта — это модель, а 5 680 522 463 байта — недокачка. Значит, заглушке нужен
**точный** размер. До 20.10.2026 заглушки делал ``fh.truncate(size)``, и в
песочнице (ext4) это честно давало разреженный файл: ноль блоков на диске.

На NTFS ``truncate`` работает иначе: ``SetEndOfFile`` **выделяет** место, то есть
каждый прогон пяти тестов записывал в ``%TEMP%\\pytest-of-User`` ~24 GB настоящих
байтов, а pytest хранит последние три прогона — до ~70 GB. Отчёт ``diag_disk.cmd``
у оператора показал ``[63.51 GB] AppData\\Local\\Temp`` и тринадцать GGUF по 4-8 GB
внутри ``pytest-of-User\\pytest-6..8``; до этого тот же объём выглядел как
«куда делись 70 GB». Место съедал не продукт и не модель, а тест, который в
песочнице был бесплатным.

Лечение: на Windows файл помечается разреженным (``FSCTL_SET_SPARSE``) и его
диапазон зануляется (``FSCTL_SET_ZERO_DATA``) — NTFS не хранит нули, поэтому
``Length`` остаётся точным, а заняты килобайты. Поведение проверяется по
``st_blocks`` (единственный переносимый способ увидеть выделенные блоки) и
защищено гарантами ``test_scripts_env.py``: ``truncate`` в тестах запрещён, если
в том же файле нет ``sparsefile``.

Если разреженность недоступна (FAT/exFAT, сетевая папка, отказ ioctl), тесты,
которые умеют писать только большие заглушки, обязаны пропускаться, а не
заполнять диск оператора: ``sparse_unavailable_reason()`` возвращает причину для
``pytest.mark.skipif``.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

# Десятичные единицы (AGENTS §6): GB = 1000^3. Порог «большой заглушки» — 64 MB:
# всё, что крупнее, обязано быть разреженным.
LARGE = 64 * 1000**2


class SparseNotSupported(RuntimeError):
    """Файл создан, но место под него выделено целиком: заглушка не бесплатна."""


def allocated_bytes(path: str | os.PathLike[str]) -> int:
    """Сколько байт файл **занял на диске** (не ``st_size``!).

    Для разреженного файла из 5 GB это единицы килобайт. ``st_blocks`` заполняют
    файловые системы Linux, на Windows их считает NTFS; блок — 512 байт
    независимо от реального размера кластера.
    """
    st = os.stat(path)
    blocks = getattr(st, "st_blocks", None)
    if blocks is None:  # pragma: no cover - защита от экзотической платформы
        return st.st_size
    return int(blocks) * 512


def filesystem_name(path: str | os.PathLike[str]) -> str:
    """Имя файловой системы тома (``NTFS``, ``ext4``, …); пусто, если не узнали."""
    if sys.platform != "win32":
        try:
            return str(os.confstr("CS_FILESYSTEM"))  # type: ignore[attr-defined]
        except (AttributeError, ValueError, OSError):
            return ""
    import ctypes
    from ctypes import wintypes

    buf = ctypes.create_unicode_buffer(64)
    root = os.path.splitdrive(os.path.abspath(str(path)))[0] + "\\"
    ok = ctypes.windll.kernel32.GetVolumeInformationW(  # type: ignore[attr-defined]
        wintypes.LPCWSTR(root), None, 0, None, None, None, buf, len(buf)
    )
    return buf.value if ok else ""


def _make_sparse_windows(path: Path) -> None:
    """Пометить файл разреженным и обнулить весь диапазон (место не выделяется)."""
    import ctypes
    from ctypes import wintypes

    kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
    handle = kernel32.CreateFileW(
        wintypes.LPCWSTR(str(path)),
        0x40000000,  # GENERIC_WRITE
        0x00000001 | 0x00000002,  # FILE_SHARE_READ | FILE_SHARE_WRITE
        None,
        3,  # OPEN_EXISTING
        0,
        None,
    )
    if handle == wintypes.HANDLE(-1).value:
        raise SparseNotSupported(f"CreateFileW не открыл {path}: {kernel32.GetLastError()}")
    try:
        returned = wintypes.DWORD(0)
        ok = kernel32.DeviceIoControl(
            wintypes.HANDLE(handle),
            wintypes.DWORD(0x000900C4),  # FSCTL_SET_SPARSE
            None,
            wintypes.DWORD(0),
            None,
            wintypes.DWORD(0),
            ctypes.byref(returned),
            None,
        )
        if not ok:
            raise SparseNotSupported(f"FSCTL_SET_SPARSE не сработал: {kernel32.GetLastError()}")

        class FileZeroDataInformation(ctypes.Structure):
            _fields_ = [
                ("FileOffset", ctypes.c_longlong),
                ("BeyondFinalZero", ctypes.c_longlong),
            ]

        size = path.stat().st_size
        if size <= 0:
            return
        info = FileZeroDataInformation(0, size)
        ok = kernel32.DeviceIoControl(
            wintypes.HANDLE(handle),
            wintypes.DWORD(0x000980C8),  # FSCTL_SET_ZERO_DATA
            ctypes.byref(info),
            wintypes.DWORD(ctypes.sizeof(info)),
            None,
            wintypes.DWORD(0),
            ctypes.byref(returned),
            None,
        )
        if not ok:
            # Файл уже помечен разреженным, но без SET_ZERO_DATA место могло
            # остаться выделенным — молча продолжать нельзя.
            raise SparseNotSupported(f"FSCTL_SET_ZERO_DATA не сработал: {kernel32.GetLastError()}")
    finally:
        kernel32.CloseHandle(wintypes.HANDLE(handle))


def make_sparse_file(path: str | os.PathLike[str], size: int) -> Path:
    """Создать файл-заглушку: ``st_size == size``, занято на диске — килобайты.

    Бросает ``SparseNotSupported``, если размер крупнее ``LARGE``, а разреженность
    не получилась: молча выделить 5 GB на диске оператора — ровно та авария,
    из-за которой модуль существует.
    """
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("wb") as fh:
        fh.truncate(size)
    if sys.platform == "win32":
        _make_sparse_windows(p)
    if size >= LARGE:
        used = allocated_bytes(p)
        if used > size // 8:
            raise SparseNotSupported(
                f"{p}: st_size={size}, занято на диске {used} — файл не разреженный"
            )
    return p


def sparse_unavailable_reason(root: str | os.PathLike[str]) -> str | None:
    """Причина, по которой большие заглушки на этом томе делать нельзя (``None`` — можно).

    Проверяет том, где pytest держит ``tmp_path``: именно там лежат заглушки.
    """
    probe = Path(root) / "citlali-sparse-probe.bin"
    try:
        make_sparse_file(probe, 8 * 1000**2)
    except (SparseNotSupported, OSError) as exc:
        return f"разреженные файлы не получились: {exc}"
    finally:
        probe.unlink(missing_ok=True)
    return None
