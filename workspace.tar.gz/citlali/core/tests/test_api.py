"""Сквозные тесты HTTP/SSE-контракта Core (T1.5, FR-1)."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

import pytest
from starlette.testclient import TestClient

from app.config import Config
from app.llm import LLMUnavailable
from app.main import SoulNotFoundError, _with_keepalive, create_app, load_soul
from tests.conftest import FakeLLM, read_sse


def events_of(response: Any) -> list[str]:
    return [name for name, _ in read_sse(response)]


def data_of(response: Any, event: str) -> list[dict[str, Any]]:
    return [data for name, data in read_sse(response) if name == event]


# ---------------------------------------------------------------- диагностика


def test_healthz(client: TestClient) -> None:
    resp = client.get("/healthz")
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "ok"
    assert body["soul_chars"] > 100, "характер должен быть загружен из SOUL.md"
    assert body["db_connected"] is True


def test_status_reports_llama_and_model(client: TestClient) -> None:
    body = client.get("/v1/status").json()
    assert body["core"] == "ok"
    assert body["llama"] == "ok"  # FakeLLM.healthy = True
    assert body["ctx_size"] == 8192
    assert body["model_exists"] is False


def test_openapi_is_not_exposed(client: TestClient) -> None:
    assert client.get("/openapi.json").status_code == 404


# ---------------------------------------------------------------------- чат


def test_chat_stream_event_sequence(client: TestClient) -> None:
    resp = client.post("/v1/chat", json={"message": "привет"})
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("text/event-stream")
    names = events_of(resp)
    assert names[0] == "meta"
    assert names[1] == "route"
    assert names[-1] == "done"
    assert "delta" in names


def test_chat_streams_text_pieces_in_order(client: TestClient) -> None:
    resp = client.post("/v1/chat", json={"message": "привет"})
    text = "".join(d["text"] for d in data_of(resp, "delta"))
    assert text == "Привет. Ну чего ты хотел?"


def test_chat_persists_dialogue(client: TestClient) -> None:
    resp = client.post("/v1/chat", json={"message": "привет"})
    session_id = data_of(resp, "meta")[0]["session_id"]
    messages = client.get(f"/v1/sessions/{session_id}/messages").json()
    assert [m["role"] for m in messages] == ["user", "assistant"]
    assert messages[0]["content"] == "привет"
    assert messages[1]["content"].startswith("Привет.")


def test_chat_continues_same_session(client: TestClient) -> None:
    first = client.post("/v1/chat", json={"message": "первое"})
    session_id = data_of(first, "meta")[0]["session_id"]
    second = client.post("/v1/chat", json={"message": "второе", "session_id": session_id})
    assert data_of(second, "meta")[0]["session_id"] == session_id

    messages = client.get(f"/v1/sessions/{session_id}/messages").json()
    assert [m["content"] for m in messages] == [
        "первое",
        "Привет. Ну чего ты хотел?",
        "второе",
        "Привет. Ну чего ты хотел?",
    ]


def test_chat_history_is_passed_to_model_without_current_message(
    app: Any, client: TestClient
) -> None:
    resp = client.post("/v1/chat", json={"message": "первое"})
    session_id = data_of(resp, "meta")[0]["session_id"]
    client.post("/v1/chat", json={"message": "второе", "session_id": session_id})

    llm: FakeLLM = app.state.llm
    sent = llm.last_messages
    assert [m["role"] for m in sent] == ["system", "user", "assistant", "user"]
    assert sent[-1]["content"] == "второе"
    assert sent[1]["content"] == "первое"
    assert llm.last_system.startswith("<soul>"), "характер — всегда первое сообщение"


def test_route_event_marks_command(client: TestClient) -> None:
    resp = client.post("/v1/chat", json={"message": "Ситлали, открой YouTube"})
    route = data_of(resp, "route")[0]
    assert route["kind"] == "command"
    assert route["matched"]


def test_facts_are_injected_into_system_prompt(app: Any, client: TestClient) -> None:
    client.post("/v1/facts", json={"key": "name", "value": "Marat"})
    client.post("/v1/chat", json={"message": "как меня зовут?"})
    llm: FakeLLM = app.state.llm
    system = llm.last_system
    assert "<facts>" in system
    assert "- name: Marat" in system


def test_metrics_are_reported_in_done(client: TestClient) -> None:
    resp = client.post("/v1/chat", json={"message": "привет"})
    done = data_of(resp, "done")[0]
    assert done["stop_reason"] == "stop"
    assert done["completion_tokens"] > 0
    assert done["ttft_ms"] >= 0
    assert done["truncated"] is False
    assert done["route_kind"] == "chat"


def test_empty_message_rejected(client: TestClient) -> None:
    assert client.post("/v1/chat", json={"message": ""}).status_code == 422


# ------------------------------------------------------------- регенерация


def test_regenerate_replaces_last_answer(app: Any, client: TestClient) -> None:
    resp = client.post("/v1/chat", json={"message": "привет"})
    session_id = data_of(resp, "meta")[0]["session_id"]
    app.state.llm.chunks = ["Другой ", "ответ"]

    regen = client.post(
        "/v1/chat", json={"message": "ignored", "session_id": session_id, "regenerate": True}
    )
    messages = client.get(f"/v1/sessions/{session_id}/messages").json()
    assert [m["role"] for m in messages] == ["user", "assistant"]
    assert messages[1]["content"] == "Другой ответ"
    assert events_of(regen)[-1] == "done"

    sent = app.state.llm.last_messages
    assert [m["role"] for m in sent] == ["system", "user"], (
        "старый ответ не должен попасть в промпт"
    )


# ------------------------------------------------------------------ ошибки


def test_llm_unavailable_yields_error_event(cfg: Config) -> None:
    app = create_app(cfg, llm=FakeLLM(error=LLMUnavailable("нет связи")))
    with TestClient(app) as client:
        resp = client.post("/v1/chat", json={"message": "привет"})
        names = events_of(resp)
        assert "error" in names
        assert "done" not in names
        err = data_of(resp, "error")[0]
        assert err["code"] == "llm_unavailable"
        assert err["retryable"] is True


def test_destructive_request_is_refused_and_logged(cfg: Config) -> None:
    app = create_app(cfg, llm=FakeLLM())
    with TestClient(app) as client:
        resp = client.post("/v1/chat", json={"message": "Удали всё в Downloads"})
        route = data_of(resp, "route")[0]
        assert route["kind"] == "command"
        assert route["destructive"] is True

        actions = client.get("/v1/actions").json()
        assert len(actions) == 1, "A-4: отказ обязан попасть в журнал"
        assert actions[0]["tool"] == "none"
        assert actions[0]["risk"] == "dangerous"
        assert actions[0]["reason"] == "destructive_not_in_v1"


# ----------------------------------------------------------------- сессии


def test_session_start_and_end(client: TestClient) -> None:
    sid = client.post("/v1/sessions", json={}).json()["session_id"]
    resp = client.post(f"/v1/sessions/{sid}/end")
    assert resp.status_code == 200
    assert client.post("/v1/sessions/нет-такой/end").status_code == 404


# ------------------------------------------------------------ факты/журнал


def test_facts_api_roundtrip(client: TestClient) -> None:
    assert client.get("/v1/facts").json() == []
    client.post("/v1/facts", json={"key": "likes", "value": "кофе", "confidence": 0.9})
    facts = client.get("/v1/facts").json()
    assert facts[0]["key"] == "likes"
    assert facts[0]["source"] == "user_explicit"
    assert client.post("/v1/facts", json={"key": "", "value": "x"}).status_code == 422


def test_actions_api_returns_journal(client: TestClient) -> None:
    client.post("/v1/chat", json={"message": "Удали всё"})
    actions = client.get("/v1/actions").json()
    assert actions and actions[0]["status"] == "pending"


def test_confirm_stub_updates_journal(client: TestClient) -> None:
    client.post("/v1/chat", json={"message": "Удали всё"})
    request_id = client.get("/v1/actions").json()[0]["id"]
    resp = client.post("/v1/confirm", json={"request_id": request_id, "approved": False})
    assert resp.status_code == 200
    assert client.get("/v1/actions").json()[0]["status"] == "denied"
    assert client.post("/v1/confirm", json={"request_id": "x", "approved": True}).status_code == 404


# -------------------------------------------------------------- авторизация


def test_token_required_when_configured(cfg: Config) -> None:
    cfg.core.api_token = "sekret"
    app = create_app(cfg, llm=FakeLLM())
    with TestClient(app) as client:
        assert client.post("/v1/chat", json={"message": "привет"}).status_code == 401
        assert client.get("/v1/status").status_code == 401
        assert client.get("/healthz").status_code == 200, "healthz доступен для watchdog"

        ok = client.post(
            "/v1/chat",
            json={"message": "привет"},
            headers={"X-Citlali-Token": "sekret"},
        )
        assert ok.status_code == 200


def test_public_config_hides_token(cfg: Config) -> None:
    cfg.core.api_token = "sekret"
    app = create_app(cfg, llm=FakeLLM())
    with TestClient(app) as client:
        assert client.get("/v1/config/public").status_code == 401
        body = client.get("/v1/config/public", headers={"X-Citlali-Token": "sekret"}).json()
        assert "api_token" not in body["core"]
        assert body["llama"]["ctx_size"] == 8192


# ------------------------------------------------------------------ stop


def test_stop_without_active_stream_is_noop(client: TestClient) -> None:
    resp = client.delete("/v1/stop/несуществующая")
    assert resp.status_code == 200
    assert resp.json()["stopped"] is False


async def test_keepalive_emits_ping_on_silence() -> None:
    """HITL-ожидание может длиться минуты — поток не должен молча умирать."""

    async def slow() -> Any:
        await asyncio.sleep(0.05)
        yield "event: done\ndata: {}\n\n"

    got = [chunk async for chunk in _with_keepalive(slow(), interval_s=0.01)]
    assert any("ping" in chunk for chunk in got), "ожидаются keep-alive-события"
    assert got[-1].startswith("event: done")


# --------------------------------------------------- SOUL.md обязателен (fatal)


def test_missing_soul_is_fatal(cfg: Config) -> None:
    """Регрессия: ядро молча работало на заглушке характера.

    Относительный ``soul_file`` разрешился от ``%APPDATA%/Citlali``, файл не
    нашёлся — и приложение выглядело рабочим, не имея личности. Теперь это
    ошибка запуска, а не предупреждение в логе.
    """
    cfg.paths.soul_file = "soul/НЕТ-ТАКОГО-ФАЙЛА.md"
    with pytest.raises(SoulNotFoundError, match=r"SOUL\.md не найден"):
        create_app(cfg, llm=FakeLLM())


def test_empty_soul_is_fatal(cfg: Config, app_dir: Path) -> None:
    empty = app_dir / "soul" / "empty.md"
    empty.write_text("   \n  ", encoding="utf-8")
    cfg.paths.soul_file = str(empty)
    with pytest.raises(SoulNotFoundError, match=r"пуст"):
        create_app(cfg, llm=FakeLLM())


def test_load_soul_error_message_tells_how_to_fix(cfg: Config) -> None:
    cfg.paths.soul_file = "soul/missing.md"
    with pytest.raises(SoulNotFoundError) as exc:
        load_soul(cfg.soul_path)
    msg = str(exc.value)
    assert "setup_config.ps1" in msg, "сообщение обязано подсказывать способ починки"
    assert "soul_file" in msg


def test_soul_within_budget(cfg: Config) -> None:
    from app.main import SOUL_MAX_CHARS

    text = load_soul(cfg.soul_path)
    assert 0 < len(text) <= SOUL_MAX_CHARS
