"""Тесты замера NFR (`scripts/bench.py`).

Замер — единственный источник правды для таблицы в `docs/design.md` §9,
поэтому проверяем три вещи:

1. диагностика говорит, КАКОЕ окно не запущено (оператор дважды получал
   безличный ``ConnectError`` и подсказку «нужно три окна», хотя закрыто
   было только одно — A-27);
2. агрегация медиан/перцентилей не врёт на граничных случаях;
3. разбор ``tasklist`` считает именно мегабайты и суммирует одноимённые процессы.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "scripts"))

from bench import (
    NFR_RAM_MB,
    NFR_TPS,
    NFR_TTFT_MS,
    diagnose,
    parse_tasklist_csv,
    percentile,
)

# ------------------------------------------------------------ диагностика


def test_both_alive_no_hints() -> None:
    ok, lines = diagnose(llama_ok=True, core_ok=True)
    assert ok is True
    assert lines == [], "при живых сервисах подсказки не нужны"


def test_both_dead_names_both_windows() -> None:
    ok, lines = diagnose(llama_ok=False, core_ok=False)
    assert ok is False
    text = "\n".join(lines)
    assert "run_llama.cmd" in text
    assert "run_core.cmd" in text
    assert "bench.cmd" in text


def test_only_llama_dead_points_to_window_a() -> None:
    """Регрессия 19.10: закрыто было окно ядра, а подсказка была общей."""
    ok, lines = diagnose(llama_ok=False, core_ok=True)
    assert ok is False
    text = "\n".join(lines)
    assert "run_llama.cmd" in text
    assert "run_core.cmd" not in text, "не виноватое окно называть нельзя"
    assert "8080" in text


def test_only_core_dead_points_to_window_b() -> None:
    ok, lines = diagnose(llama_ok=True, core_ok=False)
    assert ok is False
    text = "\n".join(lines)
    assert "run_core.cmd" in text
    assert "run_llama.cmd" not in text
    assert "8787" in text
    assert "Ctrl+C" in text, "оператор закрывал ядро именно так — надо это назвать"


@pytest.mark.parametrize("llama_ok", [True, False])
def test_any_failure_reminds_about_three_windows(llama_ok: bool) -> None:
    _, lines = diagnose(llama_ok=llama_ok, core_ok=False)
    assert any("окно C" in line for line in lines)


# ------------------------------------------------------------ статистика


def test_percentile_bounds() -> None:
    assert percentile([], 95) == 0.0
    assert percentile([5.0], 95) == 5.0
    assert percentile([1.0, 2.0, 3.0], 0) == 1.0
    assert percentile([1.0, 2.0, 3.0], 100) == 3.0


def test_percentile_p95_on_seven_runs() -> None:
    """Реальный прогон оператора: 6 тёплых ~110 ms и один холодный 1386 ms."""
    ttft = [1386.0, 118.0, 113.0, 109.0, 111.0, 113.0, 110.0]
    assert percentile(ttft, 95) == 1386.0
    assert sorted(ttft)[len(ttft) // 2] == 113.0


def test_nfr_limits_match_spec() -> None:
    """Лимиты обязаны совпадать с docs/spec.md §6, иначе PASS ничего не значит."""
    assert NFR_TTFT_MS == 3000.0
    assert NFR_TPS == 25.0
    assert NFR_RAM_MB == 1024.0


def test_measured_run_passes_limits() -> None:
    """Факт 19.10.2026 (Qwen3.5-9B, контекст 8192, -ngl 99): все три порога закрыты."""
    measured = {"ttft_median_ms": 113.0, "tps_median": 44.7, "core_ui_mb": 104.9}
    assert measured["ttft_median_ms"] < NFR_TTFT_MS
    assert measured["tps_median"] >= NFR_TPS
    assert measured["core_ui_mb"] <= NFR_RAM_MB


# ------------------------------------------------------------ tasklist

TASKLIST = "\n".join(
    [
        '"System Idle Process","0","Services","0","8 K"',
        '"python.exe","23980","Console","1","104 928 K"',
        '"llama-server.exe","7028","Console","1","5 566 700 K"',
        '"python.exe","31337","Console","1","20 480 K"',
        '"Citlali.exe","4242","Console","1","123 456 K"',
    ]
)


def test_parse_tasklist_filters_and_sums() -> None:
    got = parse_tasklist_csv(TASKLIST, ("citlali", "python", "llama-server"))
    assert got["python.exe"] == pytest.approx(122.5, abs=0.1), "одноимённые процессы суммируются"
    assert got["llama-server.exe"] == pytest.approx(5436.2, abs=0.5)
    assert got["citlali.exe"] == pytest.approx(120.6, abs=0.1)
    assert "system idle process" not in got


def test_parse_tasklist_core_excludes_model() -> None:
    """Core+UI = всё, кроме llama-server: так считал bench у оператора."""
    got = parse_tasklist_csv(TASKLIST, ("citlali", "python", "llama-server"))
    core = sum(v for k, v in got.items() if not k.startswith("llama-server"))
    assert core == pytest.approx(243.1, abs=0.5)


def test_parse_tasklist_ignores_garbage() -> None:
    assert parse_tasklist_csv("", ("python",)) == {}
    assert parse_tasklist_csv("мусор без колонок", ("python",)) == {}
    assert parse_tasklist_csv('"python.exe","1","Console","1","N/A"', ("python",)) == {}
