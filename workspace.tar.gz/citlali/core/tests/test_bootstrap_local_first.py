"""Интеграционный тест A-27: bootstrap ищет модели на диске ДО обращения к сети.

Регрессия 19.10.2026: модели перенесли в `C:\\citlali-models` (A-26), а
`01_bootstrap.ps1` искал GGUF только в `models\\` внутри проекта. Своих же файлов
он не увидел и начал качать 9 GB заново; два обрыва curl оставили ~7 GB мусора.

Тест запускает настоящий PowerShell (проба `core/tests/ps/find_local_model_probe.ps1`
вытаскивает из скрипта только функции, поэтому ничего не скачивается и не удаляется)
на разреженных файлах: размер у них настоящий, места на диске они не занимают.

Разреженность — не пожелание, а требование (ловушка 25): один прогон создаёт
заглушки на ~24 GB логического объёма, а pytest хранит последние прогоны в
`%TEMP%\\pytest-of-<user>`. `fh.truncate()` на NTFS место **выделяет**, поэтому
20.10.2026 у оператора в Temp лежало 63.5 GB наших же «бесплатных» GGUF.
Теперь заглушки делает `tests/sparsefile.py`, а если разреженные файлы на томе
не получаются, тесты пропускаются вместо того, чтобы заполнить диск.

Если PowerShell в системе нет (CI на Linux), тест пропускается — статические
гарантии живут в `test_scripts_env.py::test_bootstrap_checks_disk_before_network`.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

from tests.sparsefile import make_sparse_file, sparse_unavailable_reason
from tests.test_doctor_report import decode_console

REPO = Path(__file__).resolve().parents[2]
PROBE = Path(__file__).resolve().parent / "ps" / "find_local_model_probe.ps1"
SPECS = json.loads((REPO / "scripts" / "bootstrap.json").read_text(encoding="utf-8"))["models"]
BY_NAME = {str(s["name"]): s for s in SPECS}
# Заглушки создаются во временном каталоге pytest — его том и проверяем.
_TMP_ROOT = Path(os.environ.get("PYTEST_DEBUG_TEMPROOT") or os.environ.get("TEMP") or "/tmp")
_SPARSE_REASON = sparse_unavailable_reason(_TMP_ROOT)


def powershell_exe() -> str | None:
    for name in ("pwsh", "powershell"):
        found = shutil.which(name)
        if found:
            return found
    return None


PS = powershell_exe()

pytestmark = [
    pytest.mark.skipif(PS is None, reason="нет PowerShell — интеграционный тест пропускается"),
    pytest.mark.skipif(
        _SPARSE_REASON is not None,
        reason=f"большие заглушки заняли бы десятки GB на диске: {_SPARSE_REASON}",
    ),
]


def norm(path: str) -> str:
    return os.path.normpath(str(path)).replace("\\", "/").casefold()


def make_file(path: Path, size: int) -> Path:
    """Разреженный файл нужного размера: настоящий `Length`, ноль байт на диске.

    Только через `tests.sparsefile`: на NTFS `truncate` выделяет место целиком
    (ловушка 25), и «бесплатная» заглушка стоила оператору 63.5 GB в Temp.
    """
    return make_sparse_file(path, size)


def run_probe(root: Path, models_dir: str | None) -> dict[str, dict[str, str]]:
    env = dict(os.environ)
    if models_dir is None:
        env.pop("CITLALI_MODELS_DIR", None)
    else:
        env["CITLALI_MODELS_DIR"] = models_dir
    proc = subprocess.run(
        [
            PS,
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(PROBE),
            "-Root",
            str(root),
            "-Repo",
            str(REPO),
        ],
        capture_output=True,
        timeout=180,
        env=env,
        check=False,
    )
    # A-31: вывод PowerShell берём байтами. Сама проба печатает ASCII, но её
    # stderr на Windows приходит в OEM-кодировке — в текстовом режиме subprocess
    # превращал его в труху ровно тогда, когда его читают (в сообщении о падении).
    stdout = decode_console(proc.stdout)
    stderr = decode_console(proc.stderr)
    lines = [line.strip() for line in stdout.splitlines() if line.strip()]
    assert proc.returncode == 0, (
        f"проба не запустилась: rc={proc.returncode}\nSTDOUT:\n{stdout}\nSTDERR:\n{stderr}"
    )
    out: dict[str, dict[str, str]] = {"_dirs": {"list": lines[0].split("|")[1:]}}
    for line in lines[1:]:
        parts = line.split("|")
        if parts[0] == "HIT":
            out[parts[1]] = {"status": "HIT", "path": parts[2], "expected": parts[3]}
        elif parts[0] == "MISS":
            out[parts[1]] = {"status": "MISS", "expected": parts[2]}
        elif parts[0] == "ERR":
            pytest.fail(f"проба сообщила об ошибке: {line}")
    return out


def test_probe_file_exists_and_is_ascii() -> None:
    data = PROBE.read_bytes()
    assert data, "проба пуста"
    assert all(b < 128 for b in data), (
        "проба обязана быть ASCII: её читает и PowerShell 5.1, и pwsh 7"
    )


def test_complete_model_outside_repo_is_found(tmp_path: Path) -> None:
    """Главная регрессия A-27: полный файл снаружи находится без сети."""
    outside = tmp_path / "citlali-models"
    project = tmp_path / "project"
    spec = BY_NAME["qwen3.5-9b"]
    make_file(outside / str(spec["file"]), int(spec["size_bytes"]))

    got = run_probe(project, str(outside))

    assert got["qwen3.5-9b"]["status"] == "HIT", "модель во внешнем каталоге не найдена"
    assert norm(got["qwen3.5-9b"]["path"]) == norm(str(outside / str(spec["file"])))
    assert got["qwen3-14b"]["status"] == "MISS"
    assert got["qwen3-8b"]["status"] == "MISS"


def test_partial_file_is_not_accepted_as_complete(tmp_path: Path) -> None:
    """7.7 GB из 9.0 GB — это не модель: её надо докачивать, а не пропускать."""
    outside = tmp_path / "citlali-models"
    project = tmp_path / "project"
    spec = BY_NAME["qwen3-14b"]
    make_file(project / "models" / str(spec["file"]), int(spec["size_bytes"]) - 1_300_000_000)

    got = run_probe(project, str(outside))

    assert got["qwen3-14b"]["status"] == "MISS", "недокачанный файл принят за полный"


def test_complete_file_in_repo_models_also_found(tmp_path: Path) -> None:
    """Без внешнего каталога поведение прежнее: ищем в models\\ внутри проекта."""
    project = tmp_path / "project"
    spec = BY_NAME["qwen3-8b"]
    make_file(project / "models" / str(spec["file"]), int(spec["size_bytes"]))

    got = run_probe(project, str(tmp_path / "citlali-models"))

    assert got["qwen3-8b"]["status"] == "HIT"
    assert norm(got["qwen3-8b"]["path"]) == norm(str(project / "models" / str(spec["file"])))


def test_external_dir_is_checked_first(tmp_path: Path) -> None:
    """Порядок каталогов: внешний (A-26), затем models\\ внутри проекта."""
    outside = tmp_path / "citlali-models"
    project = tmp_path / "project"
    (project / "models").mkdir(parents=True)

    got = run_probe(project, str(outside))
    dirs = [norm(d) for d in got["_dirs"]["list"]]

    assert dirs[0] == norm(str(outside)), "внешний каталог обязан быть первым"
    assert dirs[-1] == norm(str(project / "models")), "models\\ внутри проекта — последний fallback"


def test_same_name_full_copy_wins_over_partial(tmp_path: Path) -> None:
    """Копия снаружи полная, в проекте осталась недокачанная — берём полную."""
    outside = tmp_path / "citlali-models"
    project = tmp_path / "project"
    spec = BY_NAME["qwen3.5-9b"]
    size = int(spec["size_bytes"])
    make_file(outside / str(spec["file"]), size)
    make_file(project / "models" / str(spec["file"]), size - 1000)

    got = run_probe(project, str(outside))

    assert got["qwen3.5-9b"]["status"] == "HIT"
    assert norm(got["qwen3.5-9b"]["path"]) == norm(str(outside / str(spec["file"])))


@pytest.mark.skipif(sys.platform != "win32", reason="про setx-поведение говорим только на Windows")
def test_probe_does_not_touch_network(tmp_path: Path) -> None:
    """Проба обязана завершаться быстро: значит, к HF она не ходила.

    Загрузка списка файлов с HF занимает секунды даже при живом интернете,
    а локальная сверка — десятки миллисекунд. Порог намеренно щедрый.
    """
    import time

    project = tmp_path / "project"
    started = time.perf_counter()
    run_probe(project, str(tmp_path / "citlali-models"))
    elapsed = time.perf_counter() - started
    assert elapsed < 30.0, f"проба шла {elapsed:.1f} с — похоже на обращение к сети"
