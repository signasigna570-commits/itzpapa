"""Тесты конфигурации (T0.4, T1.1): дефолты, TOML-оверрайды, env, пути."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from app.config import (
    Config,
    ConfigError,
    expand_path,
    to_toml,
)


def test_defaults_are_loopback_and_safe() -> None:
    cfg = Config()
    assert cfg.core.host == "127.0.0.1", "A-12: наружу не слушаем"
    assert cfg.llama.host == "127.0.0.1"
    assert cfg.core.port == 8787
    assert cfg.llama.port == 8080
    assert cfg.llama.ctx_size == 8192
    assert cfg.llm.thinking is False, "A-11: /no_think по умолчанию"
    assert cfg.tools.max_steps == 5
    assert cfg.memory.history_max_messages == 20


def test_expand_path_uses_env_and_normalises(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("CITLALI_TEST_ROOT", str(Path("/tmp") / "root"))
    p = expand_path("%CITLALI_TEST_ROOT%/models/../models/x.gguf")
    assert p == Path("/tmp/root/models/x.gguf")


def test_expand_path_user_home(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    assert expand_path("~/x") == tmp_path / "x"


def test_app_dir_and_relative_paths_resolved_from_app_dir(cfg: Config, app_dir: Path) -> None:
    assert cfg.app_dir == app_dir
    assert cfg.db_path == app_dir / "citlali-test.db"
    assert cfg.soul_path == app_dir / "soul" / "SOUL.md"
    # абсолютный путь не переклеивается
    cfg.paths.model_file = str(app_dir / "m.gguf")
    assert cfg.model_path == app_dir / "m.gguf"


def test_load_from_toml_overrides_only_given_keys(tmp_path: Path, cfg: Config) -> None:
    toml_file = tmp_path / "config.toml"
    toml_file.write_text(
        """
[llama]
port = 8099
ctx_size = 4096

[memory]
history_max_messages = 6

[tools]
url_whitelist = ["example.com"]
""",
        encoding="utf-8",
    )
    loaded = Config.load(toml_file, env=False)
    assert loaded.llama.port == 8099
    assert loaded.llama.ctx_size == 4096
    assert loaded.memory.history_max_messages == 6
    assert loaded.tools.url_whitelist == ["example.com"]
    # не указанные ключи остались дефолтными
    assert loaded.core.port == cfg.core.port
    assert loaded.llama.ngl == 99
    assert "Get-Date" in loaded.tools.ps_whitelist


def test_load_missing_file_returns_defaults(tmp_path: Path) -> None:
    loaded = Config.load(tmp_path / "nope.toml", env=False)
    assert loaded == Config()


def test_absolute_windows_soul_path_from_toml(tmp_path: Path) -> None:
    """Регрессия: run_core.cmd/setup_config.ps1 пишут в конфиг абсолютный путь.

    Он содержит удвоенные обратные слэши и не должен резолвиться относительно
    ``app_dir`` — иначе ядро молча переключается на заглушку характера.
    """
    toml_file = tmp_path / "config.toml"
    toml_file.write_text(
        "[paths]" + "\n" + r'soul_file = "C:\\repo\\citlali\\soul\\SOUL.md"' + "\n",
        encoding="utf-8",
    )
    loaded = Config.load(toml_file, env=False)
    # TOML развернул '\\\\' → '\\', путь остался как задан
    assert loaded.paths.soul_file == r"C:\repo\citlali\soul\SOUL.md"
    # главное: путь НЕ приклеился к app_dir (баг, из-за которого характер
    # молча переключался на заглушку) — проверяем на любой ОС
    assert str(loaded.soul_path) == r"C:\repo\citlali\soul\SOUL.md"
    if os.name == "nt":
        assert loaded.soul_path.is_absolute()
        assert loaded.soul_path.name == "SOUL.md"


def test_env_override_with_type_coercion(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("CITLALI_LLAMA__PORT", "8091")
    monkeypatch.setenv("CITLALI_LLAMA__FLASH_ATTN", "false")
    monkeypatch.setenv("CITLALI_MEMORY__HISTORY_TOKEN_BUDGET", "1000")
    loaded = Config.load(tmp_path / "nope.toml", env=True)
    assert loaded.llama.port == 8091
    assert isinstance(loaded.llama.port, int)
    assert loaded.llama.flash_attn is False
    assert loaded.memory.history_token_budget == 1000


def test_env_override_ignores_unknown_sections(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("CITLALI_NOSUCH__KEY", "1")
    monkeypatch.setenv("CITLALI_MALFORMED", "1")
    loaded = Config.load(tmp_path / "nope.toml", env=True)  # не должно упасть
    assert loaded.core.port == 8787


def test_unknown_toml_keys_are_ignored(tmp_path: Path) -> None:
    toml_file = tmp_path / "config.toml"
    toml_file.write_text("[core]\nport = 9000\nfuture_field = 'x'\n", encoding="utf-8")
    loaded = Config.load(toml_file, env=False)
    assert loaded.core.port == 9000


def test_to_toml_roundtrip(tmp_path: Path) -> None:
    cfg = Config()
    text = to_toml(cfg)
    toml_file = tmp_path / "generated.toml"
    toml_file.write_text(text, encoding="utf-8")
    reloaded = Config.load(toml_file, env=False)
    assert reloaded == cfg, "сгенерированный config.toml должен читаться обратно без потерь"


def test_to_toml_escapes_windows_paths() -> None:
    cfg = Config()
    cfg.paths.data_dir = r"C:\Users\Test\AppData\Roaming\Citlali"
    text = to_toml(cfg)
    assert r"C:\\Users\\Test" in text


def test_invalid_port_type_raises_config_error(tmp_path: Path) -> None:
    toml_file = tmp_path / "bad.toml"
    toml_file.write_text("[core]\nport = 'не-число'\n", encoding="utf-8")
    with pytest.raises(ConfigError):
        Config.load(toml_file, env=False)


def test_unexpanded_env_var_in_path_is_a_loud_error(monkeypatch: pytest.MonkeyPatch) -> None:
    """Регрессия: каталог с именем ``%APPDATA%\\Citlali`` создаваться не должен.

    Если переменная не задана в этой ОС — падаем с внятной ConfigError,
    а не тихо пишем данные в каталог-мусор.
    """
    monkeypatch.delenv("CITLALI_NOPE", raising=False)
    with pytest.raises(ConfigError, match="CITLALI_NOPE"):
        expand_path(r"%CITLALI_NOPE%\Citlali\x.db")


def test_data_dir_default_is_os_aware() -> None:
    from app.config import default_data_dir

    value = default_data_dir()
    if os.name == "nt":
        assert value == r"%APPDATA%\Citlali"
    else:
        assert value == "~/.local/share/Citlali"
        assert expand_path(value).is_absolute()


def test_config_load_propagates_path_error(tmp_path: Path) -> None:
    toml_file = tmp_path / "config.toml"
    toml_file.write_text(
        "[paths]" + "\n" + r'model_file = "%NO_SUCH_VAR%\\m.gguf"' + "\n", encoding="utf-8"
    )
    loaded = Config.load(toml_file, env=False)
    with pytest.raises(ConfigError):
        _ = loaded.model_path


def test_default_config_path_is_os_aware(monkeypatch: pytest.MonkeyPatch) -> None:
    from app.config import default_config_path

    monkeypatch.delenv("CITLALI_CONFIG", raising=False)
    p = default_config_path()
    assert p.name == "config.toml"
    assert "%" not in str(p), "нераскрытая переменная окружения в пути недопустима"


def test_explicit_citlali_config_env_wins(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    from app.config import default_config_path

    target = tmp_path / "custom.toml"
    monkeypatch.setenv("CITLALI_CONFIG", str(target))
    assert default_config_path() == target


def test_forward_slash_windows_path_is_normalised() -> None:
    """`setup_config.ps1` пишет пути в TOML прямыми слэшами — без экранирования.

    На Windows ``expand_path`` обязан привести ``C:/dev/x`` к ``C:\\dev\\x``,
    иначе путь уедет в llama-server в чуждом ему виде. Тестируем чистую функцию:
    ``monkeypatch.setattr(os, "name", "nt")`` ломает сам pytest (pathlib не
    создаёт WindowsPath на чужой ОС).
    """
    from app.config import normalize_windows_separators

    assert normalize_windows_separators("C:/dev/citlali/soul/SOUL.md") == (
        "C:\\dev\\citlali\\soul\\SOUL.md"
    )


def test_normalise_leaves_posix_paths_alone() -> None:
    """POSIX-путь (dev/CI) трогать нельзя, иначе сломаются тесты на Linux."""
    from app.config import normalize_windows_separators

    assert normalize_windows_separators("/tmp/citlali/soul/SOUL.md") == "/tmp/citlali/soul/SOUL.md"
    assert normalize_windows_separators("soul/SOUL.md") == "soul/SOUL.md"


def test_doubled_backslash_windows_path_survives() -> None:
    """Старые конфиги с TOML-экранированием: tomllib уже развернул, путь не ломаем."""
    from app.config import normalize_windows_separators

    path = "C:\\dev\\citlali\\soul\\SOUL.md"
    assert normalize_windows_separators(path) == path


def test_config_with_forward_slash_windows_path(tmp_path: Path) -> None:
    """Конфиг, записанный setup_config.ps1, читается и даёт абсолютный путь."""
    toml_file = tmp_path / "config.toml"
    toml_file.write_text(
        "[paths]" + "\n" + 'soul_file = "C:/dev/citlali/soul/SOUL.md"' + "\n",
        encoding="utf-8",
    )
    loaded = Config.load(toml_file, env=False)
    assert loaded.paths.soul_file == "C:/dev/citlali/soul/SOUL.md"
    if os.name == "nt":
        # Windows: '/' приводится к '\' (normalize_windows_separators)
        assert str(loaded.soul_path) == "C:\\dev\\citlali\\soul\\SOUL.md"
        assert loaded.soul_path.is_absolute()
    else:
        # dev/CI: путь остаётся как записан, главное — не приклеен к app_dir
        assert str(loaded.soul_path) == "C:/dev/citlali/soul/SOUL.md"
    assert not str(loaded.soul_path).startswith(str(loaded.app_dir))


# ------------------------------------------------------- A-20: каталог данных


def test_template_has_no_data_dir() -> None:
    """`config.default.toml` обязан быть межплатформенным.

    Реальный дефект: шаблон, сгенерированный в Linux, унёс
    ``~/.local/share/Citlali`` на Windows, и ядро создало базу в
    ``C:\\Users\\...\\.local\\share\\Citlali`` вместо ``%APPDATA%\\Citlali``.
    """
    template = Path(__file__).resolve().parents[1] / "config.default.toml"
    keys = [
        line.split("=")[0].strip()
        for line in template.read_text(encoding="utf-8").splitlines()
        if "=" in line and not line.lstrip().startswith("#")
    ]
    assert "data_dir" not in keys, (
        "в config.default.toml не должно быть КЛЮЧА data_dir (в комментариях можно): "
        "значение вычисляется в рантайме на машине запуска"
    )
    # шаблон обязан читаться нашей же Config, и data_dir после чтения — пустой
    loaded = Config.load(template, env=False)
    assert loaded.paths.data_dir == "", "после чтения шаблона data_dir обязан быть пустым"


def test_data_dir_default_is_empty_and_resolves_at_runtime() -> None:
    cfg = Config()
    assert cfg.paths.data_dir == ""
    resolved = str(cfg.app_dir)
    if os.name == "nt":
        assert "AppData" in resolved, resolved
    assert not resolved.startswith("~"), "tilde обязан раскрываться"


def test_foreign_data_dir_is_dropped_on_windows(monkeypatch: pytest.MonkeyPatch) -> None:
    """Значение из чужой ОС не должно управлять расположением данных."""
    from app.config import PathsCfg, default_data_dir

    if os.name == "nt":
        assert PathsCfg(data_dir="~/.local/share/Citlali").data_dir == ""
        assert PathsCfg(data_dir="/tmp/citlali").data_dir == ""
        assert PathsCfg(data_dir=r"%APPDATA%\Citlali").data_dir != ""
    else:
        # на Linux POSIX-пути законны, а вот Windows-путь — чужой
        assert PathsCfg(data_dir="/tmp/citlali").data_dir == "/tmp/citlali"
        assert PathsCfg(data_dir=r"C:\Users\x\AppData").data_dir == ""
    assert default_data_dir()


def test_explicit_data_dir_still_wins(cfg: Config, app_dir: Path) -> None:
    """Явно заданный каталог (например, другой диск) важнее дефолта."""
    cfg.paths.data_dir = str(app_dir)
    assert cfg.app_dir == app_dir


def test_tilde_expands_even_without_home_env(monkeypatch: pytest.MonkeyPatch) -> None:
    from app.config import expand_path

    monkeypatch.delenv("HOME", raising=False)
    monkeypatch.delenv("USERPROFILE", raising=False)
    monkeypatch.setenv("HOMEDRIVE", "C:")
    monkeypatch.setenv("HOMEPATH", "\\Users\\Test")
    out = str(expand_path("~/x"))
    assert not out.startswith("~"), f"tilde не раскрылся: {out}"
