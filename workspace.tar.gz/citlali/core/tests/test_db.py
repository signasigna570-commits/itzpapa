"""Тесты SQLite-слоя (T1.4): сессии, сообщения, факты, журнал действий."""

from __future__ import annotations

import json
import sqlite3

import pytest

from app.db import DB, SCHEMA_VERSION
from app.prompt import Msg


async def test_schema_version_pragma(db: DB) -> None:
    async with db.conn.execute("PRAGMA user_version") as cur:
        row = await cur.fetchone()
    assert int(row[0]) == SCHEMA_VERSION


async def test_session_lifecycle(db: DB) -> None:
    sid = await db.create_session()
    session = await db.get_session(sid)
    assert session is not None
    assert session["ended_at"] is None
    await db.end_session(sid, summary="говорили о модели")
    session = await db.get_session(sid)
    assert session["ended_at"] is not None
    assert session["summary"] == "говорили о модели"


async def test_ensure_session_is_idempotent(db: DB) -> None:
    sid = await db.ensure_session(None)
    assert await db.ensure_session(sid) == sid
    assert await db.ensure_session("несуществующая") == "несуществующая"
    assert await db.get_session("несуществующая") is not None


async def test_messages_roundtrip_and_order(db: DB) -> None:
    sid = await db.create_session()
    await db.append_message(sid, "user", "привет")
    await db.append_message(sid, "assistant", "ну привет")
    rows = await db.get_messages(sid)
    assert [r["role"] for r in rows] == ["user", "assistant"]
    assert [r["content"] for r in rows] == ["привет", "ну привет"]


async def test_messages_limit_returns_last_n_in_chronological_order(db: DB) -> None:
    sid = await db.create_session()
    for i in range(6):
        await db.append_message(sid, "user", f"m{i}")
    rows = await db.get_messages(sid, limit=3)
    assert [r["content"] for r in rows] == ["m3", "m4", "m5"]


async def test_history_for_prompt_excludes_current_user_message(db: DB) -> None:
    sid = await db.create_session()
    await db.append_message(sid, "user", "старое")
    await db.append_message(sid, "assistant", "старый ответ")
    await db.append_message(sid, "user", "текущее")
    history = await db.history_for_prompt(sid)
    assert [m.content for m in history] == ["старое", "старый ответ"]
    assert all(isinstance(m, Msg) for m in history)


async def test_delete_trailing_assistant_for_regenerate(db: DB) -> None:
    sid = await db.create_session()
    await db.append_message(sid, "user", "вопрос")
    await db.append_message(sid, "assistant", "плохой ответ")
    assert await db.delete_trailing_assistant(sid) == 1
    assert await db.message_count(sid) == 1
    assert await db.delete_trailing_assistant(sid) == 0, "повторно удалять нечего"


async def test_facts_upsert_replaces_value(db: DB) -> None:
    await db.upsert_fact("name", "Marat")
    await db.upsert_fact("name", "Марат")
    facts = await db.top_facts()
    assert len(facts) == 1
    assert facts[0].value == "Марат"
    assert await db.fact_count() == 1


async def test_facts_ordering_explicit_first_then_recent(db: DB) -> None:
    await db.upsert_fact("old_explicit", "1", source="user_explicit")
    await db.upsert_fact("extracted", "2", source="llm_extracted")
    await db.upsert_fact("new_explicit", "3", source="user_explicit")
    keys = [f.key for f in await db.top_facts(limit=12)]
    assert keys.index("old_explicit") < keys.index("extracted")
    assert keys.index("new_explicit") < keys.index("extracted")


async def test_top_facts_respects_limit(db: DB) -> None:
    for i in range(10):
        await db.upsert_fact(f"k{i}", f"v{i}")
    assert len(await db.top_facts(limit=3)) == 3


async def test_upsert_facts_skips_incomplete_entries(db: DB) -> None:
    saved = await db.upsert_facts(
        [
            {"key": "name", "value": "Marat"},
            {"key": "", "value": "мусор"},
            {"key": "empty", "value": "  "},
            {"key": "gpu", "value": "RTX 3060", "source": "llm_extracted", "confidence": 0.6},
        ]
    )
    assert saved == 2
    assert await db.fact_count() == 2


async def test_action_lifecycle_pending_to_ok(db: DB) -> None:
    sid = await db.create_session()
    aid = await db.start_action(
        tool="open_url",
        args={"url": "https://youtube.com"},
        risk="whitelisted",
        session_id=sid,
    )
    action = await db.get_action(aid)
    assert action is not None
    assert action["status"] == "pending", "журнал пишется ДО исполнения (AGENTS.md §5)"
    assert json.loads(action["args_json"]) == {"url": "https://youtube.com"}

    await db.set_action_status(aid, "ok", result="opened", duration_ms=42)
    action = await db.get_action(aid)
    assert action["status"] == "ok"
    assert action["result"] == "opened"
    assert action["duration_ms"] == 42


async def test_action_denied_and_refused_states(db: DB) -> None:
    aid = await db.start_action(
        tool="none", args={}, risk="dangerous", reason="destructive_not_in_v1"
    )
    await db.set_action_status(aid, "denied", error="оператор отказал")
    action = await db.get_action(aid)
    assert action["status"] == "denied"
    assert action["reason"] == "destructive_not_in_v1"


async def test_action_risk_is_constrained(db: DB) -> None:
    """CHECK-констрейнт схемы не пускает в журнал выдуманные уровни риска."""
    with pytest.raises(sqlite3.IntegrityError):
        await db.start_action(tool="x", args={}, risk="не-из-списка")


async def test_get_actions_returns_newest_first(db: DB) -> None:
    for i in range(3):
        await db.start_action(tool=f"t{i}", args={"i": i}, risk="safe")
    actions = await db.get_actions(limit=10)
    assert len(actions) == 3
    assert actions[0]["tool"] == "t2"


async def test_db_requires_connect_before_use(tmp_path) -> None:
    handle = DB(tmp_path / "x.db")
    with pytest.raises(RuntimeError, match="не подключена"):
        _ = handle.conn


async def test_recent_summaries_exclude_current_session(db: DB) -> None:
    a = await db.create_session()
    b = await db.create_session()
    await db.end_session(a, summary="саммари A")
    await db.end_session(b, summary="саммари B")
    assert await db.recent_summaries(exclude=b) == ["саммари A"]
    assert len(await db.recent_summaries()) == 2
