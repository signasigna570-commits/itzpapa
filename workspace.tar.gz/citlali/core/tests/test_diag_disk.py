"""`diag_disk`: диагностика диска смотрит, но не лечит руками (T0.34).

19.10.2026 у оператора кончилось место на C: — pytest оборвался на
``OSError: [Errno 28] No space left on device``, а десятки F/E в прогоне
были следствием, а не причиной: тестам некуда писать временные файлы.
Старый ``diag_disk.cmd`` (T0.23) искал только GGUF и каталог проекта и у
оператора ни разу не запускался; главные подозреваемые — ``Windows.old``,
``hiberfil.sys``/``pagefile.sys``, кэш Windows Update, дампы, ``Downloads``
и кэши AppData — в него не входили вообще.

Правила, которые фиксируют тесты ниже:
1. ``diag_disk`` — пара ``.cmd``-обёртка + ``.ps1`` (A-26), запуск только с
   ``-ExecutionPolicy Bypass`` (A-30);
2. диагностика НИЧЕГО не удаляет (тот же принцип, что у doctor.ps1, A-17):
   удаление — голые команды текстом, исполняет оператор после моего «можно»;
3. отчёт обязан искать известных гигантов, иначе 70 GB снова «исчезнут
   неизвестно куда»;
4. команды лечения печатаются отдельными голыми строками (A-28);
5. ``-Fast``-режим проходит без ошибок на любой ОС (его гоняет pytest).
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import pytest

from tests.sparsefile import make_sparse_file, sparse_unavailable_reason
from tests.test_doctor_report import decode_console

REPO = Path(__file__).resolve().parents[2]
SCRIPTS = REPO / "scripts"
CMD = SCRIPTS / "diag_disk.cmd"
PS1 = SCRIPTS / "diag_disk.ps1"


def powershell_exe() -> str | None:
    for name in ("pwsh", "powershell"):
        found = shutil.which(name)
        if found:
            return found
    return None


PS = powershell_exe()


def test_diag_disk_script_pair() -> None:
    """Обёртка + .ps1 (A-26), fast-режим для тестов, Bypass (A-30)."""
    cmd = CMD.read_text(encoding="ascii")
    assert "diag_disk.ps1" in cmd, ".cmd обязан звать .ps1 через -File"
    assert 'if /i "%~1"=="fast"' in cmd, "у обёртки должен быть режим fast"
    ps1 = PS1.read_text(encoding="utf-8-sig")
    assert "param([switch]$Fast)" in ps1, "fast-режим объявляется параметром -Fast"
    assert "exit 0" in ps1, "диагностика обязана завершаться явно и успешно"


def test_diag_disk_never_deletes_anything() -> None:
    """Диагностика смотрит, но не лечит руками (A-17): удалений в .ps1 нет.

    Совет ``del "..."`` печатается текстом (его исполняет оператор после
    моего подтверждения), но сам скрипт не вызывает ни одного изменяющего
    глагола — одна опечатка стоила бы 19.7 GB моделей.
    """
    ps1 = PS1.read_text(encoding="utf-8-sig")
    forbidden = (
        "Remove-Item",
        "Move-Item",
        "Copy-Item",
        "New-Item",
        "Rename-Item",
        "Set-Content",
        "Add-Content",
        "Out-File",
        "Invoke-WebRequest",
        "Clear-RecycleBin",
        "[System.IO.File]::Delete",
        "[System.IO.Directory]::Delete",
        "Start-Process",
    )
    for verb in forbidden:
        assert verb not in ps1, f"diag_disk.ps1 содержит {verb!r} — он не должен менять систему"
    for lineno, line in enumerate(ps1.splitlines(), 1):
        stripped = line.strip()
        assert not stripped.startswith(("del ", "rd ", "erase ")), (
            f"diag_disk.ps1:{lineno}: исполняемое удаление вместо совета: {stripped[:70]!r}"
        )


def test_diag_disk_hunts_known_giants() -> None:
    """Отчёт ищет всех известных пожирателей места, а не только GGUF.

    Регрессия T0.34: старый diag_disk не знал про Windows.old, hiberfil.sys,
    pagefile.sys, дампы и кэши AppData — ровно те места, куда «пропадают»
    десятки гигабайт после обновлений Windows.
    """
    ps1 = PS1.read_text(encoding="utf-8-sig")
    needles = (
        "DriveInfo",  # свободное место — без WMI, работает и под 5.1, и под 7
        "hiberfil.sys",
        "pagefile.sys",
        "swapfile.sys",
        "MEMORY.DMP",
        "Windows.old",
        "WINDOWS.~BT",
        "SoftwareDistribution\\Download",
        "LiveKernelReports",
        "Minidump",
        "WinSxS",
        "Package Cache",
        "Downloads",
        "AppData\\Local",
        "Recycle.Bin",
        "CITLALI_MODELS_DIR",
        "resolve_model.ps1",  # рабочая модель отмечается, лишние — кандидаты
        ".gguf",
        "cleanmgr",
        "powercfg /h off",
        "scripts\\cleanup.cmd",
        "restore_models.cmd",  # Корзина — запасной путь восстановления GGUF
    )
    for needle in needles:
        assert needle in ps1, f"diag_disk.ps1: нет {needle!r} — гигант снова станет невидимкой"


def test_diag_disk_fix_lines_are_bare_and_models_are_protected() -> None:
    """A-28: команды лечения — отдельные голые строки; модели не удаляются.

    Голой строкой печатается и ``scripts\\cleanup.cmd``, и каждая команда из
    списка ``$fixes``. Для GGUF совет ``del`` допускается только вне каталога
    моделей: внутри — вердикт «удалить только после моего 'можно'».
    """
    ps1 = PS1.read_text(encoding="utf-8-sig")
    assert re.search(r'^Write-Host "scripts\\cleanup\.cmd"$', ps1, re.MULTILINE), (
        "команда уборки обязана печататься отдельной голой строкой"
    )
    assert re.search(r"^\s*Write-Host \$fx\.Command$", ps1, re.MULTILINE), (
        "команды лечения из SVODKI обязаны печататься голыми строками без префикса"
    )
    assert ps1.count("'del \"'") >= 3, "советов del должно хватать: MEMORY.DMP, дубли GGUF"
    assert "posle moego 'mozhno'" in ps1, (
        "GGUF в каталоге моделей — кандидат только с явным подтверждением"
    )
    assert "RABOCHAYA model - NE TROGAT'" in ps1, "рабочая модель обязана отмечаться"
    assert "Prishlite mne ves vyvod" in ps1, "отчёт обязан заканчиваться просьбой прислать вывод"


@pytest.mark.skipif(PS is None, reason="нет PowerShell — прогон diag_disk пропускается")
def test_diag_disk_fast_run_is_green_and_complete() -> None:
    """Живой прогон ``-Fast``: зелёный код возврата, все разделы, без секции 8.

    Fast-режим обязан работать на любой ОС (в песочнице нет ни C:\\, ни
    Windows) — отсутствующие пути печатаются как ``[net]``, а не роняют
    скрипт. Именно этот прогон защищает от связывания параметров
    ``Get-ChildItem -File`` на несуществующих путях (defect T0.34: на Linux
    параметр -File не находился, и секция моделей падала в stderr).
    """
    proc = subprocess.run(
        [
            PS,
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(PS1),
            "-Fast",
        ],
        cwd=REPO,
        capture_output=True,
        timeout=600,
        check=False,
    )
    out = decode_console(proc.stdout)
    err = decode_console(proc.stderr)
    assert proc.returncode == 0, f"diag_disk -Fast упал: rc={proc.returncode}\nSTDERR:\n{err}"
    for header in (
        "== 1. Svobodnoe mesto",
        "== 2. Skrytye sistemnye fayly",
        "== 3. Giganty Windows",
        "== 4. Papki profilya",
        "== 5. Katalog proekta",
        "== 6. Modeli GGUF",
        "== 7. Keshi i musor",
        "== SVODKA",
        "== NE TROGAT' ==",
    ):
        assert header in out, f"в отчёте нет раздела {header!r}:\n{out}"
    assert "== 8." not in out, "fast-режим не должен запускать полный скан C:"
    assert "scripts\\cleanup.cmd" in out, "голая команда уборки обязана быть в отчёте"
    assert (
        re.search(r"Exception|cannot be found|UnauthorizedAccess|NativeCommandError", err) is None
    ), f"diag_disk -Fast написал в stderr:\n{err}"
    # Раздел 5 видит каталоги репозитория на любой ОС.
    assert "core" in out and "soul" in out, f"раздел 5 не показал каталоги repo:\n{out}"


@pytest.mark.skipif(PS is None, reason="нет PowerShell — прогон diag_disk пропускается")
def test_diag_disk_pytest_leftovers_become_one_command(tmp_path: Path) -> None:
    """Хвосты pytest в `%TEMP%` — одна команда `cleanup.cmd`, а не 13 отдельных `del`.

    Реальный отчёт оператора от 20.10.2026: `[63.51 GB] AppData\\Local\\Temp` и
    тринадцать GGUF по 4-8 GB внутри `pytest-of-User\\pytest-6..8`. SVODKA
    напечатала по одной команде `del` на каждый файл — тринадцать строк, которые
    оператор должен был скопировать поштучно, притом что весь мусор убирается
    одной `scripts\\cleanup.cmd`. Плюс раздел 7 не знал про главного пожирателя
    вообще: Temp показывался в разделе 4 как «кеш; MOZHNO udalit» без объяснения,
    откуда там десятки гигабайт (ловушка 25).
    """
    reason = sparse_unavailable_reason(tmp_path)
    if reason:
        pytest.skip(f"заглушка GGUF заняла бы место на диске: {reason}")
    host_temp = os.environ.get("TEMP") or os.environ.get("TMP") or ""
    if not host_temp or not Path(host_temp).is_dir():
        pytest.skip("в этой среде нет %TEMP% — диагностировать нечего")
    fake = Path(host_temp) / "pytest-of-CitlaliTest"
    pytest_dir = fake / "pytest-0" / "test_complete_model_outside_re0" / "citlali-models"
    try:
        make_sparse_file(pytest_dir / "Qwen3.5-9B-Q4_K_M.gguf", 5_680_522_464)
        proc = subprocess.run(
            [PS, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(PS1), "-Fast"],
            cwd=REPO,
            capture_output=True,
            timeout=600,
            check=False,
        )
    finally:
        shutil.rmtree(fake, ignore_errors=True)
    out = decode_console(proc.stdout)
    err = decode_console(proc.stderr)
    assert proc.returncode == 0, f"diag_disk -Fast упал: rc={proc.returncode}\nSTDERR:\n{err}"
    assert "pytest-of-*" in out, f"раздел 7 не показал каталоги pytest:\n{out}"
    assert "ostatki testovyh progono" in out, "не объяснено, откуда в Temp десятки GB"
    assert "$pytestFixDone" not in out, "в отчёт просочилось имя переменной PowerShell"
    assert "Infinity" not in out and "NaN" not in out, (
        f"в отчёте бессмысленное число — похоже на затёртую автоматическую переменную:\n{out}"
    )
    if sys.platform == "win32":
        # Раздел 8 (полный скан C:) работает только на Windows: там и проверяем,
        # что GGUF внутри каталога pytest не плодит команды del поштучно.
        assert out.count('del "') == 0, (
            "на GGUF внутри pytest-of-* напечатаны отдельные del — их убирает cleanup.cmd:\n" + out
        )


@pytest.mark.skipif(PS is None, reason="нет PowerShell — прогон cleanup пропускается")
def test_cleanup_dry_run_shows_real_numbers(tmp_path: Path) -> None:
    """Живой `cleanup.ps1 -Dry`: числа настоящие, хвосты pytest видны, ничего не удалено.

    Статические гаранты не поймали дефект T0.36: `$MB = 1e6` в cleanup.ps1
    затирался автоматической переменной PowerShell, и отчёт печатал
    `Infinity MB` вместо размера. Ловится только прогоном (ловушка 26).
    """
    fake_temp = tmp_path / "temp"
    leftovers = fake_temp / "pytest-of-CitlaliTest" / "pytest-0" / "proj" / "models"
    make_sparse_file(leftovers / "Qwen3.5-9B-Q4_K_M.gguf", 5_680_522_464)
    (fake_temp / "citlali-dl").mkdir(parents=True)

    env = dict(os.environ)
    env["TEMP"] = str(fake_temp)
    env["TMP"] = str(fake_temp)
    proc = subprocess.run(
        [
            PS,
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(SCRIPTS / "cleanup.ps1"),
            "-Dry",
        ],
        cwd=REPO,
        capture_output=True,
        timeout=600,
        env=env,
        check=False,
    )
    out = decode_console(proc.stdout)
    err = decode_console(proc.stderr)
    assert proc.returncode == 0, f"cleanup -Dry упал: rc={proc.returncode}\nSTDERR:\n{err}"
    assert "Infinity" not in out and "NaN" not in out, f"в отчёте бессмысленные числа:\n{out}"
    assert "pytest-of-CitlaliTest" in out, f"cleanup не увидел хвосты pytest:\n{out}"
    assert "[dry]" in out, "dry-режим обязан помечать строки"
    assert leftovers.parent.exists(), "dry-режим удалил файлы"


# ------------------------------------------------------- проба разреженности
PROBE_CMD = SCRIPTS / "probe_sparse.cmd"
PROBE_PS1 = SCRIPTS / "probe_sparse.ps1"
PROBE_PY = REPO / "core" / "tests" / "sparse_probe.py"


def test_probe_sparse_script_pair() -> None:
    r"""Проба — пара `.cmd`-обёртка + `.ps1` (A-26/A-30), и она ничего не удаляет.

    Единственное удаление — собственный временный файл, который проба сама и
    создала: иначе «инструмент проверки места» сам бы это место и ел.
    """
    cmd = PROBE_CMD.read_text(encoding="ascii")
    assert "probe_sparse.ps1" in cmd, ".cmd обязан звать .ps1 через -File"
    assert "-ExecutionPolicy Bypass" in cmd, "у оператора политика Restricted (A-30)"
    assert "exit /b %RC%" in cmd, "код возврата PowerShell обязан доходить до cmd"
    ps1 = PROBE_PS1.read_text(encoding="utf-8-sig")
    for forbidden in (
        "Remove-Item",
        "Move-Item",
        "Copy-Item",
        "Clear-RecycleBin",
        "Invoke-WebRequest",
    ):
        assert forbidden not in ps1, (
            f"probe_sparse.ps1 содержит {forbidden!r} — проба ничего не удаляет"
        )
    assert "SPARSE=" in ps1, "вердикт пробы обязан быть машиночитаемым (SPARSE=OK/FAIL из python)"


def test_probe_sparse_python_cleans_after_itself() -> None:
    """Python-часть пробы убирает свой файл и печатает измеренные числа."""
    src = PROBE_PY.read_text(encoding="utf-8")
    assert "unlink(missing_ok=True)" in src, "временный файл пробы обязан удаляться"
    assert "allocated_bytes" in src, "проба меряет занятое место, а не st_size"
    assert "free_before" in src and "free_after" in src, "свободное место меряется до и после"
    assert "finally" in src, "уборка обязана срабатывать и при падении"
    # Пробу оператор может запустить системным python, где нет pytest/httpx:
    # значит, импортировать пакет `tests` (он тянет conftest) ей нельзя.
    assert "from tests." not in src and "import tests" not in src, (
        "sparse_probe обязан импортировать sparsefile напрямую — без пакета tests"
    )
    assert "sys.path.insert" in src, "каталог с sparsefile.py добавляется в sys.path явно"


@pytest.mark.skipif(PS is None, reason="нет PowerShell — прогон пробы пропускается")
def test_probe_sparse_runs_and_reports() -> None:
    """Живой прогон: `SPARSE=OK`, под 5 GB файла выделены килобайты, место вернулось.

    Это единственный тест, который проверяет **поведение** разреженности, а не
    текст модуля: на NTFS `truncate` выделяет место целиком (ловушка 25), и если
    `FSCTL_SET_SPARSE`/`FSCTL_SET_ZERO_DATA` где-то сломались, тесты поиска
    моделей снова начнут записывать десятки GB в `%TEMP%` оператора.
    """
    if not shutil.which("python") and not shutil.which("python3"):
        pytest.skip("в этой среде нет python в PATH — пробу не запустить")
    fake_temp = Path(tempfile.gettempdir()) / "citlali-probe-sparse-test"
    fake_temp.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ)
    env["TEMP"] = str(fake_temp)
    env["TMP"] = str(fake_temp)
    try:
        proc = subprocess.run(
            [
                PS,
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(PROBE_PS1),
                "-SizeGb",
                "5",
            ],
            cwd=REPO,
            capture_output=True,
            timeout=600,
            env=env,
            check=False,
        )
    finally:
        shutil.rmtree(fake_temp, ignore_errors=True)
    out = decode_console(proc.stdout)
    err = decode_console(proc.stderr)
    assert proc.returncode == 0, f"проба вернула {proc.returncode}:\n{out}\nSTDERR:\n{err}"
    assert "SPARSE=" not in out.replace("[OK]", ""), (
        "сырой вывод python не должен протекать в отчёт"
    )
    m = re.search(r"allocated = (\d+)", out)
    assert m, f"в отчёте нет измеренного занятого места:\n{out}"
    assert int(m.group(1)) <= 1024 * 1024, (
        f"под 5 GB выделено {m.group(1)} байт — разреженности нет"
    )
    assert int(m.group(1)) < 5_000_000_000 // 1000, (
        "занятое место обязано быть на порядки меньше длины"
    )
    assert not (fake_temp / "citlali-sparse-probe.gguf").exists(), "проба оставила свой файл"
