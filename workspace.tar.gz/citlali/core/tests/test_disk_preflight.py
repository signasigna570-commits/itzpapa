r"""Тесты предполётной проверки свободного места (`scripts/disk_preflight.py`).

19.10.2026 у оператора кончилось место на C:, и `run_tests.cmd` на `fc2919f`
выдал прогресс-бар из `F`/`E` и в конце `OSError: [Errno 28] No space left on
device`. Падения были следствием, а не дефектом кода, но выглядели как
катастрофа: десятки красных тестов вместо одной понятной строки «места нет,
вот команды» (A-17: никакого молчаливого и непонятного отказа; A-32).

Проверяем:
1. единицы явные и десятичные (GB = 1000^3, AGENTS §6) — иначе порог «2 GB»
   на Windows оказывается 2 GiB, а отчёт расходится с тем, что видит оператор;
2. порог тестов (2 GB) отделяется от проектного порога A-3 (25 GB): второй —
   предупреждение, а не провал;
3. команды лечения — голые строки cmd (A-28), без прозы, плейсхолдеров и `.ps1`;
4. `run_tests.cmd` зовёт проверку ДО pytest и обрывается на её ненулевом коде.
"""

from __future__ import annotations

import ast
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]
SCRIPTS = REPO / "scripts"

sys.path.insert(0, str(SCRIPTS))

from disk_preflight import (  # noqa: E402
    EXIT_NO_SPACE,
    EXIT_OK,
    GB,
    GIB,
    MIN_FREE_GB,
    WARN_FREE_GB,
    build_report,
    free_gb,
    main,
    probe_paths,
)

FIX_HEADS = ("scripts\\", "cleanmgr", "del ", "powercfg ", "dism ")
FIX_PROSE = ("затем", "затем ", "(или", "; ", " <имя>", "после ", "если ")


# ---------------------------------------------------------------- единицы


def test_units_are_explicit_and_decimal() -> None:
    """AGENTS §6: GB = 1000^3, GiB = 1024^3, и оба порога названы числом."""
    assert GB == 1000**3, "GB обязан быть десятичным: 1000^3"
    assert GIB == 1024**3, "GiB обязан быть двоичным: 1024^3"
    assert GB != GIB, "если константы равны, где-то снова перепутаны GB и GiB"
    assert MIN_FREE_GB == 2.0, "порог для тестов зафиксирован в A-32: 2.0 GB"
    assert WARN_FREE_GB == 25.0, "проектный порог A-3: 25 GB свободно"
    assert MIN_FREE_GB < WARN_FREE_GB


# ------------------------------------------------------------ измерение


def test_free_gb_is_positive_on_real_dir(tmp_path: Path) -> None:
    got = free_gb(tmp_path)
    assert got > 0.0, "свободное место не может быть нулём на живом каталоге"
    assert isinstance(got, float)


def test_probe_paths_cover_repo_and_temp() -> None:
    """pytest пишет tmp_path в %TEMP%, проект - на свой диск: нужны оба."""
    paths = probe_paths()
    assert REPO in paths, "каталог проекта не проверяется"
    assert Path(tempfile.gettempdir()) in paths, "%TEMP% не проверяется"


def test_report_has_one_line_per_device(tmp_path: Path) -> None:
    """Два каталога на одном диске - одна строка, а не два одинаковых числа."""
    a = tmp_path / "a"
    b = tmp_path / "b"
    a.mkdir()
    b.mkdir()
    report = build_report(paths=[a, b])
    devices = {os.stat(p).st_dev for p in (a, b)}
    assert len(report.targets) == len(devices), "строка обязана быть одна на устройство"


# --------------------------------------------------------------- вердикты


def test_report_ok_when_space_is_enough(tmp_path: Path) -> None:
    report = build_report(min_free_gb=0.0, warn_free_gb=0.0, paths=[tmp_path])
    assert report.ok is True
    assert report.exit_code == EXIT_OK
    text = "\n".join(report.lines)
    assert "[OK]" in text
    assert report.fixes == (), "при зелёной проверке команды лечения не нужны"


def test_report_fails_when_threshold_is_impossible(tmp_path: Path) -> None:
    """Порог заведомо недостижим - единственный способ проверить ветку отказа."""
    report = build_report(min_free_gb=1e12, warn_free_gb=0.0, paths=[tmp_path])
    assert report.ok is False
    assert report.exit_code == EXIT_NO_SPACE
    text = "\n".join(report.lines)
    assert "[FAIL]" in text
    assert "28" in text, "оператор обязан узнать свой OSError 28 в диагнозе"
    assert report.fixes, "без команд лечения отказ бесполезен (A-28)"


def test_report_warns_but_passes_below_project_threshold(tmp_path: Path) -> None:
    """A-3 (25 GB) - предупреждение: прогон тестов при этом не валится."""
    report = build_report(min_free_gb=0.0, warn_free_gb=1e12, paths=[tmp_path])
    assert report.ok is True, "проектный порог не обязан валить прогон тестов"
    assert report.exit_code == EXIT_OK
    text = "\n".join(report.lines)
    assert "[WARN]" in text
    assert "A-3" in text, "предупреждение обязано ссылаться на поправку, которая его ввела"


def test_report_shows_number_with_one_decimal(tmp_path: Path) -> None:
    """A-28: число в отчёте совпадает с измерением и пишется с десятыми GB."""
    report = build_report(min_free_gb=0.0, warn_free_gb=0.0, paths=[tmp_path])
    text = "\n".join(report.lines)
    assert f"{report.free_gb:.1f} GB" in text, "в отчёте нет фактического числа GB"
    found = re.findall(r"(\d+\.\d) GB", text)
    assert found, "размер напечатан без десятых: округление до нуля уже ловили в doctor"
    assert float(found[0]) == pytest.approx(report.free_gb, abs=0.05)


def test_fixes_are_bare_single_cmd_lines(tmp_path: Path) -> None:
    report = build_report(min_free_gb=1e12, warn_free_gb=0.0, paths=[tmp_path])
    assert report.fixes, "нечего проверять"
    for fix in report.fixes:
        assert fix == fix.strip(), f"команда с отступом не копируется целиком: {fix!r}"
        assert "\n" not in fix, f"команда обязана быть одной строкой: {fix!r}"
        assert ".ps1" not in fix, f"из cmd .ps1 открывается в блокноте: {fix!r}"
        assert "<" not in fix, f"плейсхолдер нельзя скопировать: {fix!r}"
        for prose in FIX_PROSE:
            assert prose not in fix, f"в команде осталась проза {prose!r}: {fix!r}"
        assert fix.startswith(FIX_HEADS), f"не похоже на команду cmd: {fix!r}"


def test_fixes_point_to_scripts_that_exist(tmp_path: Path) -> None:
    r"""Совет `scripts\...` обязан быть настоящим файлом, а не памятью о нём."""
    report = build_report(min_free_gb=1e12, warn_free_gb=0.0, paths=[tmp_path])
    named = [f for f in report.fixes if f.startswith("scripts\\")]
    assert named, "лечение обязано звать диагностику и уборку проекта"
    for fix in named:
        # Обратные слэши - для cmd; на Linux их меняем, чтобы путь нашёлся.
        rel = fix.split(" ", 1)[0].replace("\\", "/")
        assert (REPO / rel).is_file(), f"{rel}: скрипта нет в репозитории"


# ------------------------------------------------------------------ main


def test_main_returns_zero_when_space_is_enough(
    capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    # Оба порога нулевые: свободное место в песочнице не должно влиять на тест.
    monkeypatch.setattr(
        sys, "argv", ["disk_preflight.py", "--min-free-gb", "0", "--warn-free-gb", "0"]
    )
    assert main() == EXIT_OK
    assert "[OK]" in capsys.readouterr().out


def test_main_returns_three_and_prints_commands(
    capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(sys, "argv", ["disk_preflight.py", "--min-free-gb", "1000000000"])
    assert main() == EXIT_NO_SPACE
    out = capsys.readouterr().out
    assert "[FAIL]" in out
    assert "scripts\\diag_disk.cmd" in out
    assert "scripts\\cleanup.cmd" in out


def test_main_json_is_machine_readable(
    capsys: pytest.CaptureFixture[str], monkeypatch: pytest.MonkeyPatch
) -> None:
    """Число из отчёта читает не только человек: `--json` для тестов и бенча."""
    monkeypatch.setattr(
        sys,
        "argv",
        ["disk_preflight.py", "--json", "--min-free-gb", "0", "--warn-free-gb", "0"],
    )
    assert main() == EXIT_OK
    data = json.loads(capsys.readouterr().out)
    assert data["ok"] is True
    assert data["free_gb"] >= 0.0
    assert data["min_free_gb"] == 0.0
    assert isinstance(data["targets"], list) and data["targets"]


# ------------------------------------------------------------- интеграция


def test_run_tests_checks_disk_before_pytest() -> None:
    r"""A-32: `run_tests.cmd` обязан упасть ДО pytest, а не после сотни `F`.

    Регрессия 19.10.2026 (`fc2919f`): диск полный, pytest начал писать
    `.pytest_cache` и tmp-файлы, отчёт оператора превратился в «всё сломалось».
    """
    cmd = (SCRIPTS / "run_tests.cmd").read_text(encoding="ascii")
    assert "disk_preflight.py" in cmd, "run_tests.cmd не проверяет свободное место"
    preflight_idx = cmd.index("disk_preflight.py")
    pytest_idx = cmd.index("-m pytest")
    assert preflight_idx < pytest_idx, "проверка места обязана идти до запуска pytest"
    tail = cmd[preflight_idx:pytest_idx]
    assert "if errorlevel 1" in tail, "код возврата предпроверки никто не смотрит"
    assert "exit /b" in tail, "при нехватке места прогон обязан прерываться"
    assert "[FAIL]" in tail, "оператору нужна явная строка отказа, а не тишина"


def test_preflight_is_pure_stdlib() -> None:
    """Скрипт работает до того, как venv гарантированно живой: только stdlib.

    Проверяем не текст (в докстринге название чужой библиотеки законно), а AST:
    каждый импорт обязан быть из стандартной поставки.
    """
    tree = ast.parse((SCRIPTS / "disk_preflight.py").read_text(encoding="utf-8"))
    modules: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            modules.update(alias.name.split(".")[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            modules.add(node.module.split(".")[0])
    assert modules, "скрипт ничего не импортирует - значит, и не измеряет"
    foreign = modules - set(sys.stdlib_module_names)
    assert not foreign, f"disk_preflight.py тянет чужие пакеты: {sorted(foreign)}"


def test_output_survives_cp866_redirection() -> None:
    """A-31: оператор перенаправляет вывод в файл - кодировка окна cp866.

    Знак вне cp866 (эм-тире, «ёлочки», §) в ПЕЧАТНОЙ строке при перенаправлении
    даёт UnicodeEncodeError вместо отчёта: `run_tests.cmd > "%TEMP%\t.txt"`
    кончится падением проверки, а не её результатом. Докстринги и комментарии
    не печатаются, поэтому проверяем именно запуск с PYTHONIOENCODING=cp866.
    """
    env = dict(os.environ, PYTHONIOENCODING="cp866")
    for extra in (["--min-free-gb", "0"], ["--min-free-gb", "1000000000"]):
        proc = subprocess.run(
            [sys.executable, str(SCRIPTS / "disk_preflight.py"), *extra],
            capture_output=True,
            env=env,
            check=False,
        )
        assert proc.returncode in (EXIT_OK, EXIT_NO_SPACE), proc.stderr.decode("utf-8", "replace")
        assert proc.stderr == b"", "проверка места не имеет права писать в stderr"
        text = proc.stdout.decode("cp866")
        assert "GB" in text, "в cp866-выводе потерялись единицы измерения"
