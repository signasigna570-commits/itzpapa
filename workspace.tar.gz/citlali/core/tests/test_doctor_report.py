"""Интеграционные тесты A-28: отчёт `scripts\\doctor.ps1` читают без догадок.

Регрессии, все найдены в живых прогонах у оператора (19-20.10.2026):

1. `tools\\llama\\llama-server.exe (0 MB)` — кругление до 0.1 MB превращало
   размер в ноль. Оператор решил, что exe побит («я по-моему не то сделал»).
2. `лечить: del "C:\\dev\\citlali\\models\\Qwen3-14B-Q4_K_M.gguf"` — оператор
   скопировал только путь, без `del "`. Четырежды. Файл остался на диске.
3. `SOUL.md = 5433 знаков` в doctor при `soul=5348 знаков` в логе ядра: git на
   Windows кладёт CRLF, Python читает в universal newlines. Лимит 5600 (A-10
   ред.3) проверялся по числу, которого в промпте не бывает.

4. Windows PowerShell 5.1 пишет кириллицу в консоль в OEM-кодировке (cp866),
   а тест читал stdout как UTF-8. На машине оператора четыре проверки искали
   русские подстроки в трухе из replacement-знаков и падали, хотя doctor
   отработал правильно (A-31, ловушка 21). Вывод декодируется `decode_console`.

5. Прогон наследовал окружение хоста, поэтому «скелет без config.toml» на машине
   оператора config.toml нашёл: `%APPDATA%\\Citlali\\config.toml` там настоящий
   (20.10.2026, `1 failed, 478 passed` на зелёном коде). doctor обязан видеть
   стерильный стенд — окружение для `subprocess` собирается `hermetic_env()`
   (ловушка 24).

Тесты гоняют настоящий PowerShell на временном скелете репозитория — рабочая
копия не трогается. Без PowerShell тесты пропускаются: статические гарантии
живут в `test_scripts_env.py`.
"""

from __future__ import annotations

import contextlib
import itertools
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

from tests.sparsefile import make_sparse_file

REPO = Path(__file__).resolve().parents[2]
SCRIPTS = REPO / "scripts"


def powershell_exe() -> str | None:
    for name in ("pwsh", "powershell"):
        found = shutil.which(name)
        if found:
            return found
    return None


def console_codepage() -> int:
    """Кодстраница консоли текущего окна; вне Windows — 65001 (UTF-8).

    Именно её использует Windows PowerShell 5.1 для stdout, когда вывод
    перенаправлен или перехвачен тестом (ловушка 21, A-31).
    """
    if sys.platform != "win32":
        return 65001
    import ctypes

    try:
        cp = int(ctypes.windll.kernel32.GetConsoleOutputCP())
    except (AttributeError, OSError, ValueError):
        cp = 0
    return cp or 65001


def _is_junk_char(ch: str) -> bool:
    """Знак, которого в русском отчёте doctor быть не может.

    replacement-знак, псевдографика cp866 (так выглядит UTF-8, прочитанный как
    cp866: «╨╗╨╡╤З╨╕╤В╤М») и CJK (так выглядит cp866, прочитанный как UTF-8:
    «\u18ae\u6baa»). Латиница-1 (Ã, », °) сама по себе не мусор: в cp1251
    живут настоящие «» и №, а кракозябры «Р»РµС‡РёС‚СЊ» ловит `_looks_like_cp1251_of_utf8`.
    """
    o = ord(ch)
    if o == 0xFFFD:
        return True
    if 0x2500 <= o <= 0x25FF:
        return True
    return 0x2E80 <= o <= 0x9FFF or 0xAC00 <= o <= 0xD7FF


def _looks_like_cp1251_of_utf8(text: str) -> bool:
    """«Р»РµС‡РёС‚СЊ»: UTF-8-байты, прочитанные как cp1251.

    Признак составной: кириллица + латиница-1 + регистры чередуются почти на
    каждой букве (Р» Рµ РЎ Рѕ РІ Р°). По отдельности каждый признак законен,
    вместе в русском отчёте не встречается.
    """
    cyrillic = sum(1 for ch in text if "\u0400" <= ch <= "\u04ff")
    latin1 = sum(1 for ch in text if "\u00a0" <= ch <= "\u00ff")
    if cyrillic < 12 or latin1 == 0:
        return False
    switches = sum(
        1
        for a, b in itertools.pairwise(text)
        if ("\u0400" <= a <= "\u04ff") != ("\u0400" <= b <= "\u04ff")
    )
    return switches * 2 >= cyrillic


# Частотные буквы русского текста и буквы, которых в отчёте doctor почти не бывает.
# Нужны, чтобы отличить настоящую кириллицу от «ыхўшЄ№» — cp866-прочтения
# cp1251-байтов: мусорных знаков там нет, а русского текста тоже нет.
_RU_COMMON = frozenset("оеатнисрвклдмпуяыьгзбчйхъэюё")
_RU_RARE = frozenset("щфжцшъэ")


def _russian_score(text: str) -> int:
    """Правдоподобие русского текста: частотные буквы в плюс, редкие — в минус."""
    low = text.lower()
    common = sum(1 for ch in low if ch in _RU_COMMON)
    rare = sum(1 for ch in low if ch in _RU_RARE)
    return common - 3 * rare


def _decode_penalty(text: str) -> tuple[int, int, int]:
    """Штраф расшифровки: мусор, неправдоподобие русского текста, доля кириллицы.

    Сравниваются кортежи целиком, поэтому порядок критериев и есть приоритет:
    сначала отсутствие мусора (псевдографика, CJK, replacement-знаки,
    кракозябры cp1251), затем правдоподобие русского текста, затем — меньше
    кириллицы (кракозябры удваивают её счёт: одна буква UTF-8 = два знака cp1251).

    Штрафа «за не ту кодировку» нет намеренно: кодстраница окна не обязана
    совпадать с тем, что реально написал PowerShell 5.1, а частотный анализ
    русского текста решает задачу лучше любой догадки про cp1251.
    """
    junk = sum(1 for ch in text if _is_junk_char(ch))
    if _looks_like_cp1251_of_utf8(text):
        junk += 4
    letters = sum(1 for ch in text.lower() if ch in _RU_COMMON or ch in _RU_RARE)
    russian = -_russian_score(text) + (3 * letters if letters else 0)
    cyrillic = sum(1 for ch in text if "\u0400" <= ch <= "\u04ff")
    return (junk, russian, cyrillic)


def decode_console(data: bytes) -> str:
    """Декодировать вывод PowerShell так, чтобы кириллица выжила в любой консоли.

    Кандидаты: UTF-8 (Linux, pwsh 7, Windows после `chcp 65001`), кодстраница
    окна (Windows PowerShell 5.1 пишет stdout именно в ней), cp866 и cp1251.
    Правило A-31: чистый UTF-8 с кириллицей побеждает всегда; «случайно валидный»
    UTF-8 без единой кириллической буквы проигрывает OEM-расшифровке (это cp866-
    байты, которые легли в CJK); иначе берётся наименее штрафная расшифровка.

    Проверки обязаны держать в пробах длинные русские фразы: на трёх буквах
    эвристика одну кодировку от другой не отличит.
    """
    utf8: str | None = None
    with contextlib.suppress(UnicodeDecodeError):
        utf8 = data.decode("utf-8")

    cp = console_codepage()
    numbers = [866, 1251] if cp == 65001 else [cp, 866, 1251]
    candidates = [f"cp{n}" for n in dict.fromkeys(numbers)]

    best: tuple[tuple[int, int, int], str] | None = None
    for name in candidates:
        try:
            text = data.decode(name)
        except (UnicodeDecodeError, LookupError):
            continue
        score = _decode_penalty(text)
        if best is None or score < best[0]:
            best = (score, text)

    if utf8 is not None:
        utf8_score = _decode_penalty(utf8)
        cyr_utf8 = sum(1 for ch in utf8 if "\u0400" <= ch <= "\u04ff")
        if utf8_score[0] == 0 and (cyr_utf8 > 0 or best is None or best[0][0] > 0):
            return utf8
        if best is None or utf8_score <= best[0]:
            return utf8
        return best[1]

    if best is not None:
        return best[1]
    return data.decode("cp1251", errors="replace")


PS = powershell_exe()

pytestmark = pytest.mark.skipif(
    PS is None, reason="нет PowerShell — интеграционный тест пропускается"
)

# «2.0 MB» в invariant-культуре и «2,0 MB» на русской Windows — обе формы.
_SIZE_RE = re.compile(r"llama-server\.exe \(([\d.,]+) (MB|байт)\)")
_SOUL_RE = re.compile(r"SOUL\.md = (\d+) знаков")

# Чем обязана начинаться команда лечения: это то, что можно вставить в cmd
# дословно и получить действие. Никаких «затем откройте новое окно» в строке
# команды — проза живёт в тексте проблемы (A-28).
FIX_HEADS = ("del ", "setx ", "mkdir ", "git ", "scripts\\", "powershell ")


def build_skeleton(root: Path, exe_bytes: int) -> Path:
    """Минимальный репозиторий, на котором doctor доходит до разделов 2 и 5."""
    (root / "scripts").mkdir(parents=True)
    (root / "soul").mkdir(parents=True)
    (root / "tools" / "llama").mkdir(parents=True)
    shutil.copy(SCRIPTS / "doctor.ps1", root / "scripts" / "doctor.ps1")
    shutil.copy(SCRIPTS / "bootstrap.json", root / "scripts" / "bootstrap.json")

    # CUDA-библиотеки: иначе раздел 2 ругается не на то, что мы проверяем.
    (root / "tools" / "llama" / "ggml-cuda.dll").write_bytes(b"\0" * 16)
    (root / "tools" / "llama" / "cudart64_12.dll").write_bytes(b"\0" * 16)
    # Заглушка — через tests.sparsefile (ловушка 25): на NTFS `truncate`
    # выделяет место целиком. Здесь размер маленький (2 MB), но правило одно.
    exe = root / "tools" / "llama" / "llama-server.exe"
    make_sparse_file(exe, exe_bytes)

    # SOUL.md — как после git checkout на Windows: CRLF, без BOM.
    text = (REPO / "soul" / "SOUL.md").read_text(encoding="utf-8")
    (root / "soul" / "SOUL.md").write_bytes(text.replace("\n", "\r\n").encode("utf-8"))
    return root


def hermetic_env(root: Path) -> dict[str, str]:
    """Окружение, в котором doctor видит только временный скелет (ловушка 24).

    20.10.2026 у оператора упал `test_doctor_exit_code_is_one_on_critical`:
    «скелет без config.toml» нашёл настоящий `%APPDATA%\\Citlali\\config.toml`,
    потому что `subprocess` унаследовал окружение хоста. Тест проверял состояние
    чужой машины вместо своего стенда — на чистой песочнице он зелёный, на рабочей
    машине красный. Поэтому все пути, куда doctor смотрит мимо репозитория,
    перенаправляем внутрь `root`: APPDATA/LOCALAPPDATA (конфиг, кэши pip/npm),
    TEMP/TMP (`citlali-dl`), CITLALI_MODELS_DIR (пустой каталог вместо настоящих
    GGUF оператора). Наследуются только PATH/SystemRoot и подобное — то, без чего
    не стартует сам PowerShell.

    Реестр тесту не подконтролен (`Get-EnvVar` читает уровни User/Machine), но
    переменная процесса у него в приоритете, поэтому `setx` оператора на отчёт
    не влияет.
    """
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith("CITLALI_")}
    fake_appdata = root / "env" / "appdata"
    fake_temp = root / "env" / "temp"
    fake_models = root / "env" / "models"
    for d in (fake_appdata, fake_temp, fake_models):
        d.mkdir(parents=True, exist_ok=True)
    env["APPDATA"] = str(fake_appdata)
    env["LOCALAPPDATA"] = str(fake_appdata)
    env["TEMP"] = str(fake_temp)
    env["TMP"] = str(fake_temp)
    # `Get-EnvVar` в doctor.ps1 смотрит сначала процесс, потом реестр (User/Machine):
    # явная переменная процесса перекрывает `setx CITLALI_MODELS_DIR` оператора,
    # поэтому разделы 3 и 8 не читают настоящие GGUF с чужого диска.
    env["CITLALI_MODELS_DIR"] = str(fake_models)
    return env


def run_doctor_proc(root: Path) -> subprocess.CompletedProcess[bytes]:
    """Прогон doctor.ps1 на временном скелете в стерильном окружении.

    На скелете doctor честно найдёт кучу критичных проблем (нет config.toml, нет
    core\\.venv) и вернёт 1 — это ожидаемо.
    """
    return subprocess.run(
        [
            PS,
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(root / "scripts" / "doctor.ps1"),
        ],
        cwd=root,
        capture_output=True,
        timeout=180,
        env=hermetic_env(root),
    )


def run_doctor(root: Path) -> str:
    """Текст отчёта doctor, расшифрованный по A-31."""
    return decode_console(run_doctor_proc(root).stdout)


def exe_size_mb(value: str) -> float:
    return float(value.replace(",", "."))


def test_doctor_prints_real_exe_size(tmp_path: Path) -> None:
    """Живой exe обязан показывать свой настоящий размер, а не «0 MB»."""
    out = run_doctor(build_skeleton(tmp_path / "repo", exe_bytes=2 * 1024 * 1024))
    m = _SIZE_RE.search(out)
    assert m, f"doctor не напечатал размер llama-server.exe:\n{out}"
    assert m.group(2) == "MB", "двухмегабайтный exe печатается в MB, а не в байтах"
    # T0.36: MB в отчёте десятичный (2 097 152 / 1000^2 = 2.1), раньше был
    # двоичный (2.0). Смысл теста — «не ноль», поэтому принимаем обе формы:
    # расхождение 5% и есть та самая путаница GB/GiB, доверия к цифрам оно не
    # отменяет, но и поломкой не является.
    assert exe_size_mb(m.group(1)) == pytest.approx(2.097, abs=0.05)
    assert "(0 MB)" not in out, "«0 MB» для живого файла — ровно та регрессия A-28"


def test_doctor_flags_suspiciously_light_exe(tmp_path: Path) -> None:
    """exe легче 100 KB — битая распаковка, это критично, а не косметика."""
    out = run_doctor(build_skeleton(tmp_path / "repo", exe_bytes=20 * 1024))
    assert "распаковка побита" in out, f"лёгкий exe не объявлен критичной проблемой:\n{out}"
    m = _SIZE_RE.search(out)
    assert m and m.group(2) == "байт", "размер меньше 1 MB печатается в байтах"


def test_doctor_fix_command_is_a_bare_line(tmp_path: Path) -> None:
    """Команду лечения копируют дословно: она идёт отдельной строкой без префикса.

    Регрессия: `лечить: del "путь"` оператор скопировал наполовину и получил
    четыре попытки «выполнить» путь к GGUF как команду.
    """
    out = run_doctor(build_skeleton(tmp_path / "repo", exe_bytes=2 * 1024 * 1024))
    assert "лечить - скопируйте строку ниже целиком:" in out, (
        f"нет подсказки про копирование:\n{out}"
    )
    assert "лечить: " not in out, "команда не должна быть приклеена к слову «лечить:»"

    lines = out.splitlines()
    hints = [i for i, ln in enumerate(lines) if ln.strip().startswith("лечить - скопируйте")]
    assert hints, "doctor не напечатал ни одной команды лечения"
    for i in hints:
        cmd = lines[i + 1]
        assert cmd and not cmd.startswith(" "), (
            f"команда лечения должна идти голой строкой без отступа, получено {cmd!r}"
        )
        assert cmd.startswith(FIX_HEADS), f"строка под подсказкой не похожа на команду cmd: {cmd!r}"


def test_doctor_counts_soul_chars_like_core_does(tmp_path: Path) -> None:
    """doctor обязан назвать то же число знаков, что и ядро.

    Ядро читает SOUL.md в текстовом режиме Python (universal newlines), поэтому
    CRLF для него — один знак. Файл на диске оператора содержит CRLF: 85 строк
    давали расхождение 5433 против 5348.
    """
    root = build_skeleton(tmp_path / "repo", exe_bytes=2 * 1024 * 1024)
    on_disk = (root / "soul" / "SOUL.md").read_bytes().decode("utf-8")
    assert "\r\n" in on_disk, "проба обязана быть с CRLF — иначе тест ничего не проверяет"
    core_sees = len(on_disk.replace("\r\n", "\n"))
    assert core_sees != len(on_disk), "расхождение CRLF/LF должно быть заметно"

    out = run_doctor(root)
    m = _SOUL_RE.search(out)
    assert m, f"doctor не напечатал длину SOUL.md:\n{out}"
    assert int(m.group(1)) == core_sees, (
        f"doctor насчитал {m.group(1)}, а ядро увидит {core_sees}: "
        "лимит 5600 проверяется по чужому числу"
    )


def test_doctor_exit_code_is_one_on_critical(tmp_path: Path) -> None:
    """Скелет без config.toml и venv обязан дать код возврата 1, а не 0."""
    root = build_skeleton(tmp_path / "repo", exe_bytes=2 * 1024 * 1024)
    proc = run_doctor_proc(root)
    assert proc.returncode == 1, f"ожидали 1 при критичных проблемах, получили {proc.returncode}"
    assert "config.toml не найден" in decode_console(proc.stdout), (
        "раздел 4 обязан пожаловаться на отсутствие конфига на голом скелете"
    )


def test_doctor_ignores_host_config(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Конфиг хоста не подглядывается: стенд теста — не машина оператора (ловушка 24).

    20.10.2026 этот сценарий упал вживую: у оператора `%APPDATA%\\Citlali\\config.toml`
    настоящий, прогон унаследовал окружение, и doctor на «голом скелете» нашёл
    конфиг — проверка `config.toml не найден` не сработала (478 passed, 1 failed
    на зелёном коде). Здесь хост изображён `monkeypatch.setenv`.
    """
    host_appdata = tmp_path / "host-appdata"
    (host_appdata / "Citlali").mkdir(parents=True)
    (host_appdata / "Citlali" / "config.toml").write_text(
        'model_file = "models/Qwen3.5-9B-Q4_K_M.gguf"\nsoul_file = "soul/SOUL.md"\n',
        encoding="utf-8",
    )
    monkeypatch.setenv("APPDATA", str(host_appdata))
    monkeypatch.setenv("TEMP", str(tmp_path))

    root = build_skeleton(tmp_path / "repo", exe_bytes=2 * 1024 * 1024)
    out = run_doctor(root)
    assert "config.toml не найден" in out, (
        "doctor прочитал конфиг хоста вместо стерильного стенда:\n" + out
    )
    assert str(host_appdata) not in out, "путь хоста протёк в отчёт"


def test_decode_console_reads_utf8_and_oem_alike() -> None:
    """A-31: один и тот же отчёт обязан читаться и из UTF-8, и из OEM-байтов.

    Windows PowerShell 5.1 пишет кириллицу в кодстранице консоли (у оператора
    cp866), а тест читал stdout как UTF-8 и получал труху: 19.10.2026 так упали
    четыре проверки, хотя doctor отработал правильно.
    """
    text = "лечить - скопируйте строку ниже целиком: SOUL.md = 5348 знаков"
    assert decode_console(text.encode("utf-8")) == text
    cp866 = text.encode("cp866")
    assert cp866 != text.encode("utf-8"), "проба обязана различать кодировки"
    assert decode_console(cp866) == text


def test_doctor_reports_console_codepage(tmp_path: Path) -> None:
    """Кодстраница видна в отчёте: без неё кашу из кириллицы не объяснить (A-31)."""
    out = run_doctor(build_skeleton(tmp_path / "repo", exe_bytes=2 * 1024 * 1024))
    assert "кодстраница консоли" in out, f"doctor не напечатал кодстраницу:\n{out}"


def test_doctor_pins_utf8_when_console_is_utf8() -> None:
    """При `chcp 65001` PowerShell 5.1 всё равно может писать cp866 — хук обязателен.

    .NET кэширует кодировку консоли при старте процесса, поэтому без явного
    `[Console]::OutputEncoding` отчёт в перенаправленном выводе и в тестах
    остаётся в OEM-байтах (ловушка 21).
    """
    ps1 = (SCRIPTS / "doctor.ps1").read_text(encoding="utf-8-sig")
    assert "GetConsoleOutputCP" in ps1, "doctor обязан спрашивать кодстраницу консоли"
    assert "[Console]::OutputEncoding" in ps1, "doctor обязан уметь включить UTF-8"
    assert "65001" in ps1, "UTF-8 включается только под консоль 65001"
    assert "New-Object System.Text.UTF8Encoding($false)" in ps1, "UTF-8 без BOM"
