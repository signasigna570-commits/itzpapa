"""Тесты клиента llama-server (T1.3): SSE-парсер, стрим, ошибки, stop.

Всё на httpx.MockTransport — без сети и без модели.
"""

from __future__ import annotations

import json

import httpx
import pytest

from app.llm import (
    LLMClient,
    LLMError,
    LLMHTTPError,
    LLMUnavailable,
    StreamChunk,
    parse_sse_stream,
)
from tests.conftest import make_client, sse_transport


def sse_bytes(events: list[dict | str]) -> bytes:
    out = b""
    for ev in events:
        payload = ev if isinstance(ev, str) else json.dumps(ev, ensure_ascii=False)
        out += f"data: {payload}\n\n".encode()
    return out + b"data: [DONE]\n\n"


def chunk_obj(text: str, finish: str | None = None) -> dict:
    return {
        "choices": [
            {
                "index": 0,
                "delta": {"content": text} if text else {},
                "finish_reason": finish,
            }
        ]
    }


async def collect(chunks) -> list[StreamChunk]:  # type: ignore[no-untyped-def]
    return [c async for c in chunks]


# ------------------------------------------------------------------ парсер


async def test_parse_sse_reassembles_split_lines() -> None:
    raw = b'data: {"a":' + b" 1}\n" + b"\n" + b'data: {"a": 2}\n\n'

    async def lines():  # type: ignore[no-untyped-def]
        for chunk in raw.decode().split("\n"):
            yield chunk

    got = [obj async for obj in parse_sse_stream(lines())]
    assert got == [{"a": 1}, {"a": 2}]


async def test_parse_sse_handles_crlf_and_comments() -> None:
    async def lines():  # type: ignore[no-untyped-def]
        for line in [": keep-alive\r", 'data: {"x": 1}\r', "\r", "data: [DONE]\r"]:
            yield line

    got = [obj async for obj in parse_sse_stream(lines())]
    assert got == [{"x": 1}]


async def test_parse_sse_skips_broken_json() -> None:
    async def lines():  # type: ignore[no-untyped-def]
        for line in ["data: {не json", "", 'data: {"ok": true}', ""]:
            yield line

    got = [obj async for obj in parse_sse_stream(lines())]
    assert got == [{"ok": True}]


async def test_parse_sse_flushes_unterminated_event() -> None:
    async def lines():  # type: ignore[no-untyped-def]
        yield 'data: {"tail": 1}'

    got = [obj async for obj in parse_sse_stream(lines())]
    assert got == [{"tail": 1}]


# ------------------------------------------------------------------- стрим


async def test_chat_stream_yields_text_in_order() -> None:
    body = sse_bytes([chunk_obj("Ну "), chunk_obj("привет"), chunk_obj("", finish="stop")])
    client = make_client(sse_transport([body]))
    chunks = await collect(client.chat_stream([{"role": "user", "content": "привет"}]))
    text = "".join(c.text for c in chunks)
    assert text == "Ну привет"
    assert chunks[-1].is_final
    assert chunks[-1].finish_reason == "stop"
    await client.aclose()


async def test_chat_stream_sends_expected_payload() -> None:
    seen: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen.update(json.loads(request.content))
        seen["path"] = request.url.path
        return httpx.Response(200, content=sse_bytes([chunk_obj("ok", finish="stop")]))

    client = make_client(httpx.MockTransport(handler))
    await collect(
        client.chat_stream([{"role": "user", "content": "x"}], temperature=0.3, max_tokens=64)
    )
    assert seen["path"] == "/v1/chat/completions"
    assert seen["stream"] is True
    assert seen["temperature"] == 0.3
    assert seen["max_tokens"] == 64
    assert seen["model"] == "test-model"
    assert "tools" not in seen, "без инструментов поле tools не отправляем"
    await client.aclose()


async def test_chat_stream_with_tools_enables_tool_choice() -> None:
    seen: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen.update(json.loads(request.content))
        return httpx.Response(200, content=sse_bytes([chunk_obj("", finish="tool_calls")]))

    client = make_client(httpx.MockTransport(handler))
    tools = [{"type": "function", "function": {"name": "open_url", "parameters": {}}}]
    await collect(client.chat_stream([{"role": "user", "content": "x"}], tools=tools))
    assert seen["tools"] == tools
    assert seen["tool_choice"] == "auto"
    await client.aclose()


async def test_tool_calls_are_accumulated_across_chunks() -> None:
    body = sse_bytes(
        [
            {
                "choices": [
                    {
                        "index": 0,
                        "delta": {
                            "tool_calls": [
                                {"index": 0, "id": "call_1", "function": {"name": "open_url"}}
                            ]
                        },
                        "finish_reason": None,
                    }
                ]
            },
            {
                "choices": [
                    {
                        "index": 0,
                        "delta": {"tool_calls": [{"index": 0, "function": {"arguments": '{"ur'}}]},
                        "finish_reason": None,
                    }
                ]
            },
            {
                "choices": [
                    {
                        "index": 0,
                        "delta": {
                            "tool_calls": [{"index": 0, "function": {"arguments": 'l": "x"}'}}]
                        },
                        "finish_reason": "tool_calls",
                    }
                ]
            },
        ]
    )
    client = make_client(sse_transport([body]))
    chunks = await collect(client.chat_stream([{"role": "user", "content": "открой x"}]))
    final = chunks[-1]
    assert len(final.tool_calls) == 1
    call = final.tool_calls[0]
    assert call.id == "call_1"
    assert call.name == "open_url"
    assert json.loads(call.arguments) == {"url": "x"}
    await client.aclose()


async def test_http_error_becomes_llmhttperror() -> None:
    client = make_client(
        httpx.MockTransport(lambda req: httpx.Response(500, content=b"model failed to load"))
    )
    with pytest.raises(LLMHTTPError) as exc:
        await collect(client.chat_stream([{"role": "user", "content": "x"}]))
    assert exc.value.status_code == 500
    assert "model failed" in exc.value.body
    await client.aclose()


async def test_connection_error_becomes_unavailable() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("connection refused", request=request)

    client = make_client(httpx.MockTransport(handler))
    with pytest.raises(LLMUnavailable):
        await collect(client.chat_stream([{"role": "user", "content": "x"}]))
    await client.aclose()


async def test_health_reflects_server_state() -> None:
    ok = make_client(httpx.MockTransport(lambda req: httpx.Response(200, json={"status": "ok"})))
    assert await ok.health() is True
    await ok.aclose()

    down = LLMClient(base_url="http://127.0.0.1:1", model="x", timeout_s=1.0)
    assert await down.health() is False
    await down.aclose()


async def test_stop_generation_posts_to_completion_stop() -> None:
    seen: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request.url.path)
        return httpx.Response(200, json={"status": "ok"})

    client = make_client(httpx.MockTransport(handler))
    assert await client.stop_generation() is True
    assert seen == ["/completion/stop"]
    await client.aclose()


async def test_chat_json_returns_content() -> None:
    body = {
        "choices": [{"message": {"role": "assistant", "content": '{"facts": []}'}}],
        "usage": {"total_tokens": 10},
    }
    client = make_client(httpx.MockTransport(lambda req: httpx.Response(200, json=body)))
    out = await client.chat_json([{"role": "user", "content": "извлеки факты"}])
    assert out == '{"facts": []}'
    await client.aclose()


async def test_chat_json_rejects_malformed_response() -> None:
    client = make_client(httpx.MockTransport(lambda req: httpx.Response(200, json={"oops": 1})))
    with pytest.raises(LLMError, match="неожиданный ответ"):
        await client.chat_json([{"role": "user", "content": "x"}])
    await client.aclose()


# ---------------------------------------------------- пустые think-блоки

OPEN_TAG = "<" + "think>"
CLOSE_TAG = "</" + "think>"


def test_strip_empty_think_removes_tags() -> None:
    """Qwen3-14B/8B печатают пустые теги даже при --reasoning-format none."""
    from app.llm import strip_empty_think

    src = OPEN_TAG + "\n\n" + CLOSE_TAG + "\n\nНу привет."
    assert strip_empty_think(src) == "Ну привет."


def test_strip_empty_think_does_not_trim_plain_text() -> None:
    """Функция убирает только теги; пробелы по краям — забота вызывающего кода."""
    from app.llm import strip_empty_think

    assert strip_empty_think("  ordinary text  ") == "  ordinary text  "
    assert strip_empty_think("") == ""


def test_strip_empty_think_keeps_nonempty_reasoning() -> None:
    """Содержательные рассуждения прятать нельзя: их надо видеть в логе и в оценке."""
    from app.llm import strip_empty_think

    text = OPEN_TAG + "\nThinking Process: 1. Analyze\n" + CLOSE_TAG + "\nОтвет."
    assert strip_empty_think(text) == text


def test_strip_empty_think_handles_special_tokens_inside() -> None:
    """Блок с мусорным спецтокеном внутри не считается пустым — не трогаем."""
    from app.llm import strip_empty_think

    text = OPEN_TAG + "<" + "|fim_suffix|" + ">" + CLOSE_TAG + "Раз. Два."
    assert strip_empty_think(text) == text


def test_strip_empty_think_handles_multiple_blocks() -> None:
    from app.llm import strip_empty_think

    src = OPEN_TAG + "\n \n" + CLOSE_TAG + "Раз. " + OPEN_TAG + "\n" + CLOSE_TAG + "Два."
    # хвостовой \s* в паттерне съедает пробел ПЕРЕД следующим блоком —
    # поэтому склеивается без пробела. Это ожидаемое поведение.
    assert strip_empty_think(src) == "Раз.Два."


def test_llm_module_compiles_without_syntax_warnings() -> None:
    r"""Регрессия: ``"\s"`` в обычной строке давал SyntaxWarning на Python 3.12.

    Предупреждение печаталось в лог ядра при каждом старте и пугало оператора.
    Строки регулярных выражений обязаны быть raw.
    """
    import importlib
    import warnings

    from app import llm

    with warnings.catch_warnings():
        warnings.simplefilter("error", SyntaxWarning)
        importlib.reload(llm)
