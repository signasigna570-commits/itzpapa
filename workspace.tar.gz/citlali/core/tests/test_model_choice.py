"""Тесты правила выбора модели (scripts/compare_summary.py, поправка A-1).

Это детерминированное продуктовое решение, а не «посоветовал и забыл»:
ошибка здесь стоит оператору 9 GB диска и часа ожидания.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "scripts"))

from compare_summary import load_rows, recommend, render


def row(
    name: str,
    *,
    size_gb: float,
    tps: float,
    free_mb: float = 2048,
    used_mb: float = 8000,
    status: str = "ok",
) -> dict:
    return {
        "model_file": name,
        "model_size_gb": size_gb,
        "ctx": 8192,
        "status": status,
        "tps_median": tps,
        "tps_min": tps - 2,
        "vram_used_mb": used_mb,
        "vram_total_mb": 12288,
        "vram_free_mb": free_mb,
        "nfr_tps_pass": tps >= 25.0,
    }


B14 = "Qwen3-14B-Q4_K_M.gguf"
B8 = "Qwen3-8B-Q4_K_M.gguf"
B35 = "Qwen3.5-9B-Q4_K_M.gguf"


def test_prefers_larger_model_when_both_pass() -> None:
    rows = [row(B8, size_gb=5.0, tps=46.8, free_mb=6188), row(B14, size_gb=9.0, tps=27.4)]
    assert B14 in recommend(rows)


def test_falls_back_to_smaller_when_big_is_slow() -> None:
    rows = [row(B8, size_gb=5.0, tps=46.8, free_mb=6188), row(B14, size_gb=9.0, tps=11.2)]
    assert B8 in recommend(rows)


def test_falls_back_to_smaller_when_big_has_no_vram_headroom() -> None:
    rows = [
        row(B8, size_gb=5.0, tps=46.8, free_mb=6188),
        row(B14, size_gb=9.0, tps=27.4, free_mb=300, used_mb=11900),
    ]
    assert B8 in recommend(rows)


def test_no_vram_headroom_anywhere_still_recommends_biggest() -> None:
    rows = [
        row(B8, size_gb=5.0, tps=46.8, free_mb=400, used_mb=11800),
        row(B14, size_gb=9.0, tps=27.4, free_mb=200, used_mb=12000),
    ]
    text = recommend(rows)
    assert B14 in text
    assert "запаса VRAM нет" in text


def test_startup_failed_is_not_recommended() -> None:
    rows = [
        row(B8, size_gb=5.0, tps=46.8, free_mb=6188),
        row(B14, size_gb=9.0, tps=0.0, status="startup_failed"),
    ]
    text = recommend(rows)
    assert B8 in text
    assert B14 not in text


def test_all_failed_gives_action_plan() -> None:
    rows = [
        row(B8, size_gb=5.0, tps=0.0, status="startup_failed"),
        row(B14, size_gb=9.0, tps=0.0, status="startup_failed"),
    ]
    text = recommend(rows)
    assert "4096" in text
    assert "Vulkan" in text


def test_all_slow_gives_action_plan() -> None:
    rows = [row(B8, size_gb=5.0, tps=9.0), row(B14, size_gb=9.0, tps=6.0)]
    text = recommend(rows)
    assert "25 tok/s" in text
    assert "offloaded" in text


def test_render_has_header_and_all_rows() -> None:
    rows = [row(B8, size_gb=5.0, tps=46.8), row(B14, size_gb=9.0, tps=27.4)]
    text = render(rows)
    lines = text.splitlines()
    assert lines[0].startswith("модель")
    assert lines[1].startswith("-")
    assert any(B8 in line for line in lines)
    assert any(B14 in line for line in lines)


def test_load_rows_skips_broken_json(tmp_path: Path) -> None:
    (tmp_path / "ok.json").write_text(
        '{"model_file": "a.gguf", "tps_median": 30}', encoding="utf-8"
    )
    (tmp_path / "bad.json").write_text("{не json", encoding="utf-8")
    rows = load_rows(tmp_path)
    assert len(rows) == 1
    assert rows[0]["model_file"] == "a.gguf"


# ------------------------------------------------------ A-16: Qwen3.5-9B в A/B


def test_smaller_but_much_faster_wins() -> None:
    """A-16: Qwen3.5-9B (hybrid, 2026) против dense Qwen3-14B (2025).

    Если мелкая модель быстрее более чем в 1.5 раза, размер перестаёт быть
    аргументом: agent-цикл из 5 шагов выигрывает на каждом шаге.
    """
    rows = [
        row(B14, size_gb=9.0, tps=27.0, free_mb=2048),
        row(B35, size_gb=5.68, tps=62.0, free_mb=5000),
    ]
    text = recommend(rows)
    assert B35 in text, text
    assert "быстрее самой крупной" in text


def test_slightly_faster_smaller_does_not_win() -> None:
    """1.44x — ниже порога 1.5: остаёмся на крупной модели."""
    rows = [
        row(B14, size_gb=9.0, tps=27.0, free_mb=2048),
        row(B35, size_gb=5.68, tps=39.0, free_mb=5000),
    ]
    assert B14 in recommend(rows)


def test_exactly_at_threshold_prefers_faster() -> None:
    rows = [
        row(B14, size_gb=9.0, tps=40.0, free_mb=2048),
        row(B35, size_gb=5.68, tps=60.0, free_mb=5000),
    ]
    assert B35 in recommend(rows), "60/40 = 1.5 — порог включительно"


def test_three_way_choice_picks_best_by_rule() -> None:
    rows = [
        row(B8, size_gb=5.03, tps=46.0, free_mb=6000),
        row(B14, size_gb=9.0, tps=27.0, free_mb=2048),
        row(B35, size_gb=5.68, tps=62.0, free_mb=5000),
    ]
    assert B35 in recommend(rows)


def test_fastest_but_no_vram_headroom_still_flagged() -> None:
    rows = [
        row(B14, size_gb=9.0, tps=27.0, free_mb=200, used_mb=12000),
        row(B35, size_gb=5.68, tps=62.0, free_mb=300, used_mb=11900),
    ]
    text = recommend(rows)
    assert B35 in text
    assert "запаса VRAM нет" in text


def test_speed_escape_ratio_is_documented_constant() -> None:
    from compare_summary import SPEED_ESCAPE_RATIO

    assert SPEED_ESCAPE_RATIO == 1.5
