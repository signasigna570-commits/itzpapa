"""Синтаксис `.ps1` проверяется настоящим парсером PowerShell, а не регуляркой.

Грабли 19.10.2026 (четвёртые за Этап 0, и самые дорогие по времени): в строке

    Write-Warn2 ("... move \\"$partial\\" \\"$dest\\" ...")

я экранировал кавычки как в Python/C. В PowerShell `\\"` кавычку НЕ экранирует —
строка разъехалась, и `01_bootstrap.ps1` перестал парситься целиком. Статические
тесты это пропустили: BOM на месте, скобки сбалансированы, файл «выглядит целым».
Ошибка вскрылась бы только на машине оператора — на первом же запуске bootstrap.

Поэтому правило: если в системе есть PowerShell (у оператора — всегда, в CI на
Linux его может не быть), каждый `.ps1` проекта прогоняется через
`[System.Management.Automation.Language.Parser]::ParseFile`, и ошибок должно быть
ноль. Нет PowerShell — тест пропускается, а не падает.
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import pytest

from tests.test_doctor_report import decode_console

REPO = Path(__file__).resolve().parents[2]
PROBE = Path(__file__).resolve().parent / "ps" / "parse_all.ps1"
DIRS = {
    "scripts": REPO / "scripts",
    "core/tests/ps": Path(__file__).resolve().parent / "ps",
}


def powershell_exe() -> str | None:
    for name in ("pwsh", "powershell"):
        found = shutil.which(name)
        if found:
            return found
    return None


PS = powershell_exe()

pytestmark = pytest.mark.skipif(
    PS is None, reason="нет PowerShell — проверка синтаксиса пропускается"
)


def parse_dir(directory: Path) -> list[str]:
    proc = subprocess.run(
        [
            PS,
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(PROBE),
            "-Dir",
            str(directory),
        ],
        capture_output=True,
        timeout=180,
        check=False,
    )
    # A-31: контракт вывода пробы — ASCII, но сообщения парсера PowerShell
    # бывают русскими и приходят в OEM-кодировке окна.
    stdout = decode_console(proc.stdout)
    stderr = decode_console(proc.stderr)
    assert proc.returncode == 0, (
        f"проба не запустилась: rc={proc.returncode}\nSTDOUT:\n{stdout}\nSTDERR:\n{stderr}"
    )
    return [line.strip() for line in stdout.splitlines() if line.strip()]


@pytest.mark.parametrize("name", sorted(DIRS))
def test_every_ps1_parses(name: str) -> None:
    lines = parse_dir(DIRS[name])
    fails = [line for line in lines if line.startswith("FAIL|")]
    assert not fails, (
        f"{name}: PowerShell не смог разобрать .ps1 — скрипт упадёт у оператора:\n  "
        + "\n  ".join(fails)
    )


def test_scripts_dir_actually_scanned() -> None:
    """Защита от «проба отработала по пустому каталогу и радостно сообщила OK»."""
    lines = parse_dir(DIRS["scripts"])
    total = [line for line in lines if line.startswith("TOTAL|")]
    assert total, f"проба не напечатала итог: {lines}"
    parts = total[0].split("|")
    assert int(parts[1]) >= 7, f"в scripts/ найдено всего {parts[1]} .ps1 — ожидалось не меньше 7"
    assert int(parts[2]) == 0, f"{parts[2]} файлов с ошибками синтаксиса"
    known = {line.split("|")[1] for line in lines if line.startswith("OK|")}
    for required in ("01_bootstrap.ps1", "doctor.ps1", "setup_config.ps1", "move_models.ps1"):
        assert required in known, f"{required} не попал в проверку"


def test_probe_itself_is_ascii() -> None:
    for probe in (PROBE, Path(__file__).resolve().parent / "ps" / "find_local_model_probe.ps1"):
        data = probe.read_bytes()
        assert all(b < 128 for b in data), (
            f"{probe.name}: только ASCII — её читают и PS 5.1, и pwsh 7"
        )
