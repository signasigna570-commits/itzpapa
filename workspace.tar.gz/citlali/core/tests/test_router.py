"""Тесты роутера (T3.1 / FR-5) и деструктивных намерений (A-4)."""

from __future__ import annotations

import pytest

from app.router import Router, classify


@pytest.mark.parametrize(
    "text",
    [
        "Ситлали, открой YouTube",
        "открой ютуб",
        "запусти блокнот",
        "Запусти, пожалуйста, калькулятор",
        "включи проводник",
        "покажи процессы",
        "сколько свободное место на диске?",
        "проверь температура видеокарты",
        "прочитай файл notes.txt",
        "выполни команду Get-Date",
        "найди в гугле llama.cpp",
        "создай файл отчёт.txt",
        "открой браузер",
    ],
)
def test_commands_detected(text: str) -> None:
    route = classify(text)
    assert route.kind == "command", text
    assert route.matched, "должно быть хотя бы одно совпадение для диагностики"


@pytest.mark.parametrize(
    "text",
    [
        "привет",
        "как дела?",
        "кто ты такая?",
        "расскажи про себя",
        "объясни, что такое KV-кэш",
        "почему небо голубое?",
        "спасибо",
        "мне скучно",
        "ты меня слышишь?",
        "а открой мне душу",  # глагол есть, цели нет → болтовня
        "что думаешь о цундере?",
        "можешь открыть браузер?",  # вопрос о возможности, а не приказ
        "открой мне глаза на эту ситуацию",
        "",
    ],
)
def test_smalltalk_detected(text: str) -> None:
    assert classify(text).kind == "chat", text


def test_capability_question_is_not_a_command() -> None:
    route = classify("ты умеешь запускать блокнот?")
    assert route.kind == "chat"
    assert route.reason == "asking_about_capability"


def test_destructive_request_is_command_with_flag() -> None:
    route = classify("Удали всё в Downloads")
    assert route.kind == "command"
    assert route.destructive is True
    assert route.reason == "destructive_intent"


def test_destructive_variants_detected() -> None:
    for text in ("стереть папку temp", "форматируй диск D", "снеси всё на рабочем столе"):
        assert classify(text).destructive is True, text


def test_route_event_payload_shape() -> None:
    payload = classify("открой youtube").as_event()
    assert set(payload) == {"kind", "reason", "matched", "destructive"}
    assert payload["kind"] == "command"


def test_router_threshold_configurable() -> None:
    strict = Router(threshold=2)
    assert strict.route("открой").kind == "chat", "один глагол без цели — мало"
    assert strict.route("открой браузер").kind == "command"


def test_unknown_mode_falls_back_to_regex() -> None:
    router = Router(mode="llm")  # LLM-роутер — v2
    assert router.mode == "regex"
    assert router.route("запусти блокнот").kind == "command"
