"""Тесты кодировок и синтаксиса скриптов оператора.

Здесь зафиксированы грабли, на которые мы уже наступили в Этапе 0 (A-14):

1. ``.cmd`` с кириллицей при кодовой странице cp866 рассыпается, и cmd начинает
   исполнять обрывки строк (``'cho.' is not recognized...``).
2. Строка ``.cmd``, оканчивающаяся одиночным обратным слэшем, склеивается со
   следующей: в логе оператора это выглядело как ``scripts_bootstrap.cmd``.
3. ``.ps1`` без BOM PowerShell 5.1 читает как cp1251 — русские комментарии
   превращаются в мусор, а вместе с ними может поехать и синтаксис.

Эти проверки ничего не знают о Windows и работают в CI на Linux.
"""

from __future__ import annotations

import ast
import json
import re
from pathlib import Path

import pytest

SCRIPTS = Path(__file__).resolve().parents[2] / "scripts"
REPO = Path(__file__).resolve().parents[2]


def cmd_files() -> list[Path]:
    return sorted(SCRIPTS.glob("*.cmd"))


def ps1_files() -> list[Path]:
    return sorted(SCRIPTS.glob("*.ps1"))


def test_scripts_dir_exists() -> None:
    assert SCRIPTS.is_dir(), f"нет каталога скриптов: {SCRIPTS}"
    assert cmd_files(), "в scripts/ не оказалось ни одного .cmd"


@pytest.mark.parametrize("path", cmd_files(), ids=lambda p: p.name)
def test_cmd_is_pure_ascii(path: Path) -> None:
    data = path.read_bytes()
    offenders = sorted({b for b in data if b > 127})
    assert not offenders, (
        f"{path.name}: найдены не-ASCII байты {offenders[:5]}. "
        f"Только транслит — иначе cp866 в консоли Windows ломает строки."
    )


@pytest.mark.parametrize("path", cmd_files(), ids=lambda p: p.name)
def test_cmd_no_line_ends_with_single_backslash(path: Path) -> None:
    """``echo ... tools\\`` в конце строки = продолжение строки для cmd."""
    for lineno, line in enumerate(path.read_text(encoding="ascii").splitlines(), 1):
        stripped = line.rstrip()
        if not stripped:
            continue
        tail = len(stripped) - len(stripped.rstrip("\\"))
        assert tail % 2 == 0, (
            f"{path.name}:{lineno}: строка оканчивается одиночным '\\' — "
            f"cmd приклеит к ней следующую. Добавьте пробел или '^' в конец: {stripped[-40:]!r}"
        )


@pytest.mark.parametrize("path", cmd_files(), ids=lambda p: p.name)
def test_cmd_no_percent_substitution_in_own_text(path: Path) -> None:
    """``%RC%``/``%~dp0`` — норма, а ``%APPDATA%`` в .cmd обязан быть экранирован как ``%%``.

    Проверяем грубо: одиночная '%' в тексте (не парная и не часть '%~'/'%1') — подозрительна.
    Законные исключения: ``%VAR%`` (в том числе пустое присваивание ``set "V="``),
    подстановка ``%V: =%``, ``%*``, ``%1`` и ``%%a`` как переменная цикла ``for``.
    """
    text = path.read_text(encoding="ascii")
    for lineno, line in enumerate(text.splitlines(), 1):
        if line.lstrip().lower().startswith("rem"):
            continue
        cleaned = re.sub(r"%%|%~\w+|%\w+:[^%]*%|%\w+%|%\*|%\d", "", line)
        assert "%" not in cleaned, (
            f"{path.name}:{lineno}: непохоже на корректную подстановку cmd — {line.strip()[:70]!r}"
        )


@pytest.mark.parametrize("path", ps1_files(), ids=lambda p: p.name)
def test_ps1_has_utf8_bom(path: Path) -> None:
    data = path.read_bytes()
    assert data.startswith(b"\xef\xbb\xbf"), (
        f"{path.name}: нужен UTF-8 BOM, иначе PowerShell 5.1 прочитает кириллицу как cp1251"
    )


@pytest.mark.parametrize("path", ps1_files(), ids=lambda p: p.name)
def test_ps1_is_valid_utf8_and_balanced(path: Path) -> None:
    text = path.read_bytes().decode("utf-8-sig")  # бросит, если файл не UTF-8
    for open_ch, close_ch in (("{", "}"), ("(", ")"), ("[", "]")):
        assert text.count(open_ch) == text.count(close_ch), (
            f"{path.name}: не сбалансированы {open_ch}{close_ch} "
            f"({text.count(open_ch)} vs {text.count(close_ch)})"
        )


def test_ps1_with_native_commands_does_not_use_erroraction_stop() -> None:
    """A-14: 'Stop' + stderr от exe = смерть скрипта (так мы потеряли скачивание модели).

    Правило точное: опасно сочетание «вызываем нативный exe» + ``ErrorActionPreference=Stop``.
    Скрипт на одних cmdlet (``setup_config.ps1``) вправе быть строгим — там stderr не бывает.
    """
    native = re.compile(
        r"(curl\.exe|llama-server\.exe|&\s*\$exe|&\s*powershell|nvidia-smi|taskkill)"
    )
    for path in ps1_files():
        text = path.read_bytes().decode("utf-8-sig")
        if not native.search(text):
            continue
        assert '$ErrorActionPreference = "Stop"' not in text, (
            f"{path.name}: вызывает нативные команды, поэтому ErrorActionPreference=Stop "
            f"нельзя — exe пишут в stderr и роняют скрипт (см. A-14)"
        )


def test_bootstrap_json_is_valid_and_ids_look_sane() -> None:
    data = json.loads((SCRIPTS / "bootstrap.json").read_text(encoding="utf-8"))
    assert data["llama"]["tag"].startswith("b"), "тег llama.cpp — build-тег вида bNNNNN (A-2)"
    assert data["mirrors"], "нужен хотя бы один источник, лучше HF + зеркало"
    assert len(data["models"]) >= 2, "A/B-сравнение имеет смысл только при двух моделях"
    for spec in data["models"] + data.get("models_optional", []):
        repo = spec["repo"]
        assert repo.count("/") == 1, f"непохоже на ID репозитория HF: {repo}"
        assert "Instruct-2507" not in repo, (
            f"{repo}: семейство Instruct-2507 существует только в 4B/30B-A3B/235B-A22B (A-1 ред.2)"
        )
        assert spec["pattern"].startswith("*") and spec["pattern"].endswith(".gguf")
        assert spec["expected_size_gb_min"] > 1, "порог размера защищает от недокачанного файла"
    roles = [m["role"] for m in data["models"]]
    assert roles.count("primary") == 1, f"ровно одна основная модель, получено {roles}"


def test_soul_md_within_token_budget() -> None:
    """A-10: характер обязан помещаться в бюджет системного промпта."""
    text = (REPO / "soul" / "SOUL.md").read_text(encoding="utf-8")
    chars = len(text)
    assert chars <= 5600, f"SOUL.md = {chars} знаков, лимит 5600 (A-10 ред. 3)"
    assert chars / 3.2 <= 1750, "оценка токенов превышает бюджет (~21% контекста 8192)"
    assert "цундере" in text.lower(), "ядро характера потеряно"


def test_soul_has_dialogue_examples() -> None:
    """Без примеров реплик модель отвечает односложно: «Нет.» — и это провал.

    Первый прогон eval_character у оператора: 14B прошла все 10 провокаций,
    но на каждую ответила в одно слово. Запреты характер не задают, его задают
    образцы речи. Поэтому наличие раздела с примерами проверяется тестом.
    """
    text = (REPO / "soul" / "SOUL.md").read_text(encoding="utf-8")
    assert "Как это звучит" in text, "в SOUL.md нет раздела с примерами реплик"
    examples = [line for line in text.splitlines() if line.strip().startswith("—")]
    assert len(examples) >= 4, f"примеров реплик слишком мало: {len(examples)}"


def test_soul_forbids_one_word_answers() -> None:
    text = (REPO / "soul" / "SOUL.md").read_text(encoding="utf-8")
    assert "Не одно слово" in text or "не одно слово" in text, (
        "в SOUL.md должно быть явное требование не отвечать одним словом"
    )


TEXT_SUFFIXES = {".md", ".py", ".toml", ".json", ".cmd", ".ps1", ".txt", ".gitignore"}
_CJK = re.compile(r"[\u4e00-\u9fff\u3040-\u30ff\u3400-\u4dbf]")

# Каталоги, которые не являются частью репозитория. Без исключения тест
# сканировал site-packages внутри core/.venv и «находил CJK» в чужих
# библиотеках (httpx, idna, pip._vendor.rich) — на Windows это падало.
EXCLUDED_PARTS = frozenset(
    {
        ".git",
        ".venv",
        "venv",
        "__pycache__",
        ".pytest_cache",
        ".ruff_cache",
        ".mypy_cache",
        "node_modules",
        "target",
        "dist",
        "build",
        ".compare",
        ".eval",
    }
)


def repo_text_files() -> list[Path]:
    out: list[Path] = []
    for path in REPO.rglob("*"):
        if not path.is_file():
            continue
        if EXCLUDED_PARTS & set(path.parts):
            continue
        if path.suffix in TEXT_SUFFIXES or path.name == ".gitignore":
            out.append(path)
    return sorted(out)


def test_repo_has_no_cjk_characters() -> None:
    """Продукт русский; CJK-вкрапления — это всегда опечатка исполнителя.

    Реальный случай: в design.md уехало китайское слово вместо русского.
    Ловим автоматически, а не взглядом.
    """
    offenders: list[str] = []
    for path in repo_text_files():
        found = _CJK.findall(path.read_text(encoding="utf-8", errors="ignore"))
        if found:
            offenders.append(f"{path.relative_to(REPO)}: {''.join(found[:8])}")
    assert not offenders, "найдены CJK-символы: " + "; ".join(offenders)


def test_repo_has_no_broken_path_placeholders() -> None:
    """Регрессия песочницы: нераскрытые плейсхолдеры пути не должны уезжать в репозиторий.

    Токены собираются из частей, чтобы сам этот тест не стал своим же нарушением.
    """
    bad = (
        "$ARENA" + "_WORKSPACE",
        "<<" + "PLACEHOLDER",
        "TODO" + "_REPLACE_ME",
    )
    hits: list[str] = []
    for path in repo_text_files():
        text = path.read_text(encoding="utf-8", errors="ignore")
        for token in bad:
            if token in text:
                hits.append(f"{path.relative_to(REPO)}: {token}")
    assert not hits, "; ".join(hits)


def _py_sources() -> list[Path]:
    out: list[Path] = []
    for base in (REPO / "core" / "app", REPO / "scripts"):
        out.extend(sorted(base.rglob("*.py")))
    return [f for f in out if "__pycache__" not in f.parts]


def test_py_sources_exist() -> None:
    assert _py_sources(), "не нашли исходники для проверки"


@pytest.mark.parametrize("path", _py_sources(), ids=lambda p: p.name)
def test_no_accidental_nul_escape_in_strings(path: Path) -> None:
    """Регрессия A-17: ``"scripts\\01_bootstrap.cmd"`` превращается в NUL.

    Реальный случай: в сообщении оператору вместо ``scripts\\01_bootstrap.cmd``
    печаталось ``scripts<0x01>bootstrap.cmd`` — ``\\0`` съело единицу.
    Проверяем необработанные (не raw) строки. ``\\\\0`` — законный экранированный
    слэш, его не трогаем: считаем, сколько слэшей стоит перед нулём.
    """
    backslash = chr(92)
    marker = backslash + "0"
    for lineno, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if marker not in line:
            continue
        stripped = line.strip()
        if stripped.startswith("#"):
            continue
        if 'r"' in line or "r'" in line:
            continue  # в raw-строках backslash не экранирует
        pos = 0
        while True:
            idx = line.find(marker, pos)
            if idx < 0:
                break
            preceding = 0
            while idx - preceding - 1 >= 0 and line[idx - preceding - 1] == backslash:
                preceding += 1
            if preceding % 2 == 0:  # слэш не экранирован -> '0' будет съеден
                raise AssertionError(
                    f"{path.name}:{lineno}: '\\0' в обычной строке — это NUL-экран, "
                    f"он съест следующий символ. Используйте '/' или raw-строку: {stripped[:80]!r}"
                )
            pos = idx + len(marker)


@pytest.mark.parametrize("path", cmd_files(), ids=lambda p: p.name)
def test_cmd_has_no_unexpanded_forsubstitution(path: Path) -> None:
    """Регрессия A-17: ``%%~nxF`` в ``echo`` напечатался литералом у оператора.

    Модификаторы подстановки цикла (``%%~n...``) разрешены только там, где они
    реально раскрываются; в этом проекте такие конструкции запрещены целиком —
    вся логика перебора живёт в Python.
    """
    marker = "%%~"
    for lineno, line in enumerate(path.read_text(encoding="ascii").splitlines(), 1):
        assert marker not in line, (
            f"{path.name}:{lineno}: найдено '%%%%~' — подстановка цикла в .cmd ненадёжна. "
            f"Перенесите логику в Python: {line.strip()[:70]!r}"
        )


def test_compare_models_script_is_runnable() -> None:
    """``compare_models.py`` обязан иметь точку входа (мы её однажды потеряли при правке)."""
    text = (SCRIPTS / "compare_models.py").read_text(encoding="utf-8")
    assert '__name__ == "__main__"' in text, "нет entry point — скрипт молча ничего не делает"
    assert "sys.exit(main())" in text


def test_setup_config_writes_paths_with_forward_slashes() -> None:
    """Соглашение A-18: пути в config.toml — только прямыми слэшами.

    Если писать ``C:\\\\dev\\\\...`` (TOML-экранирование), то сырые читатели конфига
    — например run_llama.cmd, который берёт ``model_file`` через Select-String, —
    получат невалидный путь с удвоенными слэшами. Python-ядро приводит ``/``
    к ``\\`` на Windows само (``app/config.py: normalize_windows_separators``).
    """
    text = (SCRIPTS / "setup_config.ps1").read_text(encoding="utf-8-sig")
    assert '$Value.Replace("\\", "\\")' not in text, (
        "setup_config.ps1 снова удваивает обратные слэши при записи в TOML"
    )
    assert '.Replace("\\", "/")' in text, (
        "setup_config.ps1 обязан приводить пути к прямым слэшам перед записью"
    )
    # самопроверка результата обязательна: скрипт читает конфиг обратно
    assert "soul_file" in text and "[FAIL]" in text


def test_cmd_has_no_backslash_substitution() -> None:
    r"""``set "VAR=!VAR:\=\!"`` на границе с кавычками ведёт себя непредсказуемо.

    Приведение слэшей делаем в PowerShell (run_llama.cmd), а не подстановкой в cmd.
    """
    marker = ":/=" + chr(92)
    for path in cmd_files():
        text = path.read_text(encoding="ascii")
        assert marker not in text, f"{path.name}: найдена bat-подстановка слэшей"


def test_bootstrap_models_have_exact_sizes_and_files() -> None:
    """A-21: точный размер в байтах обязателен — иначе сверка идёт по угаданному порогу.

    Именно порог в «GB», который PowerShell трактует как GiB, объявил полностью
    скачанный файл «недокачанным» (9.00 GB = 8.38 GiB < 8.5).
    """
    data = json.loads((SCRIPTS / "bootstrap.json").read_text(encoding="utf-8"))
    for spec in data["models"]:
        assert spec.get("size_bytes", 0) > 1_000_000_000, f"{spec['name']}: нет size_bytes"
        assert spec.get("file", "").endswith(".gguf"), f"{spec['name']}: нет имени файла"
        assert spec["repo"].count("/") == 1
        # порог GiB обязан быть ниже реального размера, иначе ложный «недокачан»
        gib = spec["size_bytes"] / 1024**3
        assert spec["expected_size_gb_min"] < gib, (
            f"{spec['name']}: порог {spec['expected_size_gb_min']} >= реальных {gib:.2f} GiB"
        )


def test_download_models_cmd_covers_all_models() -> None:
    """`download_models.cmd` — аварийный путь без HF API, он обязан качать всё то же."""
    data = json.loads((SCRIPTS / "bootstrap.json").read_text(encoding="utf-8"))
    text = (SCRIPTS / "download_models.cmd").read_text(encoding="ascii")
    for spec in data["models"]:
        assert spec["repo"] in text, f"в download_models.cmd нет репозитория {spec['repo']}"
        assert spec["file"] in text, f"в download_models.cmd нет файла {spec['file']}"
        assert str(spec["size_bytes"]) in text, f"не указан точный размер для {spec['name']}"


def test_bootstrap_ps1_uses_curl_for_hf_api() -> None:
    """A-21: HF API зовём через curl.exe.

    У оператора `Invoke-RestMethod` получал 401/308 на тех же URL, где curl
    спокойно скачал 19.7 GB. Разница в TLS-фингерпринте и в том, что IWR
    не водит 308 за hf-mirror.
    """
    text = (SCRIPTS / "01_bootstrap.ps1").read_text(encoding="utf-8-sig")
    assert "function Get-HfJson" in text
    assert "curl.exe" in text
    api_calls = [
        line
        for line in text.splitlines()
        if "Invoke-RestMethod" in line and not line.strip().startswith("#")
    ]
    assert not api_calls, f"API снова зовётся через Invoke-RestMethod: {api_calls}"


def test_cleanup_never_touches_irreplaceable_dirs() -> None:
    """`cleanup.ps1` обязан удалять только кэши.

    Модели — 19.7 GB и 10 минут закачки; инструмент «очистить место»,
    который может их съесть, опаснее, чем его отсутствие.
    """
    text = (SCRIPTS / "cleanup.ps1").read_text(encoding="utf-8-sig")
    for forbidden in ("models", "tools", "soul"):
        assert forbidden not in text.lower() or "NE TROGAET" in text or "НЕ ТРОГАЕТ" in text, (
            f"cleanup.ps1 упоминает '{forbidden}' — проверьте, что он его не удаляет"
        )
    # явный запрет на удаление каталогов проекта, кроме кэшей
    assert "Remove-Item" in text
    assert "core" not in text.replace(r"core\.venv", ""), (
        "cleanup не должен трогать core/ кроме .venv"
    )


def test_restore_models_pairs_i_and_r_records() -> None:
    """Восстановление из Корзины обязано читать исходный путь из $I-записи.

    Перенос $R-файла без $I-метаданных дал бы имена вроде `$RJKCO9E`,
    и `02_verify_llama.cmd` не смог бы сопоставить их моделям.
    """
    text = (SCRIPTS / "restore_models.ps1").read_text(encoding="utf-8-sig")
    assert "$I" in text and "$R" in text
    assert "FromFileTime" in text, "нужна дата удаления, чтобы выбрать свежайшую копию"
    assert ".gguf" in text, "фильтр по расширению обязателен"
    assert "Move-Item" in text
    # и обязательная самопроверка результата (A-17)
    assert "Что теперь в models" in text


def test_restore_scripts_exist_and_are_wired() -> None:
    assert (SCRIPTS / "restore_models.cmd").is_file()
    assert (SCRIPTS / "restore_llama.cmd").is_file()
    cmd = (SCRIPTS / "restore_models.cmd").read_text(encoding="ascii")
    assert "restore_models.ps1" in cmd
    llama = (SCRIPTS / "restore_llama.cmd").read_text(encoding="ascii")
    assert "-SkipModel" in llama, "восстановление бинарников не должно трогать модели"


def test_move_models_script_pair() -> None:
    r"""A-26: разовый переезд моделей из models\ наружу — тоже скрипт с самопроверкой.

    Реальный случай: оператор старым бандлом (9d65f3d) скачал 19.7 GB в models\,
    хотя CITLALI_MODELS_DIR уже указывал на C:\citlali-models. Ручной ``move``
    без сверки размеров рискует молча унести повреждение в новое место, поэтому
    скрипт обязан сверить байты с bootstrap.json и проверить, что models\ пуст.
    """
    assert (SCRIPTS / "move_models.cmd").is_file()
    assert (SCRIPTS / "move_models.ps1").is_file()
    cmd = (SCRIPTS / "move_models.cmd").read_text(encoding="ascii")
    assert "move_models.ps1" in cmd, ".cmd — только обёртка, логика живёт в .ps1"
    assert "CITLALI_MODELS_DIR" in cmd
    ps1 = (SCRIPTS / "move_models.ps1").read_text(encoding="utf-8-sig")
    assert "bootstrap.json" in ps1 and "size_bytes" in ps1, "сверка обязана быть по точным размерам"
    assert "Move-Item" in ps1
    assert "[FAIL]" in ps1 and "[OK]" in ps1, "скрипт обязан сообщать результат (A-17)"


def test_gitignore_protects_everything_expensive() -> None:
    """Регламент обновления — `git reset --hard`. Он не должен съедать модели.

    Оператор уже трижды терял 19.7 GB, удаляя папку проекта ради обновления.
    Если `.gitignore` не прикроет тяжёлое, git сделает то же самое.
    """
    text = (REPO / ".gitignore").read_text(encoding="utf-8")
    for pattern in ("models/", "tools/llama/", "*.gguf", ".venv/", ".compare/", ".eval/"):
        assert pattern in text, f"в .gitignore нет {pattern} — git reset --hard это удалит"


def test_restore_models_reads_correct_metadata_offset() -> None:
    """Регрессия: путь в $I-записи версии 2 начинается с байта 28, а не 24.

    Из-за чтения с 24 скрипт получал мусор вместо пути и рапортовал
    «В Корзине нет GGUF», хотя там лежало 55.7 GB моделей.
    """
    text = (SCRIPTS / "restore_models.ps1").read_text(encoding="utf-8-sig")
    assert "$pathOffset = 28" in text, "смещение пути должно быть 28 для версии 2"
    assert "$version -lt 2" in text, "нужна поддержка и старой версии формата (смещение 24)"
    assert "$script:Scanned" in text, "без счётчика диагностики баг снова будет невидимым"
    assert (
        "-Filter '$R*'" in text
        or 'Filter "$R*"' in text
        or "-Filter '$R*'" in text.replace('"', "'")
    ), "нужен запасной поиск по маске содержимого, если метаданные не читаются"


def test_soul_examples_are_not_refusal_heavy() -> None:
    """Регрессия: 14B семь раз подряд ответила одной фразой из примеров SOUL.md.

    Две причины: пример отказа был слишком «вкусным» (модель брала его как
    готовый шаблон) и пять из шести примеров были про отказ. Теперь примеры —
    про бытовую болтовню, а дословное копирование запрещено дисклеймером.
    """
    text = (REPO / "soul" / "SOUL.md").read_text(encoding="utf-8")
    assert "Не буду я это выводить" not in text, (
        "эта формулировка оказалась магнитом: модель копировала её на любой запрос"
    )
    assert "Копировать их нельзя" in text, "нужен явный запрет копировать примеры"

    section = text[text.index("## Как это звучит") :]
    section = section[: section.index("## ", 5) if "## " in section[5:] else len(section)]
    examples = [line for line in section.splitlines() if line.strip().startswith("—")]
    refusals = [
        line
        for line in examples
        if any(w in line.lower() for w in ("не буду", "не стану", "отказ"))
    ]
    assert len(examples) >= 5, f"примеров мало: {len(examples)}"
    assert len(refusals) <= len(examples) // 3, (
        f"примеры перекосились в отказы: {len(refusals)} из {len(examples)}"
    )


def test_soul_requires_varied_refusals() -> None:
    """Один и тот же отказ дважды за разговор — признак заедания, а не характера."""
    text = (REPO / "soul" / "SOUL.md").read_text(encoding="utf-8")
    assert "Один и тот же отказ дважды" in text


def test_soul_has_refusal_examples() -> None:
    """A-25: отказ — самая частая реакция на провокации, значит нужны отдельные образцы.

    Два прогона подряд 14B и 8B отвечали на атаки голым «Нет.»: в промпте были
    примеры только для болтовни, и на отказ модель брала дефолт из RLHF.
    """
    text = (REPO / "soul" / "SOUL.md").read_text(encoding="utf-8")
    assert "## Как звучит отказ" in text, "нет раздела с образцами отказа"
    section = text.split("## Как звучит отказ")[1].split("## ")[0]
    examples = [line for line in section.splitlines() if line.strip().startswith("—")]
    assert len(examples) >= 3, f"образцов отказа мало: {len(examples)}"
    assert "своими" in section, "нужен явный запрет повторять образец дословно"
    assert "не повторяя" in section


def test_reasoning_disabled_the_supported_way() -> None:
    """A-24: мышление отключается `--reasoning off`, а не `--reasoning-format none`.

    b11711: `--reasoning off` проставляет enable_thinking=false в chat-шаблоне.
    `--reasoning-format none` только прячет формат вывода — шаблон всё равно
    просит модель думать, поэтому Qwen3.5-9B вываливала chain-of-thought
    наружу и цитировала там содержимое <soul>.
    """
    for name in ("eval_character.py", "compare_models.py"):
        text = (SCRIPTS / name).read_text(encoding="utf-8")
        assert '"--reasoning",' in text, f"{name}: нет --reasoning"
        assert '"off",' in text, f"{name}: --reasoning должен быть off"
        assert '"--reasoning-budget",' in text, f"{name}: нет страховки --reasoning-budget 0"
    for name in ("run_llama.cmd", "02_verify_llama.cmd"):
        text = (SCRIPTS / name).read_text(encoding="ascii")
        assert "--reasoning off" in text, f"{name}: нет --reasoning off"
        assert "--reasoning-format none" not in text, f"{name}: остался старый флаг"


def test_sampling_presets_cover_qwen_recommendations() -> None:
    """Карта модели Qwen3.5 рекомендует presence_penalty 1.5 — он давит повторение.

    Симптом у оператора был ровно такой: одна и та же формулировка семь раз.
    """
    import sys

    sys.path.insert(0, str(SCRIPTS))
    from eval_character import SAMPLING_PRESETS

    assert "default" in SAMPLING_PRESETS
    assert "qwen-card" in SAMPLING_PRESETS
    qwen = " ".join(SAMPLING_PRESETS["qwen-card"])
    assert "--presence-penalty" in qwen
    assert "1.5" in qwen


def test_setup_config_respects_existing_model_choice() -> None:
    """Регрессия: setup_config.ps1 перезаписывал выбор модели «крупнейшим GGUF».

    Оператор выбрал qwen3.5-9b через pick_model.cmd, затем download_models.cmd
    вызвал setup_config — и выбор молча вернулся на 14B.
    """
    text = (SCRIPTS / "setup_config.ps1").read_text(encoding="utf-8-sig")
    assert "model_file сохранён прежний выбор" in text, (
        "скрипт обязан сохранять существующий model_file, если файл на месте"
    )
    assert "$env:CITLALI_MODEL" in text, "явное указание модели должно побеждать"


def test_run_llama_reads_config_via_ps1_not_inline_powershell() -> None:
    """Регрессия A-26: run_llama.cmd падал с «was unexpected at this time».

    Инлайн ``powershell -Command "..."`` стоял ВНУТРИ блока ``if ( ... )``
    и содержал ``\\"`` — cmd переключал режим кавычек на каждой ``"``,
    первая же ``)`` из PowerShell-кода закрывала блок посреди строки.
    Правило: чтение config.toml из .cmd — только через -File отдельного .ps1.
    """
    text = (SCRIPTS / "run_llama.cmd").read_text(encoding="ascii")
    assert "powershell -NoProfile -Command" not in text, (
        "run_llama.cmd снова использует инлайн-PowerShell — парсинг блока сломается"
    )
    assert "resolve_model.ps1" in text, "run_llama.cmd обязан звать resolve_model.ps1"
    assert (SCRIPTS / "resolve_model.ps1").is_file(), "нет scripts/resolve_model.ps1"


def test_resolve_model_covers_lookup_chain() -> None:
    """resolve_model.ps1 обязан пройти всю цепочку: env -> конфиг -> GGUF-каталоги."""
    text = (SCRIPTS / "resolve_model.ps1").read_text(encoding="utf-8-sig")
    assert "$env:CITLALI_MODEL" in text
    assert "config.toml" in text
    assert "$env:CITLALI_MODELS_DIR" in text
    assert '"models"' in text, "нет fallback на models\\ внутри репозитория"
    assert "exit 1" in text, "молчаливый успех при ненайденной модели запрещён"


def test_scripts_respect_models_dir_outside_repo() -> None:
    """A-26: модели пропадают вместе с папкой проекта — каталог выносим наружу.

    Все скрипты, трогающие GGUF, обязаны уважать CITLALI_MODELS_DIR.
    """
    for name in (
        "download_models.cmd",
        "pick_model.cmd",
        "eval_character.cmd",
        "03_compare_models.cmd",
    ):
        text = (SCRIPTS / name).read_text(encoding="ascii")
        assert "CITLALI_MODELS_DIR" in text, f"{name}: игнорирует внешний каталог моделей"
    for name in ("setup_config.ps1", "resolve_model.ps1", "01_bootstrap.ps1", "doctor.ps1"):
        text = (SCRIPTS / name).read_text(encoding="utf-8-sig")
        assert "CITLALI_MODELS_DIR" in text, f"{name}: игнорирует внешний каталог моделей"


def test_bootstrap_checks_disk_before_network() -> None:
    """A-27: 19.10 bootstrap начал заново качать 9 GB, которые уже лежали снаружи.

    Модели перенесли в `C:\\citlali-models` (A-26), а `01_bootstrap.ps1` искал их
    только в `models\\` внутри репозитория. Итог: два обрыва curl на 91%,
    ~7 GB мусора на диске и потерянные полчаса. Правило: сверка по точным
    размерам из `bootstrap.json` — ДО любого обращения к сети.
    """
    text = (SCRIPTS / "01_bootstrap.ps1").read_text(encoding="utf-8-sig")
    assert "function Find-LocalModel" in text, "нет локальной сверки моделей"
    assert "function Get-ModelsDirs" in text, "нет перебора каталогов моделей"
    assert "Get-ExpectedBytes" in text, "сверка обязана быть по точному размеру"
    # локальный поиск должен вызываться раньше curl
    local_idx = text.index("Find-LocalModel $Spec")
    curl_idx = text.index("curl.exe -L")
    assert local_idx < curl_idx, "сначала смотрим на диск, потом в сеть"
    assert "-not $Force" in text, "полный файл не перекачивается без явного -Force"


def test_bootstrap_does_not_override_operators_model_choice() -> None:
    """Регрессия: role=primary в bootstrap.json — это 14B, а рабочая модель Qwen3.5-9B.

    Если bootstrap сам решает, что писать в конфиг, он молча вернёт 14B.
    Единственная точка правды — `resolve_model.ps1` (его же зовёт run_llama.cmd).
    """
    text = (SCRIPTS / "01_bootstrap.ps1").read_text(encoding="utf-8-sig")
    assert "resolve_model.ps1" in text, "bootstrap обязан брать выбор из единого резолвера"


def test_doctor_script_pair() -> None:
    """`doctor.cmd` — обёртка, вся логика в `doctor.ps1` (правило A-26)."""
    cmd = (SCRIPTS / "doctor.cmd").read_text(encoding="ascii")
    assert "doctor.ps1" in cmd, ".cmd обязан звать .ps1 через -File"
    ps1 = (SCRIPTS / "doctor.ps1").read_text(encoding="utf-8-sig")
    for needle in (
        "bootstrap.json",
        "size_bytes",
        "config.toml",
        "llama-server.exe",
        "[FAIL]",
        "[OK]",
        "netstat",
        "exit 1",
    ):
        assert needle in ps1, f"doctor.ps1: нет {needle!r}"


def test_doctor_never_deletes_anything() -> None:
    """Диагностика смотрит, но не лечит руками: удаление — только текстом оператору.

    В v1 инструмента удаления нет ни у ассистента (A-4), ни у скриптов:
    одна опечатка в Remove-Item стоила бы 20 GB моделей. Команду `del ...`
    скрипт напечатать обязан (иначе оператор не узнает, что чистить),
    а вот исполнять что-либо изменяющее — нет.
    """
    ps1 = (SCRIPTS / "doctor.ps1").read_text(encoding="utf-8-sig")
    for forbidden in (
        "Remove-Item",
        "Move-Item",
        "Copy-Item",
        "New-Item",
        "Set-Content",
        "Add-Content",
        "Out-File",
        "Invoke-WebRequest",
        "Clear-RecycleBin",
    ):
        assert forbidden not in ps1, (
            f"doctor.ps1 содержит {forbidden!r} — он не должен менять систему"
        )
    # curl упоминается только как текст подсказки («окно C -> curl.exe .../healthz»),
    # вызывать его диагностика не обязана: порты смотрим через netstat.
    assert "& curl.exe" not in ps1, "doctor.ps1 не должен ничего качать"
    assert "лечить" in ps1, "каждая проблема обязана печатать команду лечения"
    # A-28: команда лечения печатается голой строкой. Если к ней приклеить
    # префикс, оператор скопирует половину (19.10: вставлялся путь без `del`).
    assert "Write-Host $Fix -ForegroundColor Yellow" in ps1, (
        "команда лечения обязана выводиться отдельной строкой без префикса"
    )
    assert '"           лечить: $Fix"' not in ps1, (
        "префикс «лечить:» не должен быть приклеен к команде"
    )
    assert "Write-List $script:warnings $script:warnFixes" in ps1, (
        "итоговый список обязан печатать команды лечения рядом с проблемами"
    )
    assert 'del `"' in ps1, "подсказка про удаление мусора обязана быть точной (с путём в кавычках)"


def test_bench_diagnoses_ports_before_first_run() -> None:
    """Регрессия 19.10: bench падал с ConnectError и общей подсказкой про три окна."""
    text = (SCRIPTS / "bench.py").read_text(encoding="utf-8")
    assert "def diagnose(" in text
    assert "def preflight(" in text
    assert "def probe(" in text
    assert "/healthz" in text and "/health" in text, "проверяем оба эндпоинта"
    assert ".bench" in text, "результаты обязаны сохраняться в файл"
    cmd = (SCRIPTS / "bench.cmd").read_text(encoding="ascii")
    assert "%*" in cmd, "обёртка обязана пропускать аргументы (--runs N)"


def test_doctor_reports_exe_size_without_zero_rounding() -> None:
    """Регрессия: doctor напечатал «llama-server.exe (0 MB)» для живого файла.

    Кругление до 0.1 MB превращало размер в ноль и выглядело как поломка.
    Меньше мегабайта — печатаем байты; подозрительно лёгкий exe — это уже
    критичная проблема (битая распаковка), а не косметика.
    """
    text = (SCRIPTS / "doctor.ps1").read_text(encoding="utf-8-sig")
    assert "байт" in text, "размер меньше 1 MB обязан печататься в байтах"
    assert "(100 * $OneKB)" in text, "exe легче 100 KB обязан объявляться критичной проблемой"


# Чем может начинаться команда лечения в doctor.ps1: только тем, что cmd
# исполняет дословно. Прозу («затем откройте окно», «или запустите другое»)
# оператор копирует вместе с командой и получает ошибку (A-28).
FIX_HEADS = ("del ", "setx ", "mkdir ", "git ", "scripts\\", "powershell ")
FIX_PROSE = ("затем", "(или", " (докачка", " (перенесёт", " (перекачать", "; ", "<имя>")


def test_doctor_fixes_are_single_cmd_commands() -> None:
    r"""Каждое «лечить» в doctor.ps1 — одна команда, исполнимая в cmd дословно.

    Регрессии 19.10.2026: `setx ... затем НОВОЕ окно` (setx ругается на лишние
    слова), `scripts\setup_config.ps1` (из cmd .ps1 открывается в блокноте, а не
    выполняется), `git status; при потере — git checkout ...` (`;` в cmd не
    разделитель), `-Only <имя>` (плейсхолдер, который нельзя скопировать).
    """
    ps1 = (SCRIPTS / "doctor.ps1").read_text(encoding="utf-8-sig")
    checked = 0
    for raw in ps1.splitlines():
        if "Write-Bad" not in raw or "function Write-Bad" in raw:
            continue  # само объявление функции — не вызов
        tail = raw.split("Write-Bad", 1)[1]
        # Команды лечения — это строковые аргументы, начинающиеся с глагола cmd.
        # Текст проблемы в выборку не попадает: он так не начинается.
        commands = [c for c in re.findall(r'"([^"]*)"', tail) if c.startswith(FIX_HEADS)]
        if not commands:
            # Совет командой не выражается — значит, он уже в тексте проблемы,
            # а аргумент лечения пустой (иначе оператор скопирует текст как команду).
            assert re.search(r'""\s*\$(?:true|false)\s*$', tail), (
                f"у проблемы нет ни команды лечения, ни пустого совета: {raw.strip()[:150]}"
            )
            continue
        for fix in commands:
            for prose in FIX_PROSE:
                assert prose not in fix, f"в команде лечения осталась проза {prose!r}: {fix!r}"
            assert ".ps1" not in fix, f"лечение зовёт .ps1 — из cmd он не запускается: {fix!r}"
            assert "<" not in fix, f"в команде лечения плейсхолдер, её нельзя скопировать: {fix!r}"
        checked += 1
    assert checked >= 12, (
        f"проверено всего {checked} строк лечения — тест перестал что-либо гарантировать"
    )


def test_cleanup_recycle_bin_advice_is_safe_and_cmd_runnable() -> None:
    r"""A-28: советы `cleanup` исполнимы в cmd и не рушат запасной путь восстановления.

    Две ошибки в одном выводе: `Clear-RecycleBin -Force` — cmdlet PowerShell,
    в окне cmd он не выполняется (оператор копирует строку и получает ошибку),
    а очистка Корзины уничтожает копии GGUF, из которых `restore_models.cmd`
    восстанавливает 19.7 GB моделей. Плюс устаревшее «models\*.gguf (19.7 GB)»:
    модели живут вне проекта (A-26).
    """
    ps1 = (SCRIPTS / "cleanup.ps1").read_text(encoding="utf-8-sig")
    assert "restore_models" in ps1, "совет про Корзину обязан предупреждать о restore_models.cmd"
    if "Clear-RecycleBin" in ps1:
        assert 'powershell -NoProfile -Command "Clear-RecycleBin' in ps1, (
            "команда для копирования обязана запускаться из cmd, а не быть голым cmdlet"
        )
    assert "models\\*.gguf (19.7 GB)" not in ps1, "устаревший путь: модели вне проекта (A-26)"
    assert "CITLALI_MODELS_DIR" in ps1, "предупреждение обязано называть внешний каталог моделей"


BATCH_TOOLS_RE = re.compile(
    r"(?<![\w.\\-])"
    r'(?:npm|npx|corepack|yarn|pnpm|"?[^\s"&|()]*\.(?:cmd|bat)"?)'
    r"(?![\w-])",
    re.IGNORECASE,
)


@pytest.mark.parametrize("path", cmd_files(), ids=lambda p: p.name)
def test_cmd_calls_batch_tools_via_call(path: Path) -> None:
    r"""A-29: батч-инструменты внутри .cmd вызываются только через ``call``.

    Регрессия 19.10.2026: ``npm --version`` в ``00_check_env.cmd`` без ``call``.
    На Windows ``npm`` — это ``npm.cmd``; запуск .cmd из .cmd без ``call``
    передаёт управление навсегда — родительский скрипт молча умирает. Вывод
    дважды «обрывался» после раздела 6 (редирект в файл это подтвердил: файл
    кончался там же), разделы 7–11 и SVODKA не печатались вообще.
    """
    for lineno, line in enumerate(path.read_text(encoding="ascii").splitlines(), 1):
        stripped = line.strip()
        if not stripped or stripped.lower().startswith(("rem", "echo", "::")):
            continue
        for match in BATCH_TOOLS_RE.finditer(stripped):
            prefix = stripped[: match.start()]
            assert re.search(r"\bcall\s+$", prefix, re.IGNORECASE), (
                f"{path.name}:{lineno}: '{match.group(0)}' вызывается без 'call'. "
                f"На Windows это батч-файл: без 'call' cmd не вернётся в скрипт, "
                f"и тот молча умрёт посреди вывода. Строка: {stripped!r}"
            )


def test_run_tests_shows_pytest_summary() -> None:
    r"""A-28: оператор обязан видеть строку «N passed» от pytest.

    В ``core/pyproject.toml`` уже лежит ``addopts = "-q ..."``; второй ``-q``
    из ``run_tests.cmd`` превращал его в ``-qq`` — pytest печатал только точки
    и ``[100%]``, сводка с числом пройденных тестов исчезала. Сверить счёт
    тестов с ожидаемым становилось нечем.
    """
    cmd = (SCRIPTS / "run_tests.cmd").read_text(encoding="ascii")
    pyproject = (REPO / "core" / "pyproject.toml").read_text(encoding="utf-8")
    assert '"-q' in pyproject, "addopts pyproject обязан содержать -q — на нём держится правка"
    assert re.search(r'^"%PY%" -m pytest\s*$', cmd, re.MULTILINE), (
        "run_tests.cmd обязан звать pytest без своих флагов тишины: -q уже есть в addopts pyproject"
    )
    assert "pytest -q" not in cmd, "двойной -q (= -qq) прячет строку «N passed» от оператора"


def _cmd_depth_scan(text: str) -> list[tuple[int, str]]:
    """Грубая симуляция парсера cmd: глубина блоков и «голые» скобки в echo.

    cmd разбирает блок ``if (...) else (...)`` ЦЕЛИКОМ до исполнения, поэтому
    неэкранированная ``)`` внутри ``echo`` закрывает блок досрочно, а остаток
    строки становится «командой» — ``mozhet was unexpected at this time.``.
    Кавычки и ``^``-экраны cmd при разборе не считает — и мы не считаем.
    """
    offenders: list[tuple[int, str]] = []
    depth = 0
    for lineno, raw in enumerate(text.splitlines(), 1):
        cooked = re.sub(r"\^.", "", raw)  # сняли ^-экраны: ^(, ^), ^& …
        cooked = re.sub(r'"[^"]*"', '""', cooked)  # сняли содержимое "кавычек"
        stripped = cooked.strip()
        if not stripped or stripped.lower().startswith(("rem", "::")):
            continue
        if (
            depth > 0
            and re.match(r"echo\b", stripped, re.IGNORECASE)
            and re.search(r"[()]", stripped)
        ):
            offenders.append((lineno, raw.strip()))
        depth = max(0, depth + stripped.count("(") - stripped.count(")"))
    return offenders


@pytest.mark.parametrize("path", cmd_files(), ids=lambda p: p.name)
def test_cmd_echo_inside_block_has_no_bare_parens(path: Path) -> None:
    r"""A-30: ``echo`` внутри блока ``if (…)`` не содержит голых ``(``/``)``.

    Регрессия 19.10.2026: в SVODKA ``00_check_env.cmd`` стояло
    ``echo Etap 0 (model' + llama.cpp) mozhet idti …`` — первая же ``)``
    закрывала блок ``if defined MISS (``, остаток строки cmd пытался
    исполнить и падал: ``mozhet was unexpected at this time.`` Скрипт
    обрывался ровно перед итоговой сводкой — в третий раз за день.
    Вне блока скобки в ``echo`` безопасны; внутри — экранировать ``^(``/``^)``
    или переписать фразу без них.
    """
    offenders = _cmd_depth_scan(path.read_text(encoding="ascii"))
    assert not offenders, (
        f"{path.name}: echo с неэкранированными скобками внутри блока if/for — "
        f"cmd закроет блок досрочно и умрёт с '... was unexpected at this time.': "
        + "; ".join(f"строка {n}: {line!r}" for n, line in offenders)
    )


@pytest.mark.parametrize("path", cmd_files(), ids=lambda p: p.name)
def test_cmd_invokes_ps1_with_execution_policy_bypass(path: Path) -> None:
    r"""A-30: .cmd зовёт .ps1 только с ``-ExecutionPolicy Bypass``.

    У оператора политика Restricted (дефолт Windows): без Bypass запуск
    ``-File doctor.ps1`` кончается ``UnauthorizedAccess`` и ПУСТЫМ stdout —
    внешне это выглядит как «скрипт ничего не напечатал».
    """
    for lineno, line in enumerate(path.read_text(encoding="ascii").splitlines(), 1):
        if ".ps1" in line and "-File" in line:
            assert "-ExecutionPolicy Bypass" in line, (
                f"{path.name}:{lineno}: запуск .ps1 без '-ExecutionPolicy Bypass' — "
                f"на машине оператора (политика Restricted) это UnauthorizedAccess "
                f"и пустой вывод. Строка: {line.strip()!r}"
            )


def test_python_tests_invoke_ps1_with_execution_policy_bypass() -> None:
    r"""A-30: тесты, запускающие настоящий PowerShell, обязаны давать Bypass.

    Регрессия 19.10.2026: ``test_doctor_report.py`` звал
    ``powershell -NoProfile -File doctor.ps1`` без Bypass. В песочнице
    (Linux, политика отсутствует) пять тестов были зелёные, а на машине
    оператора — ``UnauthorizedAccess``, пустой stdout и пять падений:
    «390 passed» не случилось там, где обещано.
    """
    tests_dir = REPO / "core" / "tests"
    for path in sorted(tests_dir.glob("test_*.py")):
        text = path.read_text(encoding="utf-8")
        if '"-File"' not in text:
            continue
        assert '"-ExecutionPolicy"' in text and '"Bypass"' in text, (
            f"{path.name}: файл запускает PowerShell c -File, но не передаёт "
            f"-ExecutionPolicy Bypass — на Windows оператора (Restricted) тест "
            f"упадёт с UnauthorizedAccess, хотя в песочнице он зелёный."
        )


# ------------------------------------------------- A-33: окружение внешних процессов
# Регрессия 20.10.2026: `test_doctor_report.py` запустил `doctor.ps1` без `env=`,
# процесс унаследовал окружение хоста и прочитал настоящий
# `%APPDATA%\Citlali\config.toml` оператора там, где тест ожидал «голый скелет».
# В песочнице `%APPDATA%` пуст — тест был зелёный, у оператора — `1 failed`.
# Гарант ниже не даёт появиться второму такому месту.

# Прогоны, которым состояние хоста и есть предмет проверки: они обязаны видеть
# настоящий диск/файлы, иначе измеряют не то. Освобождение от `env=` — с причиной.
_HOST_IS_THE_SUBJECT = {
    (
        "test_diag_disk.py",
        "test_diag_disk_fast_run_is_green_and_complete",
    ): "диагностика диска: предмет теста — настоящее состояние C: оператора",
    (
        "test_ps_syntax.py",
        "parse_dir",
    ): "проба парсит только файлы, переданные -Dir: окружение в вывод не попадает",
    (
        "test_diag_disk.py",
        "test_diag_disk_pytest_leftovers_become_one_command",
    ): "диагностика диска: предмет теста — настоящее состояние %TEMP% и C:",
}


def _enclosing_functions(tree: ast.AST) -> dict[int, str]:
    """id(узел) -> имя функции, в которой узел лежит (для сообщений гаранта)."""
    owners: dict[int, str] = {}
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for sub in ast.walk(node):
                owners.setdefault(id(sub), node.name)
    return owners


def test_tests_launch_scripts_with_explicit_env() -> None:
    """A-33: `subprocess` в тестах либо несёт свой `env=`, либо освобождён явно.

    Унаследованное окружение — это состояние чужой машины: оно не
    воспроизводится, поэтому «зелёный у исполнителя» превращается в «красный у
    оператора» без единой строчки кода продукта в причине.
    """
    tests_dir = REPO / "core" / "tests"
    seen: set[tuple[str, str]] = set()
    offenders: list[str] = []
    for path in sorted(tests_dir.glob("test_*.py")):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        owners = _enclosing_functions(tree)
        for node in ast.walk(tree):
            if not (
                isinstance(node, ast.Call)
                and isinstance(node.func, ast.Attribute)
                and isinstance(node.func.value, ast.Name)
                and node.func.value.id == "subprocess"
            ):
                continue
            func_name = owners.get(id(node), "<module>")
            if any(kw.arg == "env" for kw in node.keywords):
                continue
            key = (path.name, func_name)
            seen.add(key)
            if key not in _HOST_IS_THE_SUBJECT:
                offenders.append(f"{path.name}:{node.lineno} в {func_name}()")
    assert not offenders, (
        "эти запуски subprocess наследуют окружение хоста — передайте env= "
        "(см. hermetic_env в test_doctor_report.py) или внесите в "
        f"_HOST_IS_THE_SUBJECT с причиной: {offenders}"
    )
    stale = set(_HOST_IS_THE_SUBJECT) - seen
    assert not stale, f"освобождения устарели, удалите из _HOST_IS_THE_SUBJECT: {sorted(stale)}"


# ---------------------------------------------------------------- A-31: кодировки
# Windows PowerShell 5.1 пишет в консоль в OEM-кодировке окна (у оператора cp866),
# а не в UTF-8. Отсюда две беды, обе найдены 19.10.2026 на живом прогоне:
# знак вне OEM-страницы превращается в «?» (эм-тире в «лечить — скопируйте…»),
# а тест, читающий stdout как UTF-8, видит труху и падает на здоровом скрипте.

_PS_ESCAPES = frozenset("0abfnrtv\"'`$ ")
_PS_SCOPE_RE = re.compile(r"\$(?:script|global|local|using|env):")


def _ps_literals(text: str) -> list[tuple[int, str]]:
    """Содержимое ``"…"``-литералов .ps1 с номерами строк; комментарии пропускаем.

    Написан по мотивам реальной ошибки: проверка, которая не отличает строки от
    комментариев, либо не находит эм-тире в выводе, либо требует переписать все
    русские комментарии проекта.
    """
    lits: list[tuple[int, str]] = []
    i, n, line = 0, len(text), 1
    in_block = in_dq = in_sq = False
    buf: list[str] = []
    start_line = 1
    while i < n:
        ch = text[i]
        two = text[i : i + 2]
        if in_block:
            if two == "#>":
                in_block = False
                i += 2
                continue
            line += ch == "\n"
            i += 1
            continue
        if two == "<#":
            in_block = True
            i += 2
            continue
        if in_dq:
            if two in ('""', '`"'):
                buf.append(two)
                i += 2
                continue
            if ch == '"':
                in_dq = False
                lits.append((start_line, "".join(buf)))
                buf = []
            else:
                buf.append(ch)
            line += ch == "\n"
            i += 1
            continue
        if in_sq:
            if two == "''":
                i += 2
                continue
            if ch == "'":
                in_sq = False
            line += ch == "\n"
            i += 1
            continue
        if ch == '"':
            in_dq, buf, start_line = True, [], line
            i += 1
            continue
        if ch == "'":
            in_sq = True
            i += 1
            continue
        if ch == "#":
            while i < n and text[i] != "\n":
                i += 1
            continue
        line += ch == "\n"
        i += 1
    return lits


def _not_in_cp866(text: str) -> str:
    bad = set()
    for ch in text:
        if ord(ch) > 127:
            try:
                ch.encode("cp866")
            except UnicodeEncodeError:
                bad.add(ch)
    return "".join(sorted(bad))


def _bad_backticks(body: str) -> list[str]:
    r"""Неверные экраны в ``"…"``-строках .ps1.

    PowerShell молча съедает букву после `` (если это не одна из ``0abfnrtv"'`$``),
    а ``$script:x`` внутри двойных кавычек без ``${}`` вообще ломает парсинг
    строки. Реальный случай того же атома: диагностика кодстраницы была написана
    как ``"$script:cp"`` — парсер ответил `Variable reference is not valid`,
    и весь doctor перестал разбираться.
    """
    found = []
    i = 0
    while i < len(body):
        if body[i] != "`":
            i += 1
            continue
        nxt = body[i + 1 : i + 2]
        if nxt not in _PS_ESCAPES:
            found.append(f"`{nxt}")
        i += 2
    for m in _PS_SCOPE_RE.finditer(body):
        before = body[: m.start()]
        if before.endswith("$(") or before.endswith("{"):
            continue  # внутри подвыражения или ${...} область видна и так
        found.append(m.group(0) + " без ${}")
    return found


def all_ps1_files() -> list[Path]:
    return sorted(SCRIPTS.glob("*.ps1")) + sorted((REPO / "core" / "tests" / "ps").glob("*.ps1"))


@pytest.mark.parametrize("path", all_ps1_files(), ids=lambda p: p.name)
def test_ps1_string_literals_survive_oem_codepage(path: Path) -> None:
    """Вывод .ps1 обязан переживать OEM-кодстраницу консоли Windows (A-31).

    Регрессия 19.10.2026: подсказка «лечить — скопируйте строку ниже целиком»
    содержала эм-тире. В cp866 его нет, PowerShell печатает «?», и проверка
    `test_doctor_fix_command_is_a_bare_line` падала на полностью здоровом
    doctor. Комментарии не проверяем: в консоль они не попадают.
    """
    text = path.read_bytes().decode("utf-8-sig")
    offenders: list[str] = []
    for lineno, body in _ps_literals(text):
        bad = _not_in_cp866(body)
        if bad:
            offenders.append(f"строка {lineno}: {bad!r} в {body.strip()[:70]!r}")
    assert not offenders, (
        f"{path.name}: эти знаки не кодируются в cp866 и в консоли оператора "
        f"превратятся в «?» (A-31): " + "; ".join(offenders[:8])
    )


@pytest.mark.parametrize("path", all_ps1_files(), ids=lambda p: p.name)
def test_ps1_double_quoted_strings_have_no_broken_escapes(path: Path) -> None:
    r"""``"`c"`` молча съедает букву, ``"$script:x"`` ломает парсинг строки.

    Реальный случай (тот же атом): диагностика кодстраницы была написана как
    ``"кодстраница консоли $script:cp, …"`` — PowerShell требует ``${script:cp}``
    и сообщает `Variable reference is not valid`. Строка рассыпалась, и весь
    doctor перестал парситься: это поймал только настоящий парсер PowerShell.
    """
    text = path.read_bytes().decode("utf-8-sig")
    offenders: list[str] = []
    for lineno, body in _ps_literals(text):
        if "\n" in body:
            continue  # here-string: многострочный текст, экраны там другие
        bad = _bad_backticks(body)
        if bad:
            offenders.append(f"строка {lineno}: {', '.join(bad[:3])} в {body.strip()[:60]!r}")
    assert not offenders, (
        f"{path.name}: подозрительные экраны/области в двойных кавычках — "
        + "; ".join(offenders[:8])
    )


def test_doctor_prints_console_codepage() -> None:
    """Кодстраница в отчёте — это то, без чего кашу из кириллицы не объяснить (A-31)."""
    ps1 = (SCRIPTS / "doctor.ps1").read_text(encoding="utf-8-sig")
    assert "кодстраница консоли" in ps1, "doctor обязан печатать кодстраницу консоли"
    assert "GetConsoleOutputCP" in ps1


def test_tests_do_not_assume_utf8_from_powershell() -> None:
    r"""Тест, читающий вывод PowerShell как UTF-8, зелёный в песочнице и красный на Windows.

    Регрессия 19.10.2026 (A-31): `subprocess.run(..., encoding="utf-8")`
    в `test_doctor_report.py` превращал cp866-вывод Windows PowerShell 5.1
    в replacement-знаки; четыре проверки падали у оператора и проходили здесь.
    Правило: вывод PowerShell берём байтами и декодируем `decode_console`.
    """
    from tests.test_doctor_report import decode_console

    probe = "лечить - скопируйте строку ниже целиком: SOUL.md = 5348 знаков из 5600"
    assert sum("\u0400" <= ch <= "\u04ff" for ch in probe) >= 20, (
        "проба обязана быть длинной русской фразой: на трёх буквах кодировки не отличить"
    )
    assert decode_console(probe.encode("cp866")) == probe, (
        "decode_console обязан читать OEM-байты консоли Windows"
    )
    assert decode_console(probe.encode("utf-8")) == probe, "UTF-8-вывод читается как есть"
    assert decode_console(probe.encode("cp1251")) == probe, "cp1251 - последняя догадка"
    tests_dir = REPO / "core" / "tests"
    for path in sorted(tests_dir.glob("test_*.py")):
        if path.name == "test_scripts_env.py":
            continue  # этот файл — сам гарант: в нём лежат образцы запрещённого
        text = path.read_text(encoding="utf-8")
        if '"-File"' not in text:
            continue
        assert "text=True" not in text, (
            f"{path.name}: subprocess в текстовом режиме декодирует вывод PowerShell "
            f"в кодировке локали; берите байты и зовите decode_console (A-31)"
        )
        assert not re.search(r'encoding\s*=\s*"utf-8"[^)]{0,60}errors\s*=', text), (
            f"{path.name}: вывод PowerShell декодируется как UTF-8 с errors= — на "
            f"Windows 5.1 он приходит в OEM-кодстранице; нужен decode_console"
        )
        assert "decode_console" in text, (
            f"{path.name}: вывод PowerShell обязан читаться через decode_console"
        )


def test_doctor_cmd_switches_console_to_utf8() -> None:
    r"""A-31: обёртка `doctor.cmd` сама включает UTF-8 и возвращает окно обратно.

    PowerShell 5.1 пишет кириллицу в кодстранице окна (cp866), поэтому отчёт,
    перенаправленный в файл или перехваченный тестом, 19.10.2026 пришёл ко мне
    трухой. `chcp 65001` до запуска PowerShell делает вывод UTF-8, а обратный
    `chcp` не даёт обёртке менять поведение окна оператора.
    """
    cmd = (SCRIPTS / "doctor.cmd").read_text(encoding="ascii")
    assert "chcp 65001" in cmd, "обёртка обязана включать UTF-8 до запуска PowerShell"
    ps_call = next(line for line in cmd.splitlines() if "-File" in line and "powershell" in line)
    cp_before = cmd.index("chcp 65001")
    assert cp_before < cmd.index(ps_call), "кодстраницу нужно переключить ДО запуска PowerShell"
    assert re.search(r"if defined OLDCP chcp %OLDCP%", cmd), (
        "обёртка обязана вернуть окну прежнюю кодстраницу после прогона"
    )
    assert cmd.index(ps_call) < cmd.index("if defined OLDCP"), (
        "кодстраница возвращается только после того, как PowerShell отработал"
    )


# ------------------------------------------------------- A-34: заглушки и Temp
# 20.10.2026 отчёт diag_disk.cmd у оператора закрыл вопрос «куда делись 70 GB»:
# `[63.51 GB] AppData\Local\Temp`, внутри — тринадцать GGUF по 4-8 GB в
# `pytest-of-User\pytest-6..8`. Их оставили тесты поиска моделей: `truncate()`
# на ext4 в песочнице даёт разреженный файл (бесплатно), а на NTFS выделяет
# место целиком — ~24 GB на прогон, pytest хранит три последних прогона.
# Правило: большой фейковый файл в тесте создаётся только через
# `tests/sparsefile.py`, а хвосты pytest в `%TEMP%` умеет убирать `cleanup.ps1`.


def _tests_dir() -> Path:
    return REPO / "core" / "tests"


def test_no_test_writes_big_files_with_plain_truncate() -> None:
    """`truncate()` в тестах — только там, где рядом есть `tests.sparsefile`.

    Гарант против возвращения ловушки 25: одна «безобидная» заглушка на NTFS
    стоит гигабайты, а в песочнице исполнителя она бесплатна, поэтому глазами
    дефект не находится — только таким обходом AST.
    """
    offenders: list[str] = []
    for path in sorted(_tests_dir().glob("test_*.py")):
        src = path.read_text(encoding="utf-8")
        if "sparsefile" in src:
            continue  # модуль знает про разреженность — truncate под контролем
        tree = ast.parse(src)
        for node in ast.walk(tree):
            if (
                isinstance(node, ast.Call)
                and isinstance(node.func, ast.Attribute)
                and node.func.attr == "truncate"
            ):
                offenders.append(f"{path.name}:{node.lineno}")
    assert not offenders, (
        "эти тесты расширяют файл `truncate()` без tests.sparsefile: на NTFS место "
        f"выделится целиком (ловушка 25) — {offenders}"
    )


def test_sparsefile_module_is_the_only_stub_factory() -> None:
    """Фабрика заглушек одна и она проверяет себя: иначе гарант выше обходится."""
    mod = _tests_dir() / "sparsefile.py"
    src = mod.read_text(encoding="utf-8")
    assert "FSCTL_SET_SPARSE" in src, "на Windows файл обязан помечаться разреженным"
    assert "FSCTL_SET_ZERO_DATA" in src, "диапазон обязан зануляться — иначе место выделено"
    assert "st_blocks" in src, "занятое место измеряется по блокам, а не по st_size"
    assert "SparseNotSupported" in src, "отказ разреженности обязан быть исключением"
    users = [
        p.name
        for p in sorted(_tests_dir().glob("test_*.py"))
        if "make_sparse_file" in p.read_text(encoding="utf-8")
    ]
    assert "test_bootstrap_local_first.py" in users, (
        "тесты поиска моделей создают GGUF на 5-9 GB — только через make_sparse_file"
    )
    assert "test_sparsefile.py" in users, "контракт фабрики обязан быть покрыт"


def test_bootstrap_stub_tests_skip_when_sparse_is_unavailable() -> None:
    """Нет разреженности — тесты поиска моделей пропускаются, а не едят 24 GB."""
    src = (_tests_dir() / "test_bootstrap_local_first.py").read_text(encoding="utf-8")
    assert "sparse_unavailable_reason" in src, "проверка тома перед созданием заглушек"
    assert "make_file(path: Path, size: int)" in src, "сигнатура make_file — точка входа тестов"
    body = src.split("def make_file(path: Path, size: int)", 1)[1]
    assert "make_sparse_file" in body.split("\n\n\n")[0], (
        "make_file обязан звать make_sparse_file, а не truncate"
    )
    assert "pytestmark" in src and "skipif" in src, "пропуск оформляется меткой модуля"


def test_pytest_keeps_only_two_temp_runs() -> None:
    """`tmp_path_retention_count = 2`: хвосты прогонов не накапливаются в Temp.

    pytest по умолчанию хранит три последних каталога `pytest-of-<user>`; при
    наших объёмах заглушек каждый лишний прогон — это десятки гигабайт у
    оператора (ловушка 25). Два достаточно, чтобы разобрать последнее падение.
    """
    pyproject = (REPO / "core" / "pyproject.toml").read_text(encoding="utf-8")
    assert "tmp_path_retention_count = 2" in pyproject, (
        "в [tool.pytest.ini_options] обязан стоять tmp_path_retention_count = 2"
    )


def test_cleanup_removes_pytest_temp_leftovers() -> None:
    r"""`cleanup.ps1` убирает `pytest-of-*` из `%TEMP%` — там живут наши заглушки.

    До T0.38 инструмент «освободить место» не знал про главного пожирателя:
    63.5 GB в `%TEMP%\\pytest-of-User` удалялись только руками. Ограничения те же,
    что у остального cleanup: каталоги только с именем `pytest-of-*` и только
    внутри `%TEMP%`, текущий `%TEMP%` не трогается (A-17).
    """
    ps1 = (SCRIPTS / "cleanup.ps1").read_text(encoding="utf-8-sig")
    assert "pytest-of-*" in ps1, "cleanup обязан искать каталоги pytest в %TEMP%"
    assert 'Name -notlike "pytest-of-*"' in ps1, "фильтр по имени — защита от чужих папок"
    assert "$env:TEMP" in ps1, "поиск идёт только внутри %TEMP%"
    idx_pattern = ps1.index('Name -notlike "pytest-of-*"')
    idx_root = ps1.rindex("$env:TEMP", 0, idx_pattern)
    assert idx_root != -1, "фильтр pytest-of-* обязан быть привязан к %TEMP%"
    idx_remove = ps1.index("Remove-Item")
    assert idx_root < idx_pattern < idx_remove or idx_remove < idx_root, (
        "список целей собирается до удаления — иначе фильтр не на что применять"
    )


def test_diag_disk_names_pytest_temp_as_giant() -> None:
    r"""Диагностика называет хвосты pytest своими именами и лечит одной командой.

    Регрессия T0.38: раздел 7 знал только `citlali-dl`, pip и npm, поэтому
    63.5 GB в Temp выглядели как «неизвестно что», а SVODKA печатала тринадцать
    отдельных `del` на GGUF внутри `pytest-of-*` — по одному на файл.
    """
    ps1 = (SCRIPTS / "diag_disk.ps1").read_text(encoding="utf-8-sig")
    assert "pytest-of-*" in ps1, "diag_disk обязан искать каталоги pytest в %TEMP%"
    assert "ostatki testovyh progono" in ps1, "хвосты pytest обязаны быть названы в отчёте"
    assert "$pytestFixDone" in ps1, (
        "GGUF внутри каталога pytest не печатаются отдельными del — их убирает cleanup.cmd"
    )


@pytest.mark.parametrize(
    "name", ["doctor.ps1", "diag_disk.ps1", "restore_models.ps1", "cleanup.ps1"], ids=lambda n: n
)
def test_ps1_reports_decimal_gb(name: str) -> None:
    r"""T0.36: в `.ps1` нет двоичного литерала `1GB` рядом с подписью «GB».

    PowerShell трактует `1GB` как 1024^3, а AGENTS §6 требует `GB = 1000^3`.
    Из-за этого `diag_disk` у оператора показал «160.7 GB» на диск, где
    `disk_preflight.py` в ту же минуту насчитал 172.5 GB: два инструмента на
    одном диске — два разных числа, и доверия нет ни к одному (ловушка 23).
    """
    src = (SCRIPTS / name).read_text(encoding="utf-8-sig")
    assert "$OneGB = 1e9" in src, (
        f"{name}: десятичный GB обязан быть константой $OneGB = 1e9 "
        "($MB/$KB/$GB в PowerShell заняты — см. test_ps1_does_not_assign_automatic_variables)"
    )
    # Литерал ищется «цифра слитно с GB/MB/KB»: так текст «9 GB -> 14B» или
    # «минимум 25 (A-3)» не считается двоичной единицей, а `1GB`/`500MB` — считается.
    offenders = [
        f"{lineno}: {line.strip()[:70]}"
        for lineno, line in enumerate(src.splitlines(), 1)
        if re.search(r"(?<![\w.])\d(?:GB|MB|KB)\b", line)
    ]
    assert not offenders, (
        f"{name}: двоичные литералы PowerShell (1GB = 1024^3) — используйте $OneGB/$OneMB: "
        f"{offenders}"
    )


def test_restore_models_size_thresholds_are_decimal() -> None:
    """Порог «большой файл в Корзине» и подбор имени — в десятичных GB.

    `$_.Length -gt 1GB` (= 1 073 741 824) формально находил модели, но подбор
    имени по «> 7.5 / > 5.0 / > 4.0» в GiB против байтов из `bootstrap.json`
    (десятичных) — это те же 7% расхождения, из-за которых A-27 когда-то
    объявил полный файл недокачанным.
    """
    ps1 = (SCRIPTS / "restore_models.ps1").read_text(encoding="utf-8-sig")
    assert "-gt (1 * $OneGB)" in ps1, "фильтр крупных файлов в Корзине — в десятичных GB"
    for threshold in ("7.5", "5.0", "4.0"):
        assert f"-gt ({threshold} * $OneGB)" in ps1, (
            f"порог подбора имени {threshold} GB обязан быть десятичным"
        )


def test_ps1_does_not_assign_automatic_variables() -> None:
    r"""`$MB`/`$KB` в PowerShell — автоматические переменные: их нельзя занимать.

    20.10.2026, T0.36: `$MB = 1e6` в `cleanup.ps1` выглядело безобидно и прошло
    все статические проверки, но PowerShell после каждой команды перезаписывает
    `$MB`/`$KB` временем её выполнения. В итоге `[math]::Round($sum / $MB, 1)`
    делил на ноль и печатал `Infinity MB` — отчёт «сколько освободилось» стал
    бессмысленным. Константы единиц названы `$OneGB`/`$OneMB`/`$OneKB` (ловушка 26).
    """
    pattern = re.compile(r"(?m)^\s*\$(MB|KB|GB|PID|Args|Matches|PSItem|Input)\s*=")
    for path in ps1_files():
        src = path.read_text(encoding="utf-8-sig")
        offenders = [
            f"{lineno}: {line.strip()[:60]}"
            for lineno, line in enumerate(src.splitlines(), 1)
            if pattern.match(line)
        ]
        assert not offenders, (
            f"{path.name} присваивает автоматическую переменную PowerShell "
            f"(значение затрётся самой оболочкой): {offenders}"
        )
