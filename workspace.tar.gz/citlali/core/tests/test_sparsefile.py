"""`tests/sparsefile.py`: заглушка обязана быть бесплатной на диске оператора (T0.38).

20.10.2026 отчёт `diag_disk.cmd` у оператора: `[63.51 GB] AppData\\Local\\Temp`,
внутри — тринадцать GGUF по 4-8 GB в `pytest-of-User\\pytest-6..8`. Их оставили
наши же тесты поиска моделей: `fh.truncate(size)` в песочнице (ext4) создаёт
разреженный файл, а на NTFS — выделяет место целиком. Пять тестов × ~24 GB на
прогон, pytest хранит три последних прогона. Вопрос «куда делись 70 GB» закрылся
одной строкой отчёта.

Тесты ниже фиксируют контракт модуля:
1. `st_size` равен заказанному размеру **точно** (поиск модели сверяет байты с
   `bootstrap.json`, иначе недокачка выглядит как модель);
2. занято на диске (`st_blocks * 512`) — килобайты, а не гигабайты;
3. содержимое читается и равно нулям: файл настоящий, а не «дырка в metadata»;
4. каталоги создаются сами (заглушки лежат в `models\\` и `citlali-models\\`);
5. если разреженность не получилась, модуль **кричит**, а не молча ест диск.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

from tests import sparsefile
from tests.sparsefile import (
    LARGE,
    SparseNotSupported,
    allocated_bytes,
    filesystem_name,
    make_sparse_file,
    sparse_unavailable_reason,
)


def test_allocated_bytes_is_disk_usage_not_length(tmp_path: Path) -> None:
    """`allocated_bytes` — это занятые блоки, а не `st_size`."""
    real = tmp_path / "real.bin"
    real.write_bytes(os.urandom(1024 * 64))
    assert allocated_bytes(real) >= 64 * 1024, "реальный файл обязан занимать свои байты"
    assert allocated_bytes(real) == pytest.approx(real.stat().st_size, rel=0.25)


def test_stub_has_exact_size(tmp_path: Path) -> None:
    """Размер — байт в байт: на нём держится сверка с bootstrap.json (A-27)."""
    size = 5_680_522_464  # Qwen3.5-9B-Q4_K_M.gguf
    p = make_sparse_file(tmp_path / "citlali-models" / "Qwen3.5-9B-Q4_K_M.gguf", size)
    assert p.stat().st_size == size, "логический размер заглушки обязан быть точным"
    assert p.parent.is_dir(), "каталог под заглушку создаётся сам"


def test_stub_costs_almost_nothing_on_disk(tmp_path: Path) -> None:
    """Главная гарантия: 5 GB заглушки не стоят 5 GB диска (ловушка 25).

    Если том не умеет разреженные файлы, тест честно пропускается: падать здесь
    значит требовать от файловой системы того, чего в ней нет.
    """
    reason = sparse_unavailable_reason(tmp_path)
    if reason:
        pytest.skip(reason)
    size = 5_680_522_464
    p = make_sparse_file(tmp_path / "Qwen3.5-9B-Q4_K_M.gguf", size)
    used = allocated_bytes(p)
    assert used <= 1024 * 1024, (
        f"заглушка {size} байт заняла {used} байт на диске — диск оператора снова уедет в ноль"
    )


def test_stub_reads_as_zeros(tmp_path: Path) -> None:
    """Файл настоящий: читается, и в нём нули (а не мусор прежних записей)."""
    reason = sparse_unavailable_reason(tmp_path)
    if reason:
        pytest.skip(reason)
    size = 200 * 1000**2
    p = make_sparse_file(tmp_path / "big.gguf", size)
    with p.open("rb") as fh:
        assert fh.read(4096) == b"\0" * 4096, "начало файла обязано быть нулевым"
        fh.seek(size - 4096)
        assert fh.read(4096) == b"\0" * 4096, "хвост файла обязан быть нулевым"
        fh.seek(0, os.SEEK_END)
        assert fh.tell() == size, "конец файла — ровно заказанный размер"


def test_many_stubs_do_not_eat_disk(tmp_path: Path) -> None:
    """Прогон тестов создаёт ~10 заглушек: суммарно они обязаны стоить мегабайты.

    Именно так выглядела авария: по отдельности каждый файл «невинный»,
    вместе — 63.5 GB в `%TEMP%\\pytest-of-User`.
    """
    reason = sparse_unavailable_reason(tmp_path)
    if reason:
        pytest.skip(reason)
    sizes = [5_680_522_464, 9_001_752_960, 5_027_783_488] * 3
    total_logical = 0
    for i, size in enumerate(sizes):
        make_sparse_file(tmp_path / f"run{i}" / "model.gguf", size)
        total_logical += size
    used = sum(allocated_bytes(p) for p in tmp_path.rglob("model.gguf"))
    assert total_logical > 50 * 1000**3, "сценарий обязан быть крупнее аварии оператора"
    assert used <= 10 * 1024 * 1024, f"{len(sizes)} заглушек заняли {used} байт на диске"


def test_large_stub_without_sparse_support_is_an_error(tmp_path: Path, monkeypatch) -> None:
    """Нет разреженности + большой размер = `SparseNotSupported`, а не молча 5 GB.

    Модуль обязан мешать тесту записать гигабайты: лучше пропуск теста,
    чем полный диск (ловушка 22).
    """
    monkeypatch.setattr(sparsefile, "allocated_bytes", lambda _p: 10 * 1000**3)
    with pytest.raises(SparseNotSupported):
        make_sparse_file(tmp_path / "fake.gguf", LARGE + 1)


def test_sparse_unavailable_reason_reports_failure(tmp_path: Path, monkeypatch) -> None:
    """Причина пропуска — человекочитаемая строка, а не `None` при беде."""

    def boom(_path, _size):
        raise SparseNotSupported("FSCTL_SET_SPARSE не сработал: 50")

    monkeypatch.setattr(sparsefile, "make_sparse_file", boom)
    reason = sparse_unavailable_reason(tmp_path)
    assert reason is not None and "FSCTL_SET_SPARSE" in reason
    assert not (tmp_path / "citlali-sparse-probe.bin").exists(), "проба обязана убираться за собой"


def test_filesystem_name_is_text(tmp_path: Path) -> None:
    """Имя ФС используется в диагнозах: пустая строка допустима, падение — нет."""
    name = filesystem_name(tmp_path)
    assert isinstance(name, str)
    if sys.platform == "win32":  # на машине оператора это NTFS
        assert name.upper() == "NTFS", f"tmp_path оказался не на NTFS: {name!r}"
