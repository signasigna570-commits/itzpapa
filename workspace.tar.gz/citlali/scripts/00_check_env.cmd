@echo off
REM ============================================================
REM  Citlali. Etap 0, shag 1: proverka okruzheniya Windows
REM  Tolko ASCII: kirillitsa v .cmd lomayet kodovuyu stranitsu konsoli.
REM  V konitse - svodka "chego ne khvataet", chtoby ne listat' vyvod.
REM ============================================================
setlocal EnableExtensions EnableDelayedExpansion

set "MISS="

echo.
echo === 1. Windows / arhitektura ===
ver
echo PROCESSOR_ARCHITECTURE=%PROCESSOR_ARCHITECTURE%
if not "%PROCESSOR_ARCHITECTURE%"=="AMD64" set "MISS=!MISS! arhitektura-ne-x64"

echo.
echo === 2. Svobodnoe mesto na diskah (GB) ===
powershell -NoProfile -Command "Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | Select-Object DeviceID, @{n='FreeGB';e={[math]::Round($_.FreeSpace/1GB,1)}}, @{n='SizeGB';e={[math]::Round($_.Size/1GB,1)}} | Format-Table -AutoSize"
echo     Trebovanie Etapa 0: ne meneye 30 GB svobodno (2 modeli + llama.cpp + kesh sborki).

echo.
echo === 3. GPU i draiver NVIDIA ===
powershell -NoProfile -Command "Get-CimInstance Win32_VideoController | Select-Object Name, DriverVersion | Format-Table -AutoSize"
where nvidia-smi >nul 2>nul
if %errorlevel%==0 (
  nvidia-smi --query-gpu=name,driver_version,memory.total,memory.used --format=csv
) else (
  echo [WARN] nvidia-smi ne naiden v PATH. CUDA-sborka mozhet ne zarabotat'; nuzhen draiver NVIDIA.
)

echo.
echo === 4. Git ===
where git >nul 2>nul
if %errorlevel%==0 (git --version) else (echo [MISSING] git & set "MISS=!MISS! git")

echo.
echo === 5. Python 3.11+ (64-bit) ===
where py >nul 2>nul && (py -0p) || (echo     [INFO] launcher 'py' ne naiden)
set "PYOK="
py -3.11 -c "import sys;print('     py -3.11 OK:', sys.version.split()[0])" >nul 2>nul && set "PYOK=py -3.11"
if not defined PYOK py -3.12 -c "import sys;print('     py -3.12 OK:', sys.version.split()[0])" >nul 2>nul && set "PYOK=py -3.12"
if not defined PYOK (
  python -c "import sys;v=sys.version_info;print('     python:', sys.version.split()[0]);sys.exit(0 if (v[0],v[1])>=(3,11) else 1)" >nul 2>nul && set "PYOK=python"
)
if defined PYOK (
  echo [OK] Python najden: !PYOK!
) else (
  echo [MISSING] Python 3.11/3.12 ne najden
  echo     https://www.python.org/downloads/release/python-3119/  ^(otmetit' "Add python.exe to PATH"^)
  set "MISS=!MISS! python"
)

echo.
echo === 6. Node.js 20+ ===
where node >nul 2>nul
if %errorlevel%==0 (
  node --version
  REM A-29: npm na Windows - eto npm.cmd. Bez 'call' upravlenie ne vernyotsya,
  REM i skript molcha umret pryamo zdes. Vsegda zvat batch-cherez 'call'.
  call npm --version
) else (
  echo [MISSING] node
  set "MISS=!MISS! node"
)
echo     Dlya Etapa 2 (Tauri). Node 24 podkhodit; esli sborka upadet - otkatimsya na 20 LTS.

echo.
echo === 7. Rust toolchain (nuzhen dlya Etapa 2) ===
where rustc >nul 2>nul
if %errorlevel%==0 (rustc --version) else (echo [MISSING] rustc & set "MISS=!MISS! rust")
where cargo >nul 2>nul
if %errorlevel%==0 (cargo --version) else (echo [MISSING] cargo & set "MISS=!MISS! rust")
echo     Ustanovka: https://rustup.rs/  (vybrat' default host = x86_64-pc-windows-msvc)

echo.
echo === 8. MSVC (VS Build Tools 2022, C++) ===
powershell -NoProfile -Command "$vswhere='C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe'; if (Test-Path $vswhere) { $p = & $vswhere -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath; if ($p) { Write-Host ('[OK] ' + $p) } else { Write-Host '[MISSING] C++ workload'; exit 3 } } else { Write-Host '[MISSING] vswhere (VS Build Tools ne postavleny)'; exit 3 }"
if errorlevel 1 set "MISS=!MISS! msvc"

echo.
echo === 9. WebView2 Runtime ===
powershell -NoProfile -Command "$k='HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}'; if (Test-Path $k) { Write-Host ('[OK] ' + (Get-ItemProperty $k).pv) } else { Write-Host '[MISSING] WebView2 Runtime'; exit 3 }"
if errorlevel 1 set "MISS=!MISS! webview2"

echo.
echo === 10. Porty 8080 / 8787 / 8090 (dolzhny byt' svobodny DO zapuska) ===
netstat -ano | findstr ":8080 :8787 :8090" | findstr LISTENING
if errorlevel 1 (echo [OK] porty svobodny) else (echo [WARN] kakoy-to port zanyat - zakroyte programm ili pomenyayte port v config.toml)

echo.
echo === 11. Antivirus/Defender: isklucheniya (proverit' rukami) ===
echo     Rekomenduetsya dobavit' v isklucheniya: %~dp0models, %~dp0tools, %APPDATA%\Citlali
echo     Inache Defender blokiruet llama-server i tormozit chtenie GGUF.

echo.
echo ############################################################
echo ## SVODKA
echo ############################################################
if defined MISS (
  echo Ne khvataet:!MISS!
  echo Ustanovite nedostayushchee i povtorite etot skript.
  echo Etap 0 - modeli i llama.cpp - mozhet idti bez Rust/MSVC/WebView2:
  echo oni nuzhny tolko s Etapa 2.
) else (
  echo Vse na meste. Mozhno idti dalej: scripts\01_bootstrap.cmd
)
echo.
echo Prishlite mne ves' vyvod etogo skripta tselikom.

endlocal
