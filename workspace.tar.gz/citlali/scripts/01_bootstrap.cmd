@echo off
REM ============================================================
REM  Citlali. Etap 0, shag 2: skachat' llama.cpp + modeli.
REM  Obertka dlya 01_bootstrap.ps1.
REM  Vnimanie: tolko ASCII. Kirillitsa v .cmd lomayet kodovuyu
REM  stranitsu konsoli (cp866 vs UTF-8) i komandy prevrashchayutsya
REM  v musor tipa "'cho.' is not recognized...".
REM ============================================================
setlocal
cd /d "%~dp0.."
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp001_bootstrap.ps1" %*
set RC=%errorlevel%
echo.
echo Kod vozvrata: %RC%
if not "%RC%"=="0" (
  echo.
  echo Chto delat':
  echo   1. Skopiruyte ves' vyvod vyshe i prishlite mne.
  echo   2. Esli obryv seti - prosto zapustite skript povtorno ^(dokachka s mesta obryva^).
  echo   3. ID repo modeli provereny 17.10.2026. Esli HF nedostupen - zerkalo hf-mirror.com:
  echo      14B : https://huggingface.co/Qwen/Qwen3-14B-GGUF   ^(fayl Qwen3-14B-Q4_K_M.gguf, 9.0 GB^)
  echo      8B  : https://huggingface.co/Qwen/Qwen3-8B-GGUF    ^(fayl Qwen3-8B-Q4_K_M.gguf, 5.03 GB^)
  echo      Zerkalo: zamenite huggingface.co na hf-mirror.com v teh zhe ssylkakh.
  echo      GGUF kladyom v models, binarniki - v katalog tools\llama
  echo      NB: stroka v .cmd ne dolzhna zakanchivatsya odinochnym obratnym sleshem -
  echo      cmd schitaet eto prodolzheniem stroki i s'yest sleduyushchuyu komandu.
  echo   4. Povtorite shag: scripts\01_bootstrap.cmd
)
endlocal & exit /b %RC%
