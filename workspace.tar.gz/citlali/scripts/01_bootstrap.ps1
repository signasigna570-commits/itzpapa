﻿<#
.SYNOPSIS
  Citlali. Etap 0: skachat' llama.cpp (Windows CUDA) i model' Qwen3 GGUF.

.DESCRIPTION
  - sozdayot tools/llama/ i raspakovivaet tuda binarniki llama.cpp;
  - sozdayot models/ i kachaet GGUF s HuggingFace (s dozkachkoy pri obryve);
  - vse puti i versii chitaet iz scripts/bootstrap.json.

.NOTES
  Zapusk:  powershell -NoProfile -ExecutionPolicy Bypass -File scripts\01_bootstrap.cmd
  Set' nuzhna tolko dlya etogo shaga (skachivanie). Posle - rabotaem oflain.
#>

[CmdletBinding()]
param(
  [switch]$SkipLlama,
  [switch]$SkipModel,
  [switch]$All,
  [switch]$Force,
  [string]$Only = "",
  [string]$HfMirror = "https://huggingface.co"
)

# -All:   brat' VES' spisok iz bootstrap.json, vklyuchaya models_optional.
# -Force: perekkachat' fayl, dazhe esli on uzhe polnyy.
# Bez -All skript (A-27) snachala sveryaet GGUF po tochnym razmeram iz
# bootstrap.json i ne trogaet set' voobshche, esli vse modeli uzhe na diske.

# "Continue", NE "Stop".
# PowerShell 5.1 pri $ErrorActionPreference="Stop" schitayet Lyuboy vyvod v stderr
# nativnoy komandy (curl.exe, llama-server.exe --version) terminal'noy oshibkoy
# i ubivayet skript. Imenno tak etap 0 oborvalsya posle raspakovki llama.cpp,
# ne doydya do skachivaniya modeli. Sobstvennye oshibki my brosayem sami (throw),
# a kod vozvrata nativnykh komand proveryayem cherez $LASTEXITCODE.
$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"   # Invoke-WebRequest bez etogo medlennoe v 10 raz
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Root = Split-Path -Parent $PSScriptRoot
$CfgPath = Join-Path $PSScriptRoot "bootstrap.json"
if (-not (Test-Path $CfgPath)) { throw "Ne naiden $CfgPath" }
$Cfg = Get-Content $CfgPath -Raw -Encoding UTF8 | ConvertFrom-Json

function Write-Step([string]$Msg)  { Write-Host ""; Write-Host "==> $Msg" -ForegroundColor Cyan }
function Write-Ok([string]$Msg)    { Write-Host "    [OK] $Msg" -ForegroundColor Green }
function Write-Warn2([string]$Msg) { Write-Host "    [WARN] $Msg" -ForegroundColor Yellow }

function Get-FreeGb([string]$Path) {
  $drive = (Split-Path -Qualifier $Path)
  $d = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$drive'"
  return [math]::Round($d.FreeSpace / 1GB, 1)
}

# ---------------------------------------------------------------- 0. disk
Write-Step "Proverka svobodnogo mesta"
$free = Get-FreeGb $Root
Write-Host "    Svobodno na $(Split-Path -Qualifier $Root): $free GB"
if ($free -lt 25) {
  Write-Warn2 "Malo mesta (< 25 GB). Popravka A-3: vynesite models/ i tools/ na drugoy disk"
  Write-Warn2 "ili osvobodite mesto. Prodolzhit'? (y/N)"
  $ans = Read-Host
  if ($ans -ne "y") { throw "Prervano pol'zovatelem: net mesta" }
}

# ------------------------------------------------------------- 1. llama.cpp
if (-not $SkipLlama) {
  $tag = $Cfg.llama.tag
  $arch = $Cfg.llama.arch
  $dir = Join-Path $Root $Cfg.llama.dir
  $tmp = Join-Path $env:TEMP "citlali-dl"
  New-Item -ItemType Directory -Force -Path $dir, $tmp | Out-Null

  foreach ($asset in $Cfg.llama.assets) {
    $url = "https://github.com/ggml-org/llama.cpp/releases/download/$tag/$asset"
    $zip = Join-Path $tmp $asset
    Write-Step "Skachivanie $asset"
    if (Test-Path $zip) { Write-Ok "uzhe skachan: $zip" }
    else { Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing }
    Write-Host "    razmer: $([math]::Round((Get-Item $zip).Length/1MB,1)) MB"

    Write-Host "    raspakovka v $dir"
    Expand-Archive -Path $zip -DestinationPath $dir -Force
  }

  # cudart-arkhiv vnutri mozhet lezhat' v podpapke (build/bin/Release) - ploschitim
  Get-ChildItem -Path $dir -Recurse -File |
    Where-Object { $_.DirectoryName -ne $dir } |
    ForEach-Object { Move-Item $_.FullName -Destination $dir -Force -ErrorAction SilentlyContinue }
  Get-ChildItem -Path $dir -Recurse -Directory |
    Sort-Object { $_.FullName.Length } -Descending |
    Remove-Item -Force -Recurse -ErrorAction SilentlyContinue

  $exe = Join-Path $dir "llama-server.exe"
  if (Test-Path $exe) {
    Write-Ok "llama-server naiden: $exe"
    # --version pishet v stderr. PowerShell 5.1 dazhe pri ErrorActionPreference=Continue
    # pechataet ErrorRecord ("NativeCommandError") - kosmetika, no operatora ona pugaet.
    # Glushim lokal'no: SilentlyContinue na vremya vyzova.
    $ver = ""
    try {
      $prevEap = $ErrorActionPreference
      $ErrorActionPreference = "SilentlyContinue"
      $ver = (& $exe --version 2>&1 | Out-String)
      $ErrorActionPreference = $prevEap
    } catch {
      $ErrorActionPreference = "Continue"
    }
    if ($ver) {
      ($ver -split "\r?\n" | Where-Object { $_ -match "\S" } | Select-Object -First 3) |
        ForEach-Object { Write-Host "    $($_.Trim())" }
    }
  } else {
    throw "llama-server.exe ne pojavilsya v $dir - proverte, chto raspakovka proshla"
  }
}

# ------------------------------------------------------------------ 2. modeli
function Get-ModelsDirs {
  # A-26/A-27: modeli zhivut VNE repozitoriya. Poryadok: vneshniy katalog,
  # potom models\ v repo. setx pishet peremennuyu v reestr, no v tekushchiy
  # process ne popadayet - poetomu chitaem i User, i Machine urovni.
  $dirs = New-Object System.Collections.Generic.List[string]
  $cand = $env:CITLALI_MODELS_DIR
  if (-not $cand) { $cand = [Environment]::GetEnvironmentVariable("CITLALI_MODELS_DIR", "User") }
  if (-not $cand) { $cand = [Environment]::GetEnvironmentVariable("CITLALI_MODELS_DIR", "Machine") }
  if ($cand) { $dirs.Add($cand) }
  $dirs.Add((Join-Path $Root $Cfg.models_dir))
  return $dirs
}

function Get-ExpectedBytes($Spec) {
  # Tochnyy razmer GGUF v baytah - iz bootstrap.json, bez obrashcheniya k HF API.
  if ($Spec.PSObject.Properties.Name -contains "size_bytes" -and $Spec.size_bytes) {
    return [long]$Spec.size_bytes
  }
  return [long]0
}

function Find-LocalModel($Spec) {
  # A-27: poisk uzhe skachannoy modeli PO VSEM katalogam. Bez etogo bootstrap
  # posle perenosa GGUF v C:\citlali-models ne nashel svoi zhe 9 GB v models\
  # i nachal kachat' ih zanovo (obryv na 91 procentah, 7 GB musora na diske).
  $expected = Get-ExpectedBytes $Spec
  foreach ($d in (Get-ModelsDirs)) {
    if (-not (Test-Path -LiteralPath $d)) { continue }
    $paths = New-Object System.Collections.Generic.List[string]
    if ($Spec.PSObject.Properties.Name -contains "file" -and $Spec.file) {
      $paths.Add((Join-Path $d $Spec.file))
    }
    Get-ChildItem -LiteralPath $d -Filter *.gguf -File -ErrorAction SilentlyContinue |
      Where-Object { $_.Name -like $Spec.pattern } |
      ForEach-Object { $paths.Add($_.FullName) }
    foreach ($p in $paths) {
      if (-not (Test-Path -LiteralPath $p)) { continue }
      $len = (Get-Item -LiteralPath $p).Length
      if ($expected -gt 0) {
        if ($len -eq $expected) { return $p }
      } elseif ($len -ge [long]($Spec.expected_size_gb_min * 1GB)) {
        return $p
      }
    }
  }
  return $null
}

function Get-HfJson([string]$Url) {
  # API HuggingFace zovem cherez curl.exe, a ne Invoke-RestMethod.
  # U operatora Invoke-RestMethod poluchal 401/308 na teh zhe URL, gde curl
  # spokojno skachal 19.7 GB: raznica v TLS-finigerprint i v tom, chto IWR
  # ne vodit 308 za hf-mirror. curl est' v Windows 10+ i uzhe dokazal rabotu.
  $tmp = [System.IO.Path]::GetTempFileName()
  try {
    & curl.exe -sSL --fail --max-time 60 -A "citlali-bootstrap/1.0" -o $tmp $Url
    if ($LASTEXITCODE -ne 0) { return $null }
    $raw = Get-Content -LiteralPath $tmp -Raw -Encoding UTF8
    if (-not $raw) { return $null }
    return $raw | ConvertFrom-Json
  } catch {
    return $null
  } finally {
    Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
  }
}

function Get-GgufList([string]$Repo, [string]$Mirror) {
  # Snachala s blobs=true (tam est' tochnyy razmer v baytah),
  # pri otkaze - bez nego (rabotaet prakticheski vsegda).
  foreach ($suffix in @("?blobs=true", "")) {
    $meta = Get-HfJson "$Mirror/api/models/$Repo$suffix"
    if ($meta -and $meta.siblings) { return @($meta.siblings) }
  }
  return @()
}

function Get-RemoteSize($Siblings, [string]$FileName) {
  # Tochnyy razmer faila s HF. Bez nego my ugaadyvali porog v "GB" i poluchali
  # lozhnoe "fayl nedokachan": curl i PowerShell schitayut /1GB kak GiB (1024^3),
  # a razmer na HF ukazhan v desyatichnykh GB (1000^3). 9.0 GB = 8.38 GiB.
  foreach ($sib in $Siblings) {
    $name = Split-Path $sib.rfilename -Leaf
    if ($name -eq $FileName) {
      $size = $sib.size
      if ($size) { return [long]$size }
    }
  }
  return [long]0
}

function Get-AllModelSpecs {
  # -Only <name> ishchet po vsem spetsifikatsiyam (osnovnye + optional, esli est')
  $all = @($Cfg.models)
  if ($Cfg.PSObject.Properties.Name -contains "models_optional") { $all += @($Cfg.models_optional) }
  return $all
}

function Get-Mirrors {
  # poryadok vazhen: snachala HF, potom zerkalo
  if ($script:HfMirror) { return @($script:HfMirror) + @($Cfg.mirrors | Where-Object { $_ -ne $script:HfMirror }) }
  return @($Cfg.mirrors)
}

function Download-Model($Spec, [string]$ModelsDir) {
  # A-27: esli fayl uzhe lezhit na diske i sveren po baytam - set' ne nuzhna.
  $localHit = Find-LocalModel $Spec
  if ($localHit -and -not $Force) {
    Write-Step "Model' '$($Spec.name)' - proverka po disku"
    Write-Ok ("uzhe na meste: $localHit ({0} bayt)" -f (Get-Item -LiteralPath $localHit).Length)
    return $localHit
  }

  $repo = $Spec.repo
  $pattern = $Spec.pattern
  Write-Step "Model' '$($Spec.name)': poisk GGUF v $repo (shablon: $pattern)"

  $siblings = @()
  $mirrorUsed = $null
  foreach ($candidate in @($repo, $Spec.repo_fallback)) {
    if (-not $candidate) { continue }
    foreach ($mir in (Get-Mirrors)) {
      try {
        $siblings = Get-GgufList $candidate $mir
        $repo = $candidate
        $mirrorUsed = $mir
        break
      } catch {
        Write-Warn2 "$candidate @ $mir -> $($_.Exception.Message)"
      }
    }
    if ($siblings.Count -gt 0) { break }
  }
  if ($siblings.Count -eq 0) {
    Write-Warn2 "HF API ne otvetil ni s huggingface.co, ni s hf-mirror.com."
    Write-Warn2 "Eto NE znachit, chto fayly nedostupny: curl.exe obychno kachaet i pri 401 na API."
    Write-Host ""
    Write-Host "    Zapustite otdel'nyy skript bez API (tolko curl, URL zashity v nem):" -ForegroundColor Cyan
    Write-Host "        scripts\download_models.cmd" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "    Ili skachayte fayl vruchnuyu i polozhite v $ModelsDir :"
    Write-Host "        curl.exe -L --fail --retry 5 -C - -o $ModelsDir\$($Spec.name).gguf <url>"
    throw "Ne udalos' poluchit' spisok faylov modeli '$($Spec.name)'"
  }

  $names = @($siblings | ForEach-Object { $_.rfilename })
  $target = $names | Where-Object { $_ -like $pattern } | Select-Object -First 1
  if (-not $target) {
    Write-Host "    Dostupnye GGUF v $repo :"
    $names | Where-Object { $_ -like "*.gguf" } | ForEach-Object { Write-Host "      $_" }
    throw "Ne nashel fayl po shablonu '$pattern'. Vyberite iz spiska i popravyte scripts\bootstrap.json"
  }

  $fileName = Split-Path $target -Leaf
  $dest = Join-Path $ModelsDir $fileName
  $remoteBytes = Get-RemoteSize $siblings $fileName
  # Razmer dlya kontrol'noy sverki: HF API -> size_bytes iz bootstrap.json -> porog v GiB
  $knownBytes = [long]0
  if ($Spec.PSObject.Properties.Name -contains "size_bytes" -and $Spec.size_bytes) {
    $knownBytes = [long]$Spec.size_bytes
  }
  if ($remoteBytes -gt 0) {
    Write-Host ("    tochnyy razmer s HF API: {0:N2} GB ({1} bayt)" -f ($remoteBytes/1e9), $remoteBytes)
  } elseif ($knownBytes -gt 0) {
    Write-Host ("    razmer iz bootstrap.json: {0:N2} GB ({1} bayt)" -f ($knownBytes/1e9), $knownBytes)
  } else {
    Write-Warn2 "tochnyy razmer neizvesten - proverka po minimal'nomu porogu (vozmozhna oshibka GB/GiB)"
  }

  Write-Host "    repo: $repo  (zerkalo: $mirrorUsed)"
  Write-Host "    fayl: $target"

  if (Test-Path -LiteralPath $dest) {
    $localBytes = (Get-Item -LiteralPath $dest).Length
    $expected = if ($remoteBytes -gt 0) { $remoteBytes } else { $knownBytes }
    if ($expected -gt 0) {
      if ($localBytes -eq $expected) {
        Write-Ok ("uzhe skachana polnost'yu: $dest ({0:N2} GiB, {1} bayt)" -f ($localBytes/1GB), $localBytes)
        return $dest
      }
      Write-Warn2 ("razmer ne sovpal: lokal'no {0} bayt, ozhidaetsya {1} bayt - dozakachivayu" -f $localBytes, $expected)
    } else {
      $minBytes = [long]($Spec.expected_size_gb_min * 1GB)   # 1GB v PowerShell = 1 GiB
      if ($localBytes -ge $minBytes) {
        Write-Ok ("uzhe skachana: $dest ({0:N2} GiB)" -f ($localBytes/1GB))
        return $dest
      }
      Write-Warn2 "fayl menshe minimal'nogo poroga - dozakachivayu"
    }
  }

  # Esli v drugom kataloge (naprimer v models\ vnutri proekta) lezhit
  # nedokachannyy fayl s tem zhe imenem - dokachka nachnetsya s nulya.
  # Perenesti ego vygodnee, chem kachat' zanovo: govorym operatoru pryamym tekstom.
  foreach ($otherDir in (Get-ModelsDirs)) {
    if ($otherDir -eq $ModelsDir) { continue }
    $partial = Join-Path $otherDir $fileName
    if (Test-Path -LiteralPath $partial) {
      $pLen = (Get-Item -LiteralPath $partial).Length
      Write-Warn2 ("v $otherDir lezhit nedokachannyy $fileName ({0} bayt)" -f $pLen)
      Write-Warn2 ("chtoby ne kachat' zanovo: move `"$partial`" `"$dest`" i povtorite zapusk")
    }
  }

  Write-Step "Skachivanie $($Spec.name)"
  # curl.exe est' v Windows 10+; -C - dozkachivaet s mesta obryva
  $dlOk = $false
  foreach ($mir in (Get-Mirrors)) {
    $tryUrl = "$mir/$repo/resolve/main/$target"
    Write-Host "    probuyu: $tryUrl"
    & curl.exe -L --fail --retry 3 --retry-delay 5 -C - -o $dest $tryUrl
    if ($LASTEXITCODE -eq 0) { $dlOk = $true; break }
    Write-Warn2 "curl vernul $LASTEXITCODE - probuyu sleduyushchee zerkalo"
  }
  if (-not $dlOk) {
    throw "Ne udalos' skachat' $fileName ni s odnogo zerkala. Povtorite zapusk - dozkachka prodolzhaetsya s mesta obryva."
  }

  $localBytes = (Get-Item -LiteralPath $dest).Length
  $expected = if ($remoteBytes -gt 0) { $remoteBytes } else { $knownBytes }
  if ($expected -gt 0) {
    if ($localBytes -ne $expected) {
      throw ("Fayl nedokachan: {0} bayt iz {1}. Povtorite zapusk - dozkachaetsya s mesta obryva." -f $localBytes, $expected)
    }
    Write-Ok ("gotovo i svereno po baytam: $dest ({0:N2} GiB)" -f ($localBytes/1GB))
  } else {
    $minBytes = [long]($Spec.expected_size_gb_min * 1GB)
    if ($localBytes -lt $minBytes) {
      throw ("Fayl podozritelno malen'kiy: {0:N2} GiB. Povtorite zapusk skripta." -f ($localBytes/1GB))
    }
    Write-Ok ("gotovo: $dest ({0:N2} GiB)" -f ($localBytes/1GB))
  }
  return $dest
}

$primaryModel = $null
$modelsDir = $null
if (-not $SkipModel) {
  $dirs = @(Get-ModelsDirs)
  $modelsDir = $dirs[0]
  New-Item -ItemType Directory -Force -Path $modelsDir | Out-Null

  Write-Step "Katalog modeley (A-26)"
  Write-Host "    rabochiy: $modelsDir"
  if ($dirs.Count -gt 1) { Write-Host "    zapasnoy: $($dirs[1])" }

  $wanted = @($Cfg.models)
  if ($All) { $wanted = @(Get-AllModelSpecs) }
  if ($Only) { $wanted = @(Get-AllModelSpecs | Where-Object { $_.name -eq $Only }) }
  if ($wanted.Count -eq 0) {
    Write-Host "    Dostupnye imena modeley:"
    Get-AllModelSpecs | ForEach-Object { Write-Host "      $($_.name)  ($($_.repo))" }
    throw "-Only '$Only' ne sovpal ni s odnoy model'yu iz bootstrap.json"
  }

  # A-27: snachala sverka po disku, potom set'. Esli vse modeli na meste -
  # ni odnogo zaprosa k HF ne budet (A/B zavershon 19.10, 19.7 GB uzhe skachany).
  $have = 0
  foreach ($spec in $wanted) {
    $hit = Find-LocalModel $spec
    if ($hit) {
      $have++
      Write-Host ("    [OK] {0,-12} uzhe na diske: {1}" -f $spec.name, $hit)
    } else {
      Write-Host ("    [..] {0,-12} na diske net - nuzhno skachat'" -f $spec.name)
    }
  }
  if ($have -eq $wanted.Count -and -not $Force) {
    Write-Ok "vse modeli na meste i svereny po baytam - skachivanie propushcheno"
  }

  $resolved = @{}
  foreach ($spec in $wanted) {
    if ($have -eq $wanted.Count -and -not $Force) { break }
    $path = Download-Model $spec $modelsDir
    if ($path) { $resolved[[string]$spec.name] = $path }
    Write-Host "    svobodno na diske: $(Get-FreeGb $Root) GB"
  }
  foreach ($spec in $wanted) {
    if (-not $resolved.ContainsKey([string]$spec.name)) {
      $hit = Find-LocalModel $spec
      if ($hit) { $resolved[[string]$spec.name] = $hit }
    }
  }
  foreach ($spec in $wanted) {
    if ($spec.role -eq "primary" -and $resolved.ContainsKey([string]$spec.name)) {
      $primaryModel = $resolved[[string]$spec.name]
    }
  }
  if (-not $primaryModel -and $resolved.Count -gt 0) {
    $primaryModel = @($resolved.Values)[0]
  }

  # Rabochaya model' dlya konfiga: vybor operatora iz config.toml vazhnee,
  # chem role=primary iz bootstrap.json (inache bootstrap molcha vernul by 14B
  # vmesto vybrannoy Qwen3.5-9B). Reshaet tot zhe resolve_model.ps1, chto i
  # run_llama.cmd - edinaya tochka pravdy.
  $chosen = $null
  try {
    $rm = & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot "resolve_model.ps1")
    if ($LASTEXITCODE -eq 0 -and $rm) { $chosen = ([string[]]$rm | Select-Object -Last 1) }
  } catch {
    $chosen = $null
  }
  if ($chosen -and (Test-Path -LiteralPath $chosen)) { $primaryModel = $chosen }

  # Propisyvaem model' i SOUL.md v %APPDATA%\Citlali\config.toml.
  # Pravit' TOML regulyarkoy iz PowerShell nel'zya bezopasno ($ i \ v putyakh),
  # poetomu eto delaet otdel'nyy skript: scripts\setup_config.ps1
  if ($primaryModel) { $env:CITLALI_MODEL = $primaryModel }
  $env:CITLALI_SOUL = (Join-Path $Root "soul\SOUL.md")
  $env:CITLALI_DEFAULT_CONFIG = (Join-Path $Root "core\config.default.toml")
  & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot "setup_config.ps1")
  if ($LASTEXITCODE -ne 0) { throw "setup_config.ps1 vernul kod $LASTEXITCODE" }
  Remove-Item Env:\CITLALI_MODEL -ErrorAction SilentlyContinue
}

Write-Step "Itog"
Write-Host "    llama:  $(Join-Path $Root $Cfg.llama.dir)"
foreach ($d in @(Get-ModelsDirs)) {
  if (-not (Test-Path -LiteralPath $d)) { continue }
  $ggufs = @(Get-ChildItem -LiteralPath $d -Filter *.gguf -File -ErrorAction SilentlyContinue)
  if ($ggufs.Count -eq 0) { continue }
  Write-Host "    modeli: $d"
  foreach ($g in $ggufs) {
    Write-Host ("      {0}  {1} GB  ({2} bayt)" -f $g.Name, [math]::Round($g.Length/1GB,2), $g.Length)
  }
}
$repoModels = Join-Path $Root $Cfg.models_dir
$envModels = $env:CITLALI_MODELS_DIR
if ($envModels -and (Test-Path -LiteralPath $repoModels)) {
  $junk = @(Get-ChildItem -LiteralPath $repoModels -Filter *.gguf -File -ErrorAction SilentlyContinue)
  if ($junk.Count -gt 0) {
    $junkGb = [math]::Round((($junk | Measure-Object Length -Sum).Sum)/1GB, 2)
    Write-Warn2 "v models\ lezhat GGUF na $junkGb GB - modeli dolzhny zhit' v $envModels (A-26)."
    Write-Warn2 "Proverte inventar': scripts\doctor.cmd  (on pokazhet, chto iz etogo musor)"
  }
}
Write-Host "    svobodno: $(Get-FreeGb $Root) GB"
Write-Host ""
Write-Host "Sleduyushchiy shag: scripts\doctor.cmd  (sostoyanie), potom scripts\run_llama.cmd + scripts\run_core.cmd" -ForegroundColor Cyan
