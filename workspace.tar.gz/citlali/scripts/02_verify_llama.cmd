@echo off
REM ============================================================
REM  Citlali. Etap 0, shag 3: proverka llama-server + modeli
REM  Isp. argumenty:  %1 = put' k .gguf (esli pustoy - berem pervyy iz models\)
REM                   %2 = kontekst (default 8192)
REM ============================================================
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0.."

set "LLAMA_DIR=tools\llama"
set "CTX=%~2"
if "%CTX%"=="" set "CTX=8192"

echo === 1. Binarniki ===
if not exist "%LLAMA_DIR%\llama-server.exe" (
  echo [FAIL] %LLAMA_DIR%\llama-server.exe ne naiden. Snachala scripts\01_bootstrap.cmd
  exit /b 2
)
echo [OK] %LLAMA_DIR%\llama-server.exe

echo.
echo === 2. CUDA DLL ryadom ===
dir /b "%LLAMA_DIR%\*.dll" | findstr /i "cudart cublas ggml-cuda" >nul
if errorlevel 1 (
  echo [WARN] CUDA DLL ne naideny. Esli vy brali Vulkan-sborku - eto normalno.
) else (
  for /f "delims=" %%f in ('dir /b "%LLAMA_DIR%\*.dll" ^| findstr /i "cudart cublas ggml-cuda"') do echo     %%f
)

echo.
echo === 3. Model' ===
set "MODEL=%~1"
if "%MODEL%"=="" (
  for %%f in (models\*.gguf) do set "MODEL=%%f"
)
if "%MODEL%"=="" (
  echo [FAIL] v models\ net .gguf. Snachala scripts\01_bootstrap.cmd
  exit /b 3
)
if not exist "%MODEL%" (
  echo [FAIL] fail ne naiden: %MODEL%
  exit /b 3
)
powershell -NoProfile -Command "$f = Get-Item -LiteralPath '%MODEL%'; Write-Host ('[OK] ' + $f.Name + '  ' + [math]::Round($f.Length/1GB, 2) + ' GiB  (' + $f.Length + ' bayt)')"

echo.
echo === 4. Zapusk llama-server ^(okno otkroetsya otdel'no^) ===
set "LOGFILE=%TEMP%\citlali-llama-verify.log"
if exist "%LOGFILE%" del "%LOGFILE%"
start "citlali-llama-verify" /D "%LLAMA_DIR%" llama-server.exe ^
  -m "%CD%\%MODEL%" ^
  --host 127.0.0.1 --port 8080 ^
  -ngl 99 -c %CTX% -fa 1 -np 2 --cache-reuse 256 ^
  --jinja --reasoning off --reasoning-budget 0 ^
  > "%LOGFILE%" 2>&1
echo     log: %LOGFILE%

echo.
echo === 5. Zhdem /health ^(do 180 s: zagruzka 9 GB v VRAM^) ===
set /a TRIES=0
:WAIT
set /a TRIES+=1
powershell -NoProfile -Command "try { $r = Invoke-RestMethod -Uri 'http://127.0.0.1:8080/health' -TimeoutSec 3; exit 0 } catch { exit 1 }" >nul 2>nul
if not errorlevel 1 goto HEALTHY
if %TRIES% GEQ 60 (
  echo [FAIL] /health ne otvetil za 180 s.
  echo --- poslednie 40 strok loga ---
  powershell -NoProfile -Command "Get-Content '%LOGFILE%' -Tail 40"
  echo -------------------------------
  echo Tipichnye prichiny:
  echo   * malo VRAM  -^> povtorite s:  scripts\02_verify_llama.cmd "%MODEL%" 4096
  echo   * net CUDA   -^> nuzhna Vulkan-sborka ^(scripts/bootstrap.json: assets_vulkan_fallback^)
  echo   * staryy draiver NVIDIA -^> obnovite draiver
  taskkill /FI "WINDOWTITLE eq citlali-llama-verify*" /T /F >nul 2>nul
  exit /b 4
)
<nul set /p "=."
timeout /t 3 /nobreak >nul
goto WAIT

:HEALTHY
echo.
echo [OK] /health otvechaet posle ~%TRIES% popytok
powershell -NoProfile -Command "$s=(Invoke-RestMethod 'http://127.0.0.1:8080/v1/models'); Write-Host ('    model id: ' + $s.data[0].id)"

echo.
echo === 6. Kontrol'nyy zapros (striming + metrika) ===
powershell -NoProfile -Command ^
  "$body = @{ model='citlali'; messages=@(@{role='user'; content='Skazhi odno slovo.'}); max_tokens=48; temperature=0.2; stream=$false } | ConvertTo-Json -Depth 5;" ^
  "$t0=Get-Date; $r=Invoke-RestMethod -Uri 'http://127.0.0.1:8080/v1/chat/completions' -Method Post -Body $body -ContentType 'application/json'; $dt=((Get-Date)-$t0).TotalSeconds;" ^
  "Write-Host ('    otvet: ' + $r.choices[0].message.content);" ^
  "Write-Host ('    tok/s: ' + [math]::Round($r.usage.completion_tokens/$dt,1) + '  (vsego tokenov: ' + $r.usage.total_tokens + ')');" ^
  "if ($r.usage.completion_tokens/$dt -lt 25) { Write-Host '    [WARN] Nyzhe 25 tok/s - proverka NFR pod voprosom, smotrite -ngl/-fa/-c' }"

echo.
echo === 7. Slushaet li server tol'ko loopback (A-12) ===
netstat -ano | findstr ":8080" | findstr "LISTENING"
netstat -ano | findstr ":8080" | findstr "LISTENING" | findstr "127.0.0.1" >nul
if errorlevel 1 (echo [WARN] port 8080 slushaet NE tolko 127.0.0.1 - prover'te --host) else (echo [OK] tolko 127.0.0.1)

echo.
echo === 8. VRAM posle zagruzki ===
where nvidia-smi >nul 2>nul && (nvidia-smi --query-gpu=memory.total,memory.used,utilization.gpu --format=csv) || (echo     nvidia-smi nedostupen)

echo.
echo === 9. Ostanovka testovogo servera ===
taskkill /FI "WINDOWTITLE eq citlali-llama-verify*" /T /F >nul 2>nul
timeout /t 2 /nobreak >nul
netstat -ano | findstr ":8080" | findstr "LISTENING" >nul && (echo [WARN] port vse eshche zanyat) || (echo [OK] port 8080 svoboden)

echo.
echo Gotovo. Prishlite mne vyvod shagov 5-8 i poslednie 30 strok %LOGFILE%
endlocal
