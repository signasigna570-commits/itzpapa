@echo off
REM ============================================================
REM  Citlali. Etap 0, shag 4: A/B-sravnenie modeley na vashem zheleze
REM
REM  Isp.:  scripts\03_compare_models.cmd              (kontekst 8192, vse GGUF)
REM         scripts\03_compare_models.cmd 4096         (esli 8192 ne vlezaet)
REM
REM  Ves' perebor faylov, zapusk servera, zamery i itogovaya tablica -
REM  v Python (scripts\compare_models.py). V batche ostalsya tolko vybor
REM  interpretatora: podstanovka imeni fayla iz cikla "for" v stroke echo
REM  ne raskryvalas' i pechatala literaly (defekt A-17, punkt 3),
REM  a otlazhivat' eto na mashine operatora nel'zya.
REM
REM  Server podnimaetsya na portu 8090+ i ne meshaet rabochemu na 8080.
REM ============================================================
setlocal EnableExtensions
cd /d "%~dp0.."

set "PY=python"
if exist "core\.venv\Scripts\python.exe" set "PY=core\.venv\Scripts\python.exe"

set "MD=models"
if defined CITLALI_MODELS_DIR set "MD=%CITLALI_MODELS_DIR%"

set "CTX=%~1"
if "%CTX%"=="" set "CTX=8192"

"%PY%" scripts\compare_models.py --models-dir "%MD%" --ctx %CTX%
set RC=%errorlevel%

echo.
if not "%RC%"=="0" (
  echo Kod vozvrata %RC%. Prishlite mne stroki [FAIL] vyshe.
) else (
  echo Prishlite mne svodnuyu tablicu i stroku "Rekomendatsiya" -
  echo ya zafiksirovyi vybor modeli v docs/design.md paragraf 9.
)
endlocal & exit /b %RC%
