@echo off
REM Citlali: zamer NFR-metrik (TTFT, tok/s, RAM).
REM Nuzhny zapushchennye llama-server i Core (scripts\run_llama.cmd + scripts\run_core.cmd).
REM Isp.: scripts\bench.cmd [--runs 10] [--no-proc] [--base-url http://127.0.0.1:8787]
setlocal EnableExtensions
cd /d "%~dp0..\core"
if exist ".venv\Scripts\python.exe" (set "PY=.venv\Scripts\python.exe") else (set "PY=python")
"%PY%" "%~dp0bench.py" %*
set RC=%errorlevel%
echo.
if not "%RC%"=="0" echo Kod vozvrata %RC%: metrik ne dostigli ili yadro ne otvechaet. Sm. poyasneniya vyshe.
endlocal & exit /b %RC%
