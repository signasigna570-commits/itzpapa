"""Замер NFR-метрик Citlali: TTFT, ток/с, RAM (docs/spec.md §6).

Запуск (из Windows, при работающих llama-server и Core):

    scripts\\bench.cmd                # 7 прогонов через 127.0.0.1:8787
    scripts\\bench.cmd --runs 15      # больше прогонов
    scripts\\bench.cmd --no-proc      # без замера памяти процессов

Перед первым прогоном скрипт сам проверяет оба порта (``/health`` модели и
``/healthz`` ядра) и называет конкретное окно, которое не запущено — раньше
оператор получал безличный ``ConnectError`` и подсказку «нужно три окна»,
хотя закрыто было только одно (A-27).

Результаты пишутся в ``.bench/latest.json`` (каталог в .gitignore): цифры из
консоли теряются, а NFR-таблица в docs/design.md §9 обязана быть проверяемой.

Скрипт намеренно не добавляет зависимостей сверх ``core/requirements.txt``:
память процессов на Windows читается из ``tasklist``.
"""

from __future__ import annotations

import argparse
import json
import statistics
import subprocess
import sys
import time
from pathlib import Path

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "core"))

NFR_TTFT_MS = 3000.0  # spec: TTFT < 3 c
NFR_TPS = 25.0  # spec: >= 25 ток/с
NFR_RAM_MB = 1024.0  # spec: UI+Core <= 1 GB (без модели)

DEFAULT_PROMPTS = (
    "Привет. Представься в одном предложении.",
    "Объясни в двух фразах, что такое KV-кэш.",
    "Скажи что-нибудь едкое про мою привычку не закрывать вкладки.",
)


def percentile(values: list[float], pct: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    idx = min(len(ordered) - 1, max(0, round(pct / 100 * (len(ordered) - 1))))
    return float(ordered[idx])


def one_run(base_url: str, prompt: str, token: str | None, timeout_s: float) -> dict[str, float]:
    """Один запрос к /v1/chat: считаем TTFT и скорость по SSE-событиям."""
    headers = {"X-Citlali-Token": token} if token else {}
    ttft_ms = 0.0
    started = time.perf_counter()
    completion_tokens = 0
    prompt_tokens = 0
    stop_reason = "unknown"

    with (
        httpx.Client(timeout=timeout_s) as client,
        client.stream(
            "POST",
            f"{base_url}/v1/chat",
            json={"message": prompt},
            headers=headers,
        ) as resp,
    ):
        resp.raise_for_status()
        event = ""
        for raw in resp.iter_lines():
            line = raw.rstrip("\r")
            if line.startswith("event:"):
                event = line.split(":", 1)[1].strip()
                continue
            if not line.startswith("data:"):
                continue
            try:
                data = json.loads(line.split(":", 1)[1].strip())
            except json.JSONDecodeError:
                continue
            if event == "delta":
                if not ttft_ms:
                    ttft_ms = (time.perf_counter() - started) * 1000
                completion_tokens += max(1, len(str(data.get("text", ""))) // 4)
            elif event == "done":
                stop_reason = str(data.get("stop_reason"))
                completion_tokens = int(data.get("completion_tokens") or completion_tokens)
                prompt_tokens = int(data.get("prompt_tokens") or 0)
                ttft_ms = float(data.get("ttft_ms") or ttft_ms)
            elif event == "error":
                raise RuntimeError(f"Core вернул ошибку: {data}")

    elapsed = time.perf_counter() - started
    gen_seconds = max(elapsed - ttft_ms / 1000, 1e-6)
    return {
        "ttft_ms": ttft_ms,
        "total_s": elapsed,
        "completion_tokens": float(completion_tokens),
        "prompt_tokens": float(prompt_tokens),
        "tps": completion_tokens / gen_seconds if completion_tokens else 0.0,
        "stop_reason_ok": 1.0 if stop_reason == "stop" else 0.0,
    }


def parse_tasklist_csv(text: str, names: tuple[str, ...]) -> dict[str, float]:
    """Разбор вывода ``tasklist /FO CSV /NH`` — чистая функция, её можно тестировать.

    Суммируем RSS по именам образов (``python.exe`` может быть несколько).
    Колонка памяти имеет вид ``"104 928 K"`` — пробелы и суффикс ``K`` снимаем.
    """
    totals: dict[str, float] = {}
    for line in text.splitlines():
        parts = [p.strip('"') for p in line.split('","')]
        if len(parts) < 5:
            continue
        image = parts[0].lower()
        if not any(image.startswith(n.lower()) for n in names):
            continue
        mem = parts[4].replace(" ", "").replace(",", "").upper().removesuffix("K")
        if mem.isdigit():
            totals[image] = totals.get(image, 0.0) + int(mem) / 1024.0
    return {k: round(v, 1) for k, v in totals.items()}


def process_rss_mb(names: tuple[str, ...]) -> dict[str, float]:
    """RSS процессов по данным ``tasklist`` (Windows). Пусто, если не Windows."""
    if sys.platform != "win32":
        return {}
    try:
        out = subprocess.run(
            ["tasklist", "/FO", "CSV", "/NH"],
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        ).stdout
    except (OSError, subprocess.SubprocessError):
        return {}
    return parse_tasklist_csv(out, names)


def verdict(ok: bool) -> str:
    return "PASS" if ok else "FAIL"


def diagnose(llama_ok: bool, core_ok: bool) -> tuple[bool, list[str]]:
    """Что именно не запущено — чистая функция, чтобы её можно было тестировать.

    Регрессия: оператор дважды получал ``ConnectError ... actively refused it``
    и общую подсказку про «три окна», хотя закрыто было только одно из них.
    Диагностика обязана называть конкретное окно.
    """
    if llama_ok and core_ok:
        return True, []
    lines: list[str] = []
    if not llama_ok and not core_ok:
        lines.append("не отвечает НИ модель (8080), НИ ядро (8787) — оба окна закрыты.")
        lines.append("  окно A: scripts\\run_llama.cmd   (модель, порт 8080)")
        lines.append("  окно B: scripts\\run_core.cmd    (ядро, порт 8787)")
    elif not llama_ok:
        lines.append("ядро на 8787 живо, а модель на 8080 — нет.")
        lines.append(
            "  окно A: scripts\\run_llama.cmd   и дождаться 'listening on http://127.0.0.1:8080'"
        )
        lines.append("  загрузка модели занимает ~6 с, не закрывайте окно A во время замера.")
    else:
        lines.append("модель на 8080 жива, а ядро на 8787 — нет.")
        lines.append(
            "  окно B: scripts\\run_core.cmd    и дождаться 'Uvicorn running on http://127.0.0.1:8787'"
        )
        lines.append(
            "  окно B закрывать нельзя: Ctrl+C в нём останавливает ядро "
            "(именно так и получился отказ соединения)."
        )
    lines.append("  окно C: scripts\\bench.cmd — этот замер, запускать последним.")
    return False, lines


def probe(url: str, timeout_s: float = 4.0) -> bool:
    """Жив ли эндпоинт. Любая ошибка сети = не жив (мы не гадаем по кодам)."""
    try:
        with httpx.Client(timeout=timeout_s) as client:
            resp = client.get(url)
        return resp.status_code < 500
    except Exception:
        return False


def preflight(core_url: str, llama_url: str) -> tuple[bool, list[str]]:
    """Проверка обоих портов ДО первого прогона: экономит минуты на холодном старте."""
    llama_ok = probe(f"{llama_url}/health")
    core_ok = probe(f"{core_url}/healthz")
    print(
        f"Проверка: модель {llama_url}/health -> {'жива' if llama_ok else 'НЕТ'}; "
        f"ядро {core_url}/healthz -> {'живо' if core_ok else 'НЕТ'}"
    )
    return diagnose(llama_ok, core_ok)


def main() -> int:
    parser = argparse.ArgumentParser(description="Замер NFR-метрик Citlali")
    parser.add_argument("--base-url", default="http://127.0.0.1:8787")
    parser.add_argument("--llama-url", default="http://127.0.0.1:8080")
    parser.add_argument("--runs", type=int, default=7)
    parser.add_argument("--timeout", type=float, default=180.0)
    parser.add_argument("--token", default=None, help="X-Citlali-Token, если включена авторизация")
    parser.add_argument("--no-proc", action="store_true", help="не мерить RAM процессов")
    parser.add_argument(
        "--json",
        default=None,
        help="куда положить результаты (по умолчанию .bench/latest.json, '-' = не писать)",
    )
    parser.add_argument(
        "--no-preflight",
        action="store_true",
        help="не проверять порты заранее (нужно только для отладки самого bench)",
    )
    args = parser.parse_args()

    if not args.no_preflight:
        ok, hints = preflight(args.base_url, args.llama_url)
        if not ok:
            print("[FAIL] замер не начат: " + hints[0])
            for line in hints[1:]:
                print(line)
            return 2

    print(f"Цель: {args.base_url}  прогонов: {args.runs}")
    runs: list[dict[str, float]] = []
    for i in range(args.runs):
        prompt = DEFAULT_PROMPTS[i % len(DEFAULT_PROMPTS)]
        try:
            metrics = one_run(args.base_url, prompt, args.token, args.timeout)
        except Exception as exc:
            print(f"[FAIL] прогон {i + 1} не удался: {type(exc).__name__}: {exc}")
            _, hints = preflight(args.base_url, args.llama_url)
            if not hints:
                hints = [
                    "оба сервиса отвечают — значит запрос упал уже в работе;",
                    "пришлите мне этот вывод целиком.",
                ]
            for line in hints:
                print("       " + line)
            return 2
        runs.append(metrics)
        print(
            f"  #{i + 1:>2}  TTFT {metrics['ttft_ms']:>6.0f} ms   "
            f"{metrics['tps']:>5.1f} tok/s   "
            f"compl {int(metrics['completion_tokens']):>4} tok   "
            f"total {metrics['total_s']:>5.2f} s"
        )

    ttft = [r["ttft_ms"] for r in runs]
    tps = [r["tps"] for r in runs]
    print("\n=== Медианы (NFR из docs/spec.md §6) ===")
    print(
        f"TTFT      : медиана {statistics.median(ttft):>7.0f} ms"
        f" | p95 {percentile(ttft, 95):>7.0f} ms"
        f"   лимит < {NFR_TTFT_MS:.0f} ms   [{verdict(statistics.median(ttft) < NFR_TTFT_MS)}]"
    )
    print(
        f"Скорость  : медиана {statistics.median(tps):>7.1f} t/s | мин {min(tps):>7.1f} t/s"
        f"   лимит >= {NFR_TPS:.1f} t/s  [{verdict(statistics.median(tps) >= NFR_TPS)}]"
    )
    ok_all = all(r["stop_reason_ok"] for r in runs)
    print(
        f"stop=stop : {sum(int(r['stop_reason_ok']) for r in runs)}/{len(runs)}"
        f"   [{verdict(ok_all)}]"
    )

    ram_ok = True
    rss: dict[str, float] = {}
    core_mb = 0.0
    if not args.no_proc:
        rss = process_rss_mb(("citlali", "python", "llama-server"))
        core_mb = sum(v for k, v in rss.items() if not k.startswith("llama-server"))
        print("\n=== Память процессов (RSS) ===")
        for name, mb in sorted(rss.items()):
            print(f"  {name:<24} {mb:>8.1f} MB")
        if rss:
            print(
                f"  {'Core+UI (без модели)':<24} {core_mb:>8.1f} MB"
                f"   лимит <= {NFR_RAM_MB:.0f} MB   [{verdict(core_mb <= NFR_RAM_MB)}]"
            )
            print(
                "  (в сумме ВСЕ python.exe машины: перед замером закройте лишние — "
                "иначе лимит съест чужой процесс)"
            )
            ram_ok = core_mb <= NFR_RAM_MB
        else:
            print("  (не удалось собрать: запускайте на Windows или используйте --no-proc)")

    passed = (
        statistics.median(ttft) < NFR_TTFT_MS
        and statistics.median(tps) >= NFR_TPS
        and ok_all
        and ram_ok
    )
    print(f"\nИТОГ: {'NFR выполнены' if passed else 'NFR НЕ выполнены'}")
    if not passed:
        print("Что делать:")
        print(
            "  * TTFT высок → проверьте, что -ngl 99 и модель в VRAM (nvidia-smi в момент запроса);"
        )
        print("    включите --reasoning off --reasoning-budget 0; уменьшите -c до 4096.")
        print(
            "  * ток/с низкая → часть слоёв уехала на CPU:"
            " смотрите 'offloaded' в логе llama-server;"
        )
        print("    fallback — Qwen3-8B Q4_K_M (docs/design.md §9).")
        print(
            "  * RAM высок → проверьте, что UI не держит всю историю в DOM"
            " (нужна виртуализация списка)."
        )

    # Результаты кладём в файл: цифры из консоли теряются, а NFR-таблица
    # в docs/design.md §9 обязана быть воспроизводимой (A-17).
    payload = {
        "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "base_url": args.base_url,
        "llama_url": args.llama_url,
        "runs": runs,
        "summary": {
            "n": len(runs),
            "ttft_median_ms": statistics.median(ttft),
            "ttft_p95_ms": percentile(ttft, 95),
            "tps_median": statistics.median(tps),
            "tps_min": min(tps),
            "stop_ok": sum(int(r["stop_reason_ok"]) for r in runs),
            "rss_mb": rss,
            "core_ui_mb": round(core_mb, 1),
            "limits": {"ttft_ms": NFR_TTFT_MS, "tps": NFR_TPS, "ram_mb": NFR_RAM_MB},
            "passed": bool(passed),
        },
    }
    out = args.json
    if out is None:
        out = str(Path(__file__).resolve().parents[1] / ".bench" / "latest.json")
    if out and out != "-":
        out_path = Path(out)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"Результаты записаны: {out_path}")

    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
