@echo off
REM ============================================================
REM  Citlali: bezopasnaya ochistka diska (obertka dlya cleanup.ps1)
REM
REM  Udalyaet tol'ko vosproizvodimoe: %TEMP%\citlali-dl, %TEMP%\pytest-of-*,
REM  kesh pip, __pycache__/.pytest_cache/.ruff_cache.
REM  NE TROGAET models\, tools\llama\, core\.venv, soul\, %APPDATA%\Citlali.
REM
REM  Isp.:  scripts\cleanup.cmd          - pokazat' i udalit'
REM         scripts\cleanup.cmd dry      - tol'ko pokazat'
REM ============================================================
setlocal
cd /d "%~dp0.."

if /i "%~1"=="dry" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0cleanup.ps1" -Dry
) else (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0cleanup.ps1"
)
endlocal
