﻿<#
.SYNOPSIS
  Citlali: безопасная очистка места на диске.

.DESCRIPTION
  Удаляет ТОЛЬКО воспроизводимое:
    * %TEMP%\citlali-dl    — zip-архивы llama.cpp (~650 MB), уже распакованы в tools\llama
    * %TEMP%\pytest-of-*   — хвосты прогонов pytest: наши же заглушки GGUF
                             (20.10.2026 там лежало 63.5 GB, ловушка 25)
    * кэш pip              — wheel'ы, при необходимости скачаются заново
    * __pycache__ / .pytest_cache / .ruff_cache / .mypy_cache внутри репозитория

  НЕ ТРОГАЕТ: models\, tools\llama\, core\.venv, soul\, docs\, %APPDATA%\Citlali.
  Модели — 19.7 GB и 10 минут скачивания; удалять их, чтобы освободить место
  под кэш, — обмен в сто раз невыгоднее.

.PARAMETER Dry
  Только показать, что было бы удалено.

.EXAMPLE
  powershell -NoProfile -ExecutionPolicy Bypass -File scripts\cleanup.ps1 -Dry
#>

[CmdletBinding()]
param([switch]$Dry)

$ErrorActionPreference = "Continue"
$repo = Split-Path -Parent $PSScriptRoot

# T0.36: единицы десятичные (AGENTS пар. 6: GB = 1000^3, MB = 1000^2).
# Имена с One намеренно: $MB/$KB/$GB в PowerShell - автоматические переменные
# ($MB/$KB - время последней команды), присваивание им затирается (ловушка 26).
$OneGB = 1e9
$OneMB = 1e6

$targets = New-Object System.Collections.Generic.List[object]

$tmp = Join-Path $env:TEMP "citlali-dl"
if (Test-Path -LiteralPath $tmp) {
  $targets.Add([PSCustomObject]@{ Path = $tmp; Why = "zip-arkhivy llama.cpp (raspakovany v tools\llama)" })
}

if ($env:LOCALAPPDATA) {
  $pip = Join-Path $env:LOCALAPPDATA "pip\cache"
  if (Test-Path -LiteralPath $pip) {
    $targets.Add([PSCustomObject]@{ Path = $pip; Why = "kesh wheel pip" })
  }
}

# pytest hranit poslednie neskolko progonov v %TEMP%\pytest-of-<user>.
# Vnutri lezhat zaglushki GGUF iz testov poiska modeley: 20.10.2026 otchet
# diag_disk pokazal tam 63.5 GB (lovushka 25). Bezopasno: eto vremennye fayly
# samogo pytest, oni sozdayutsya zanovo pri kazhdom progone.
# Ogranicheniya (A-17): tolko papki s imenem pytest-of-* i tolko vnutri %TEMP%;
# tekushchiy %TEMP% ne trogaem (esli pytest zapushen s --basetemp vnutri nego).
if ($env:TEMP) {
  foreach ($d in Get-ChildItem -LiteralPath $env:TEMP -Directory -Force -ErrorAction SilentlyContinue) {
    if ($d.Name -notlike "pytest-of-*") { continue }
    if ([string]::Equals($d.FullName.TrimEnd('\'), $env:TEMP.TrimEnd('\'),
          [System.StringComparison]::OrdinalIgnoreCase)) { continue }
    $sum = (Get-ChildItem -LiteralPath $d.FullName -Recurse -File -Force -ErrorAction SilentlyContinue |
            Measure-Object Length -Sum).Sum
    if (-not $sum) { $sum = 0 }
    $gb = [math]::Round($sum / $OneGB, 2)
    $targets.Add([PSCustomObject]@{
      Path = $d.FullName
      Why  = ("hvosty progonov pytest: zaglushki GGUF (" + $gb + " GB); sozdadutsya snova")
    })
  }
}

foreach ($name in @("__pycache__", ".pytest_cache", ".ruff_cache", ".mypy_cache")) {
  Get-ChildItem -LiteralPath $repo -Filter $name -Recurse -Directory -Force -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -notmatch "\\\.venv\\" } |
    ForEach-Object { $targets.Add([PSCustomObject]@{ Path = $_.FullName; Why = "kesh instrumentov" }) }
}

$total = 0
foreach ($item in $targets) {
  $sum = (Get-ChildItem -LiteralPath $item.Path -Recurse -File -Force -ErrorAction SilentlyContinue |
          Measure-Object Length -Sum).Sum
  if (-not $sum) { $sum = 0 }
  $total += $sum
  $mb = [math]::Round($sum / $OneMB, 1).ToString().PadLeft(9)
  if ($Dry) {
    Write-Host "    [dry] $mb MB  $($item.Path)"
    Write-Host "            -- $($item.Why)"
  } else {
    Remove-Item -LiteralPath $item.Path -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "    [ok ] $mb MB  $($item.Path)"
  }
}

Write-Host ""
if ($Dry) {
  Write-Host ("Vsego k ochistke: {0} MB. Zapustite bez -Dry dlya udaleniya." -f [math]::Round($total / $OneMB, 1))
} else {
  Write-Host ("Osvobozhdeno: {0} MB" -f [math]::Round($total / $OneMB, 1))
}

Write-Host ""
Write-Host "Esli nuzhno bolshe mesta (vypolnyaetsya otdelno):"
Write-Host "    Windows Update kesh:  cleanmgr  (ili Parametry -> Sistema -> Pamyat')"
Write-Host "    core\.venv (~300 MB):  udalit' papku, potom scripts\setup_python.cmd sozdast snova"
Write-Host ""
# A-28: (1) komandu kopiruyut v cmd, a Clear-RecycleBin - eto cmdlet PowerShell;
# (2) v Korzine mogut lezhat' GGUF - iz nee ikh dostayet restore_models.cmd,
# poetomu ochistka Korziny lishaet zapasnogo puti vosstanovleniya 19.7 GB.
Write-Host "Korzina - OSTOROZHZNO: iz nee restore_models.cmd dostayet GGUF."
Write-Host "  Ochishchayte tolko esli modeli tsely (scripts\doctor.cmd, razdel 3 - vse [OK]):"
Write-Host 'powershell -NoProfile -Command "Clear-RecycleBin -Force"'
Write-Host ""
Write-Host "NE UDALYAYTE: GGUF v %CITLALI_MODELS_DIR% (ili models\), tools\llama, soul\SOUL.md"
