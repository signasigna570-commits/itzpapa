"""Сравнение моделей для Citlali: какая реально держит NFR на вашем железе.

Решение оператора от 17.10.2026 — скачать 14B и 8B и выбрать по замеру,
а не по оценке VRAM. Этот скрипт:

  1. поднимает llama-server на указанном GGUF (контекст/флаги — как в проде);
  2. ждёт ``/health``;
  3. прогоняет прямой замер ток/с через ``/v1/chat/completions`` (без Core,
     чтобы не смешивать метрики) + фиксирует VRAM через ``nvidia-smi``;
  4. гасит сервер и печатает строку для итоговой таблицы.

Запуск: ``scripts/03_compare_models.cmd`` (обёртка передаёт аргументы сюда).
Вручную:  ``python scripts\\compare_models.py --model models\\x.gguf --ctx 8192 --runs 3``
"""

from __future__ import annotations

import argparse
import contextlib
import json
import statistics
import subprocess
import sys
import time
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parents[1]
LLAMA_DIR_DEFAULT = ROOT / "tools" / "llama"

PROMPTS = (
    "Привет. Представься в одном предложении.",
    "Объясни в двух фразах, что такое KV-кэш и зачем он нужен.",
    "Перечисли три шага, как проверить свободное место на диске в Windows.",
)

SERVER_FLAGS = (
    "-ngl",
    "99",
    "-fa",
    "1",
    "-np",
    "2",
    "--cache-reuse",
    "256",
    "--jinja",
    # ШТАТНОЕ отключение мышления в b11711 — "--reasoning off" (проставляет
    # enable_thinking=false в chat-шаблоне). "--reasoning-format none" только
    # прячет формат вывода, но шаблон всё равно просит модель думать (A-24).
    "--reasoning",
    "off",
    "--reasoning-budget",
    "0",
)


def log(msg: str) -> None:
    print(msg, flush=True)


def nvidia_smi() -> dict[str, float] | None:
    """VRAM и утилизация GPU; None, если nvidia-smi недоступен."""
    try:
        out = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=memory.used,memory.total,utilization.gpu",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=20,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if out.returncode != 0:
        return None
    try:
        used, total, util = (float(x) for x in out.stdout.strip().split(",")[:3])
    except ValueError:
        return None
    return {"vram_used_mb": used, "vram_total_mb": total, "gpu_util": util}


def wait_health(port: int, timeout_s: int) -> bool:
    deadline = time.time() + timeout_s
    while time.time() < deadline:
        try:
            if httpx.get(f"http://127.0.0.1:{port}/health", timeout=3.0).status_code == 200:
                return True
        except httpx.HTTPError:
            pass
        time.sleep(2.0)
    return False


def one_run(port: int, prompt: str, max_tokens: int, temperature: float) -> dict[str, float]:
    """Замер одного запроса: время, токены, ток/с (берём из usage llama-server)."""
    payload = {
        "model": "citlali-bench",
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": max_tokens,
        "temperature": temperature,
        "stream": False,
    }
    started = time.perf_counter()
    resp = httpx.post(f"http://127.0.0.1:{port}/v1/chat/completions", json=payload, timeout=600.0)
    elapsed = time.perf_counter() - started
    resp.raise_for_status()
    data = resp.json()
    usage = data.get("usage") or {}
    completion = int(usage.get("completion_tokens") or 0)
    prompt_tokens = int(usage.get("prompt_tokens") or 0)
    text = ""
    with contextlib.suppress(KeyError, IndexError, TypeError):
        text = data["choices"][0]["message"]["content"] or ""
    return {
        "elapsed_s": elapsed,
        "tps": completion / elapsed if completion and elapsed > 0 else 0.0,
        "completion_tokens": float(completion),
        "prompt_tokens": float(prompt_tokens),
        "answer_chars": float(len(text)),
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="A/B-замер моделей GGUF на целевом железе")
    ap.add_argument("--model", help="путь к конкретному .gguf (иначе перебор --models-dir)")
    ap.add_argument("--models-dir", default="models", help="каталог с GGUF для перебора")
    ap.add_argument("--filter", default="*.gguf", help="glob-фильтр внутри --models-dir")
    ap.add_argument(
        "--summary-dir", default=str(ROOT / ".compare"), help="куда складывать JSON-результаты"
    )
    ap.add_argument("--llama-dir", default=str(LLAMA_DIR_DEFAULT))
    ap.add_argument(
        "--port", type=int, default=8090, help="не 8080, чтобы не мешать рабочему серверу"
    )
    ap.add_argument("--ctx", type=int, default=8192)
    ap.add_argument("--runs", type=int, default=3)
    ap.add_argument("--max-tokens", type=int, default=128)
    ap.add_argument("--temperature", type=float, default=0.7)
    ap.add_argument("--startup-timeout", type=int, default=180)
    args = ap.parse_args()

    summary_dir = Path(args.summary_dir)
    summary_dir.mkdir(parents=True, exist_ok=True)

    if args.model:
        targets = [Path(args.model).expanduser()]
    else:
        models_dir = Path(args.models_dir).expanduser()
        if not models_dir.is_dir():
            log(f"[FAIL] нет каталога {models_dir}: сначала scripts/01_bootstrap.cmd")
            return 2
        targets = sorted(models_dir.glob(args.filter))
        if not targets:
            log(f"[FAIL] в {models_dir} нет файлов по маске {args.filter}")
            log("       Сначала scripts/01_bootstrap.cmd — он качает модели по bootstrap.json")
            return 2

    server = Path(args.llama_dir).expanduser() / "llama-server.exe"
    if not server.is_file():
        log(f"[FAIL] llama-server не найден: {server}")
        log("       Выполните одну команду и повторите:")
        log("           scripts\\01_bootstrap.cmd")
        log("       (zip-архивы уже в %TEMP%\\citlali-dl, распаковка займёт секунды)")
        return 2

    log(f"Найдено моделей: {len(targets)}")
    for t in targets:
        log(f"  - {t.name}")

    failures = 0
    for idx, model in enumerate(targets, 1):
        log("")
        log("#" * 60)
        log(f"## [{idx}/{len(targets)}] {model.name}")
        log("#" * 60)
        json_out = summary_dir / (model.stem + ".json")
        code = benchmark(
            model,
            llama_dir=Path(args.llama_dir).expanduser(),
            port=args.port + idx - 1,
            ctx=args.ctx,
            runs=args.runs,
            max_tokens=args.max_tokens,
            temperature=args.temperature,
            startup_timeout=args.startup_timeout,
            json_out=json_out,
        )
        if code != 0:
            failures += 1
        time.sleep(3)  # дать видеопамяти освободиться перед следующим запуском

    log("")
    log("#" * 60)
    log("## СВОДНАЯ ТАБЛИЦА")
    log("#" * 60)
    from compare_summary import load_rows, recommend, render  # локальный импорт: тот же каталог

    rows = load_rows(summary_dir)
    if rows:
        log(render(rows))
        log("")
        log(recommend(rows))
        log("")
        log("Переключение модели: model_file в config.toml (папка %APPDATA%/Citlali)")
        log("или scripts\run_llama.cmd models\<файл>.gguf <контекст>")
    else:
        log("[FAIL] не удалось собрать результаты замеров")
        return 2

    if failures:
        log("")
        log(f"[WARN] {failures} из {len(targets)} моделей не прошли замер — смотрите вывод выше")
    return 0


def benchmark(
    model: Path,
    *,
    llama_dir: Path,
    port: int,
    ctx: int,
    runs: int,
    max_tokens: int,
    temperature: float,
    startup_timeout: int,
    json_out: Path,
) -> int:
    """Один полный замер модели. Возвращает код возврата (0 = успешно)."""
    model = model.resolve()
    llama_dir = llama_dir.resolve()
    server = llama_dir / "llama-server.exe"

    if not model.is_file():
        log(f"[FAIL] модель не найдена: {model}")
        return 2
    if not server.is_file():
        log(f"[FAIL] llama-server не найден: {server}")
        log("       Сначала выполните scripts/01_bootstrap.cmd")
        return 2

    log(f"=== {model.name} (ctx={ctx}) ===")
    log(f"размер модели: {model.stat().st_size / 1e9:.2f} GB")

    cmd = [
        str(server),
        "-m",
        str(model),
        "--host",
        "127.0.0.1",
        "--port",
        str(port),
        "-c",
        str(ctx),
        *SERVER_FLAGS,
    ]
    log("запуск: " + " ".join(f'"{c}"' if " " in c else c for c in cmd))
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
    )

    result: dict[str, object] = {
        "model_file": model.name,
        "model_size_gb": round(model.stat().st_size / 1e9, 2),
        "ctx": ctx,
        "runs": runs,
    }

    try:
        if not wait_health(port, startup_timeout):
            tail = ""
            if proc.stdout is not None:
                proc.kill()
                tail = proc.stdout.read()[-3000:]
            log(f"[FAIL] /health не ответил за {startup_timeout} c")
            log("--- вывод llama-server (последние строки) ---")
            log(tail.strip()[-2000:] or "(пусто)")
            log("---------------------------------------------")
            log("Что делать: уменьшите контекст (--ctx 4096). Если и так не встаёт —")
            log("нужна Vulkan-сборка (bootstrap.json: assets_vulkan_fallback) или новый драйвер.")
            result.update(status="startup_failed")
            return 3

        log("[OK] модель загружена, снимаем VRAM")
        gpu = nvidia_smi()
        if gpu:
            result.update(gpu)
            log(
                f"     VRAM: {gpu['vram_used_mb']:.0f} / {gpu['vram_total_mb']:.0f} MB"
                f"  (утилизация {gpu['gpu_util']:.0f}%)"
            )
        else:
            log("     nvidia-smi недоступен — VRAM не измерен")

        tps_list: list[float] = []
        elapsed_list: list[float] = []
        for i in range(runs):
            prompt = PROMPTS[i % len(PROMPTS)]
            try:
                run = one_run(port, prompt, max_tokens, temperature)
            except Exception as exc:
                log(f"[FAIL] прогон {i + 1}: {type(exc).__name__}: {exc}")
                result.update(status="request_failed", error=str(exc))
                return 4
            tps_list.append(run["tps"])
            elapsed_list.append(run["elapsed_s"])
            log(
                f"  #{i + 1}  {run['tps']:>5.1f} tok/s   "
                f"{run['elapsed_s']:>5.2f} s   compl {int(run['completion_tokens']):>4} tok"
            )

        median_tps = statistics.median(tps_list)
        min_tps = min(tps_list)
        result.update(
            status="ok",
            tps_median=round(median_tps, 1),
            tps_min=round(min_tps, 1),
            elapsed_median_s=round(statistics.median(elapsed_list), 2),
            nfr_tps_pass=median_tps >= 25.0,
        )
        log("")
        log(
            f"ИТОГ {model.name}: ток/с медиана {median_tps:.1f} (мин {min_tps:.1f}), "
            f"NFR ≥ 25 tok/s: {'PASS' if median_tps >= 25.0 else 'FAIL'}"
        )
        if gpu:
            free = gpu["vram_total_mb"] - gpu["vram_used_mb"]
            log(
                f"     VRAM свободно после загрузки: {free:.0f} MB "
                f"({'запас есть' if free >= 1024 else 'ВПРИТЫК: возможен offload на CPU'})"
            )
            result["vram_free_mb"] = round(free, 0)
        return 0
    finally:
        if proc.poll() is None:
            log("останавливаю llama-server…")
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
        json_out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        log(f"результат записан: {json_out}")


if __name__ == "__main__":
    sys.exit(main())
