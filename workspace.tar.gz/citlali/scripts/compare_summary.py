"""Сводная таблица сравнения моделей (читает JSON из `.compare/`).

Запуск: ``python scripts\\compare_summary.py [--dir .compare]``
Отдельный файл, а не ``python -c`` внутри .cmd: в батче пришлось бы
экранировать ``>`` и кавычки в трёх уровнях, что ломается незаметно.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# Во сколько раз мелкая модель должна быть быстрее крупной, чтобы размер
# перестал быть аргументом. 1.5 — осознанный порог: на 1.2x разница почти
# не ощущается в диалоге, а на 2x (типичный случай Qwen3.5-9B против dense
# Qwen3-14B) agent-цикл из 5 шагов выигрывает секунды на каждом шаге.
SPEED_ESCAPE_RATIO = 1.5

HEADER = (
    f"{'модель':44s} {'GB':>5s} {'tok/s':>7s} {'мин':>6s} "
    f"{'VRAM MB':>8s} {'своб MB':>8s} {'NFR':>5s}  статус"
)


def load_rows(directory: Path) -> list[dict]:
    rows: list[dict] = []
    for path in sorted(directory.glob("*.json")):
        try:
            rows.append(json.loads(path.read_text(encoding="utf-8")))
        except (OSError, json.JSONDecodeError) as exc:
            print(f"[WARN] {path.name}: {exc}")
    rows.sort(key=lambda r: -(r.get("tps_median") or 0))
    return rows


def render(rows: list[dict]) -> str:
    lines = [HEADER, "-" * len(HEADER)]
    for r in rows:
        lines.append(
            f"{str(r.get('model_file', '?'))[:44]:44s} "
            f"{r.get('model_size_gb', '-')!s:>5s} "
            f"{r.get('tps_median', '-')!s:>7s} "
            f"{r.get('tps_min', '-')!s:>6s} "
            f"{(str(int(r['vram_used_mb'])) if r.get('vram_used_mb') else '-'):>8s} "
            f"{(str(int(r['vram_free_mb'])) if r.get('vram_free_mb') else '-'):>8s} "
            f"{('PASS' if r.get('nfr_tps_pass') else 'FAIL'):>5s}  "
            f"{r.get('status', '?')!s}"
        )
    return "\n".join(lines)


def recommend(rows: list[dict]) -> str:
    """Правило выбора модели (docs/spec.md A-1 ред.2 + A-16).

    Приоритет **не** «самая быстрая» и не «самая крупная», а компромисс:
    крупная модель даёт характер и стабильный tool-calling, но если мелкая
    быстрее более чем в ``SPEED_ESCAPE_RATIO`` раз — она объективно лучший
    выбор для agent-цикла (TTFT и ток/с напрямую влияют на NFR и на UX).
    Именно такой случай — Qwen3.5-9B (2026, hybrid Gated Delta Net + MoE)
    против dense Qwen3-14B (2025).
    """
    started = [r for r in rows if r.get("status") == "ok"]
    fast = [r for r in started if (r.get("tps_median") or 0) >= 25.0]
    roomy = [r for r in fast if (r.get("vram_free_mb") or 0) >= 1024]

    if not started:
        return (
            "Ни одна модель не стартовала. Действия: --ctx 4096, затем Vulkan-сборка "
            "(bootstrap.json: assets_vulkan_fallback), затем обновление драйвера NVIDIA."
        )
    if not fast:
        return (
            "Модели стартуют, но ни одна не даёт ≥ 25 tok/s. Действия: --ctx 4096, "
            "затем переход на модель мельче, затем проверка, не уехали ли слои на CPU "
            "('offloaded' в логе llama-server)."
        )

    pool = roomy or fast
    biggest = max(pool, key=lambda r: (r.get("model_size_gb") or 0, r.get("tps_median") or 0))
    fastest = max(pool, key=lambda r: r.get("tps_median") or 0)

    b_tps = float(biggest.get("tps_median") or 0)
    f_tps = float(fastest.get("tps_median") or 0)
    if fastest is not biggest and b_tps > 0 and f_tps / b_tps >= SPEED_ESCAPE_RATIO:
        best = fastest
        reason = (
            f"в {f_tps / b_tps:.1f} раза быстрее самой крупной модели "
            f"{biggest['model_file']} ({b_tps} tok/s); "
            f"для agent-цикла из 5 шагов скорость важнее размера"
        )
    else:
        best = biggest
        reason = f"крупнейшая из проходящих по скорости ({b_tps} tok/s)"

    if not roomy:
        reason += (
            "; запаса VRAM нет — браузер с видео может вытолкнуть слои на CPU, "
            "при просадке скорости берите модель мельче"
        )
    else:
        free = int(best.get("vram_free_mb") or 0)
        reason += f", VRAM свободно {free} MB"
    return f"Рекомендация: {best['model_file']} ({best['tps_median']} tok/s — {reason})."


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default=str(ROOT / ".compare"))
    args = ap.parse_args()

    directory = Path(args.dir)
    if not directory.is_dir():
        print(f"[FAIL] нет каталога {directory}: сначала scripts/03_compare_models.cmd")
        return 2
    rows = load_rows(directory)
    if not rows:
        print(f"[FAIL] в {directory} пусто")
        return 2

    print()
    print(render(rows))
    print()
    print(recommend(rows))
    print()
    print("Переключение модели: model_file в %APPDATA%\\Citlali\\config.toml")
    print("или запуск scripts\\run_llama.cmd models\\<файл>.gguf <контекст>")
    return 0


if __name__ == "__main__":
    sys.exit(main())
