@echo off
REM ============================================================
REM  Citlali: poisk pozhiratelya mesta na diske (obertka dlya
REM  diag_disk.ps1). Tolko ASCII: kirillitsa v .cmd lomayet
REM  kodovuyu stranitsu konsoli.
REM  Skript NICHEGO ne udalyaet - tolko smotrit i pechataet
REM  gol'ye komandy lecheniya (A-17, A-28).
REM
REM  Isp.:  scripts\diag_disk.cmd        - polnyy poisk, 3-10 minut
REM         scripts\diag_disk.cmd fast   - bystro, bez skana vsego C:
REM ============================================================
setlocal
cd /d "%~dp0.."

if /i "%~1"=="fast" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0diag_disk.ps1" -Fast
) else (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0diag_disk.ps1"
)
endlocal
