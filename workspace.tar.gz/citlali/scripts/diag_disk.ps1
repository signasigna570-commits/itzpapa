﻿<#
.SYNOPSIS
  Citlali: poisk pozhirateley mesta na diske. Diagnostika, NICHEGO ne udalyaet.

.DESCRIPTION
  Razdely otcheta:
    1. svobodnoe mesto po diskam;
    2. skrytye sistemnye fayly kornya C: (hiberfil.sys, pagefile.sys, swapfile.sys, MEMORY.DMP);
    3. giganty Windows (Windows.old, kesh Update, Temp, dumpy, WinSxS, Installer);
    4. papki profilya polzovatelya (Downloads, AppData - tam zhivut keshi i dublikaty);
    5. katalog proekta;
    6. modeli GGUF: rabochaya otmechena, lishnie - kandidaty (udalyat' tolko posle podtverzhdeniya);
    7. keshi i musor, kotorye udalyayutsya odnoy komandoy (vkluchaya hvosty pytest
       v %TEMP% - tam pytest derzhit zaglushki GGUF iz testov, desyatki GB);
    8. (polnyy rezhim) odnoprohodnyy skan vsego C: - razmery papok verkhneho urovnya i vse GGUF;
    SVODKA: krupneyshiye nakhodki i gol'ye komandy lecheniya (A-28).

  Skript ne lechit rukami: on smotrit i pechataet komandy, a udalyaet operator
  i tolko posle togo, kak otchet uletel ko mne (tot zhe printsip, chto u doctor.ps1, A-17).

.PARAMETER Fast
  Propustit' dolgii skan vsego diska C: (razdel 8). Ostal'nye razdely pechatayutsya.

.EXAMPLE
  scripts\diag_disk.cmd
  scripts\diag_disk.cmd fast
#>

[CmdletBinding()]
param([switch]$Fast)

$ErrorActionPreference = "Continue"

$repo = Split-Path -Parent $PSScriptRoot
$isWin = [bool]$env:OS  # "Windows_NT" na lyuboy Windows; na Linux pusto

# T0.36: edinitsy desyatichnye (AGENTS par. 6: GB = 1000^3). Literaly PowerShell
# Literaly PowerShell GB/MB/KB - eto 1024^3/1024^2/1024; iz-za nih otchet pokazal
# "160.7 GB" na
# disk, gde disk_preflight.py v tu zhe minutu naskital 172.5 GB (lovushka 23).
$OneGB = 1e9
$OneMB = 1e6
$OneKB = 1e3

function Fmt-Size {
  param([long]$Bytes)
  if ($Bytes -ge $OneGB) { return ([math]::Round($Bytes / $OneGB, 2).ToString() + " GB") }
  if ($Bytes -ge $OneMB) { return ([math]::Round($Bytes / $OneMB, 1).ToString() + " MB") }
  if ($Bytes -ge $OneKB) { return ([math]::Round($Bytes / $OneKB, 1).ToString() + " KB") }
  return ($Bytes.ToString() + " B")
}

function Get-DirSize {
  param([string]$Path)
  if (-not $Path) { return [long]-1 }
  if (-not (Test-Path -LiteralPath $Path)) { return [long]-1 }
  $sum = [long]0
  foreach ($f in Get-ChildItem -LiteralPath $Path -Recurse -File -Force -ErrorAction SilentlyContinue) {
    $sum += $f.Length
  }
  return $sum
}

function Get-FileSize {
  param([string]$Path)
  $item = Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
  if ($null -eq $item) { return [long]-1 }
  return [long]$item.Length
}

function Verdict-ForTopDir {
  param([string]$Name)
  $n = $Name.ToLowerInvariant()
  if ($n -eq "windows") { return "sistemnaya papka - NE udalyat' vruchnuyu; tolko cleanmgr" }
  if ($n -eq "windows.old") { return "staraya Windows posle obnovleniya - udalyat cherez cleanmgr" }
  if ($n.StartsWith("program files")) { return "programmy - udalyat cherez Parametry > Prilozheniya" }
  if ($n -eq "users") { return "profili polzovateley - podrobnosti v razdele 4" }
  if ($n -eq "programdata") { return "dannye program; Package Cache NE udalyat vruchnuyu" }
  if ($n -eq "perflogs") { return "otchety proizvoditelnosti; MOZHNO udalit" }
  if ($n.StartsWith('$')) { return "sluzhebnye papki Windows - NE udalyat" }
  return "proverit chto vnutri prezhde chem udalyat"
}

$findings = New-Object System.Collections.Generic.List[object]
$fixes = New-Object System.Collections.Generic.List[object]

function Add-Fix {
  param([string]$Why, [string]$Command, [string]$Note)
  $fixes.Add([PSCustomObject]@{ Why = $Why; Command = $Command; Note = $Note })
}

function Show-Item {
  param([string]$Label, [long]$Bytes, [string]$Verdict)
  if ($Bytes -lt 0) {
    Write-Host ("    [net]  " + $Label)
    return
  }
  Write-Host ("    [" + (Fmt-Size $Bytes).PadLeft(9) + "]  " + $Label)
  if ($Verdict) { Write-Host ("               ^^ " + $Verdict) }
  if ($Bytes -ge 50 * $OneMB) {
    $findings.Add([PSCustomObject]@{ Bytes = $Bytes; Label = $Label; Verdict = $Verdict })
  }
}

Write-Host "############################################################"
Write-Host "#  Citlali: diagnostika diska - skript NICHEGO ne udalyaet"
if ($Fast) {
  Write-Host "#  Rezhim: fast (bez polnogo skana C:)"
} else {
  Write-Host "#  Rezhim: polnyy (3-10 minut, okno ne zakryvat)"
}
Write-Host "############################################################"
Write-Host ""

# ---------------------------------------------------------------- 1. diski
Write-Host "== 1. Svobodnoe mesto po diskam =="
$cFree = [long]-1
foreach ($di in [System.IO.DriveInfo]::GetDrives()) {
  if (-not $di.IsReady) { continue }
  if ($di.DriveType -ne [System.IO.DriveType]::Fixed) { continue }
  $freeGb = [math]::Round($di.AvailableFreeSpace / $OneGB, 1)
  $sizeGb = [math]::Round($di.TotalSize / $OneGB, 1)
  Write-Host ("    " + $di.Name + "  svobodno " + $freeGb + " GB iz " + $sizeGb + " GB")
  if ($isWin -and $di.Name -eq "C:\") { $cFree = [long]$di.AvailableFreeSpace }
}
if ($cFree -ge 0 -and $cFree -lt (2 * $OneGB)) {
  Write-Host "    !! KRITICHNO MALO: git i pytest padayut s 'OSError 28 No space left on device'."
}
Write-Host ""

# ------------------------------------------------- 2. skrytye fayly kornya C:
Write-Host "== 2. Skrytye sistemnye fayly v korne C: =="
$hiber = Get-FileSize "C:\hiberfil.sys"
Show-Item "C:\hiberfil.sys" $hiber "fayl spyashchego rezhima; lechitsya powercfg /h off (okno administratora)"
Show-Item "C:\pagefile.sys" (Get-FileSize "C:\pagefile.sys") "fayl podkachki; NE udalyat vruchnuyu"
Show-Item "C:\swapfile.sys" (Get-FileSize "C:\swapfile.sys") "NE udalyat"
$memDump = Get-FileSize "C:\MEMORY.DMP"
Show-Item "C:\MEMORY.DMP" $memDump "damp padeniya Windows; MOZHNO udalit (okno administratora)"
if ($memDump -ge (100 * $OneMB)) {
  Add-Fix "MEMORY.DMP - damp padeniya Windows" 'del "C:\MEMORY.DMP"' "v okne cmd ot imeni administratora"
}
if ($hiber -ge (2 * $OneGB)) {
  Add-Fix "hiberfil.sys - fayl spyashchego rezhima" "powercfg /h off" "v okne cmd ot imeni administratora; spyashchii rezhim otklyuchitsya"
}
Write-Host ""

# --------------------------------------------------------- 3. giganty Windows
Write-Host "== 3. Giganty Windows =="
$winRows = @(
  , @("C:\Windows.old", "ostatok predydushchey Windows posle obnovleniya; udalyat tolko cherez cleanmgr")
  , @('C:\$WINDOWS.~BT', "vremennye fayly obnovleniya; udalyat tolko cherez cleanmgr")
  , @("C:\Windows\SoftwareDistribution\Download", "kesh Windows Update; MOZHNO udalit")
  , @("C:\Windows\Temp", "vremennye fayly; MOZHNO udalit")
  , @("C:\Windows\LiveKernelReports", "dumpy yadra i GPU; MOZHNO udalit")
  , @("C:\Windows\Minidump", "minidumpy; MOZHNO udalit")
  , @("C:\Windows\Installer", "MSI-kesh; NE udalyat vruchnuyu - slomaetsya obnovlenie program")
  , @("C:\Windows\WinSxS", "komponenty Windows; NE udalyat vruchnuyu, tolko cleanmgr")
  , @("C:\ProgramData\Package Cache", "kesh ustanovshchikov; NE udalyat vruchnuyu")
)
$oldWindowsFound = $false
foreach ($row in $winRows) {
  $sz = Get-DirSize $row[0]
  Show-Item $row[0] $sz $row[1]
  if ($sz -ge $OneGB -and ($row[0] -eq "C:\Windows.old" -or $row[0] -like '*WINDOWS.~BT*')) {
    $oldWindowsFound = $true
  }
}
if ($oldWindowsFound) {
  Add-Fix "Windows.old / WINDOWS.~BT - ostatki staroy Windows (desyatki GB)" "cleanmgr /d C:" "v okne knopka 'Ochistit sistemnye fayly', otmetit 'Predydushchie ustanovki Windows'"
}
Write-Host ""

# ------------------------------------------------------------ 4. profil
Write-Host "== 4. Papki profilya polzovatelya =="
$prof = $env:USERPROFILE
if (-not $prof) { $prof = $HOME }
Write-Host ("    profil: " + $prof)
foreach ($name in @("Downloads", "Desktop", "Documents", "Videos", "Pictures", "Music", "Saved Games")) {
  $p = Join-Path $prof $name
  $v = ""
  if ($name -eq "Downloads") { $v = "zdes chashche vsego lezhat GGUF-dublikaty i instalatory" }
  Show-Item $p (Get-DirSize $p) $v
}
$local = Join-Path $prof "AppData\Local"
foreach ($name in @("Temp", "pip\cache", "npm-cache", "CrashDumps", "D3DSCache", "Microsoft\Windows\INetCache", "HuggingFace")) {
  $p = Join-Path $local $name
  $verdictTemp = "kesh; MOZHNO udalit"
  if ($name -eq "Temp") {
    $verdictTemp = "kesh; MOZHNO udalit; smotrite razdel 7 - tam byvayut desyatki GB hvostov pytest"
  }
  Show-Item $p (Get-DirSize $p) $verdictTemp
}
if (-not $Fast) {
  Write-Host "    -- polnyy razbor profilya (vse papki verkhneho urovnya) --"
  $profRows = New-Object System.Collections.Generic.List[object]
  foreach ($d in Get-ChildItem -LiteralPath $prof -Directory -Force -ErrorAction SilentlyContinue) {
    if ($d.Attributes -band [System.IO.FileAttributes]::ReparsePoint) { continue }
    $sz = Get-DirSize $d.FullName
    $profRows.Add([PSCustomObject]@{ Bytes = $sz; Label = $d.FullName })
    if ($sz -ge 500 * $OneMB) {
      $findings.Add([PSCustomObject]@{ Bytes = $sz; Label = $d.FullName; Verdict = "papka profilya - podrobnosti v razdele 4" })
    }
  }
  foreach ($r in ($profRows | Sort-Object Bytes -Descending)) {
    Write-Host ("    [" + (Fmt-Size $r.Bytes).PadLeft(9) + "]  " + $r.Label)
  }
}
Write-Host ""

# ------------------------------------------------------------ 5. proekt
Write-Host "== 5. Katalog proekta =="
Write-Host ("    repo: " + $repo)
foreach ($d in Get-ChildItem -LiteralPath $repo -Directory -Force -ErrorAction SilentlyContinue) {
  $v = ""
  $n = $d.Name.ToLowerInvariant()
  if ($n -eq ".git") { $v = "istoriya versiy - NE udalyat" }
  if ($n -eq "models") { $v = "GGUF vnutri repo - dubl (modeli zhivut vne repo, A-26)" }
  if ($n -eq "tools") { $v = "binarniki llama.cpp - NE udalyat (10 minut skachivaniya)" }
  if ($n -eq "node_modules") { $v = "MOZHNO udalit; sozdastsya snova (npm install)" }
  Show-Item $d.FullName (Get-DirSize $d.FullName) $v
}
$venv = Join-Path $repo "core\.venv"
Show-Item $venv (Get-DirSize $venv) "krayniy sluchay: MOZHNO udalit, sozdastsya snova (scripts\setup_python.cmd)"
Write-Host ""

# ------------------------------------------------------------ 6. modeli
Write-Host "== 6. Modeli GGUF =="
$mdir = $env:CITLALI_MODELS_DIR
if (-not $mdir) { $mdir = "C:\citlali-models" }
Write-Host ("    katalog modeley: " + $mdir)
if (-not (Test-Path -LiteralPath $mdir)) { Write-Host ("    [net]  " + $mdir) }
$working = ""
if ($isWin) {
  try {
    $rm = & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot "resolve_model.ps1") 2>$null
    if ($LASTEXITCODE -eq 0 -and $rm) { $working = ($rm | Select-Object -First 1).ToString().Trim() }
  } catch { $working = "" }
}
if ($working) { Write-Host ("    rabochaya model (reshaet resolve_model.ps1): " + $working) }
if (Test-Path -LiteralPath $mdir) {
  foreach ($f in Get-ChildItem -LiteralPath $mdir -File -Force -ErrorAction SilentlyContinue | Sort-Object Length -Descending) {
    $v = ""
    if ($working -and [string]::Equals($f.FullName, $working, [System.StringComparison]::OrdinalIgnoreCase)) {
      $v = "RABOCHAYA model - NE TROGAT'"
    } elseif ($f.Extension -ieq ".gguf") {
      $v = "yadro s nei ne rabotaet; udalyat' tolko posle moego 'mozhno'"
    }
    Show-Item $f.FullName ([long]$f.Length) $v
  }
}
$repoModels = Join-Path $repo "models"
if (Test-Path -LiteralPath $repoModels) {
  foreach ($f in Get-ChildItem -LiteralPath $repoModels -Filter *.gguf -File -Force -ErrorAction SilentlyContinue) {
    Show-Item $f.FullName ([long]$f.Length) "GGUF vnutri repo - dubl' (modeli zhivut vne repo, A-26)"
    Add-Fix "GGUF-dubl' vnutri repo" ('del "' + $f.FullName + '"') "posle udaleniya: scripts\doctor.cmd dlya kontrolya"
  }
}
$dlDir = Join-Path $prof "Downloads"
if (Test-Path -LiteralPath $dlDir) {
  foreach ($f in Get-ChildItem -LiteralPath $dlDir -Filter *.gguf -File -Force -ErrorAction SilentlyContinue) {
    Show-Item $f.FullName ([long]$f.Length) "skachannyi GGUF v Downloads - sverit' s katalogom modeley"
    Add-Fix "GGUF v Downloads (vozmozhno, staryi dubl')" ('del "' + $f.FullName + '"') "snachala sverit' razmer s katalogom modeley; fail popadet v Korzinu"
  }
}
Write-Host ""

# ------------------------------------------------------------ 7. keshi
Write-Host "== 7. Keshi i musor: udalyayutsya odnoy komandoy =="
# Hvosty progono pytest: %TEMP%\pytest-of-<user>\pytest-N. Vnutri lezhat
# zaglushki GGUF iz testov poiska modeley - 20.10.2026 tam bylo 63.5 GB, i eto
# vyglyadelo kak "neizvestno kuda delis' 70 GB" (lovushka 25).
$pytestDirs = @()
if ($env:TEMP) {
  $pytestDirs = @(Get-ChildItem -LiteralPath $env:TEMP -Directory -Force -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -like "pytest-of-*" })
  $tmpDl = Join-Path $env:TEMP "citlali-dl"
  Show-Item $tmpDl (Get-DirSize $tmpDl) "zip-arhivy llama.cpp; MOZHNO udalit"
}
if ($pytestDirs.Count -gt 0) {
  $pytestTotal = [long]0
  foreach ($pd in $pytestDirs) { $pytestTotal += (Get-DirSize $pd.FullName) }
  $pytestLabel = Join-Path $env:TEMP "pytest-of-*"
  Write-Host ("    [" + (Fmt-Size $pytestTotal).PadLeft(9) + "]  " + $pytestLabel + " (" + $pytestDirs.Count + " papok)")
  Write-Host "               ^^ ostatki testovyh progono pytest: zaglushki GGUF iz testov poiska modeley; MOZHNO udalit (scripts\cleanup.cmd)"
  if ($pytestTotal -ge 50 * $OneMB) {
    $findings.Add([PSCustomObject]@{ Bytes = $pytestTotal; Label = ($pytestLabel + "  <- hvosty pytest, udalyaet scripts\cleanup.cmd"); Verdict = "ostatki testovyh progono; MOZHNO udalit" })
  }
  Add-Fix ("hvosty progono pytest v " + $env:TEMP + " (" + (Fmt-Size $pytestTotal) + ")") "scripts\cleanup.cmd" "udalyaet papki pytest-of-* tselikom; zaglushki sozdadutsya snova pri sleduyushchem progone"
  $pytestFixDone = $true
} else {
  $pytestFixDone = $false
}
if ($env:LOCALAPPDATA) {
  $pipCache = Join-Path $env:LOCALAPPDATA "pip\cache"
  Show-Item $pipCache (Get-DirSize $pipCache) "kesh wheel pip; MOZHNO udalit"
  $npmCache = Join-Path $env:LOCALAPPDATA "npm-cache"
  Show-Item $npmCache (Get-DirSize $npmCache) "kesh npm; MOZHNO udalit"
}
if ($isWin) {
  $rb = 'C:\$Recycle.Bin'
  Show-Item $rb (Get-DirSize $rb) "Korzina; VNIMANIE: iz nee restore_models.cmd dostayet GGUF - ne ochishchat srazu"
}
Write-Host "    Keshi iz etogo razdela udalyaet komanda:"
Write-Host "scripts\cleanup.cmd"
Add-Fix "keshi i musor iz razdela 7 (pip, temp, __pycache__)" "scripts\cleanup.cmd" ""
Write-Host ""

# ------------------------------------------- 8. polnyy skan C: (ne v fast)
if (-not $Fast) {
  if ($isWin) {
    Write-Host "== 8. Polnyy skan C: (po papke za raz, 3-10 minut) =="
    $topRows = New-Object System.Collections.Generic.List[object]
    $ggufAll = New-Object System.Collections.Generic.List[object]
    foreach ($f in Get-ChildItem -LiteralPath 'C:\' -File -Force -ErrorAction SilentlyContinue) {
      if ($f.Extension -ieq ".gguf") {
        $ggufAll.Add([PSCustomObject]@{ Bytes = [long]$f.Length; Path = $f.FullName })
      }
    }
    foreach ($d in Get-ChildItem -LiteralPath 'C:\' -Directory -Force -ErrorAction SilentlyContinue) {
      if ($d.Attributes -band [System.IO.FileAttributes]::ReparsePoint) {
        Write-Host ("    propusk (ssylka): " + $d.FullName)
        continue
      }
      Write-Host ("    scan: " + $d.FullName)
      $sum = [long]0
      foreach ($f in Get-ChildItem -LiteralPath $d.FullName -Recurse -File -Force -ErrorAction SilentlyContinue) {
        $sum += $f.Length
        if ($f.Extension -ieq ".gguf") {
          $ggufAll.Add([PSCustomObject]@{ Bytes = [long]$f.Length; Path = $f.FullName })
        }
      }
      $topRows.Add([PSCustomObject]@{ Bytes = $sum; Path = $d.FullName })
      if ($sum -ge 500 * $OneMB) {
        $findings.Add([PSCustomObject]@{ Bytes = $sum; Label = $d.FullName; Verdict = (Verdict-ForTopDir $d.Name) })
      }
    }
    Write-Host "    -- papki verkhneho urovnya C: po ubyvaniyu --"
    foreach ($r in ($topRows | Sort-Object Bytes -Descending)) {
      Write-Host ("    [" + (Fmt-Size $r.Bytes).PadLeft(9) + "]  " + $r.Path)
    }
    Write-Host "    -- vse GGUF na C: --"
    if ($ggufAll.Count -eq 0) { Write-Host "    [net] GGUF na C: ne nayden" }
    $pytestSkipped = 0
    foreach ($g in ($ggufAll | Sort-Object Bytes -Descending)) {
      $inside = [bool]$mdir -and $g.Path.StartsWith($mdir, [System.StringComparison]::OrdinalIgnoreCase)
      $mark = ""
      if (-not $inside) { $mark = "  <- VNE kataloga modeley" }
      $inPytest = $false
      foreach ($pd in $pytestDirs) {
        if ($g.Path.StartsWith($pd.FullName, [System.StringComparison]::OrdinalIgnoreCase)) { $inPytest = $true; break }
      }
      if ($inPytest) {
        # Otdelnyy del na kazhdyy fayl ne nuzhen: papku tselikom ubiraet
        # scripts\cleanup.cmd (A-28 - odna komanda vmesto trinadtsati).
        $mark = $mark + "  <- zaglushka pytest (ubiraet scripts\cleanup.cmd)"
        $pytestSkipped = $pytestSkipped + 1
      }
      Write-Host ("    [" + (Fmt-Size $g.Bytes).PadLeft(9) + "]  " + $g.Path + $mark)
      if (-not $inside -and -not $inPytest -and $g.Bytes -ge 100 * $OneMB) {
        Add-Fix "GGUF vne kataloga modeley" ('del "' + $g.Path + '"') "sverit s katalogom modeley; fail popadet v Korzinu (vozvrat: restore_models.cmd)"
      }
    }
    if ($pytestSkipped -gt 0) {
      Write-Host ("    (zaglushek pytest: " + $pytestSkipped + " - otdelnye komandy del ne pechatayutsya, ikh ubiraet scripts\cleanup.cmd)")
    }
    Write-Host ""
  } else {
    Write-Host "== 8. Polnyy skan C: propushchen (ne Windows) =="
    Write-Host ""
  }
}

# ------------------------------------------------------------ SVODKA
Write-Host "== SVODKA: krupneyshiye nakhodki (porog 50 MB) =="
if ($findings.Count -eq 0) {
  Write-Host "    [net] nichego krupnee 50 MB ne naydeno"
} else {
  $seen = @{}
  foreach ($x in ($findings | Sort-Object Bytes -Descending)) {
    if ($seen.ContainsKey($x.Label)) { continue }
    $seen[$x.Label] = $true
    Write-Host ("    [" + (Fmt-Size $x.Bytes).PadLeft(9) + "]  " + $x.Label)
    if ($x.Verdict) { Write-Host ("               ^^ " + $x.Verdict) }
  }
}
Write-Host ""
Write-Host "== Chto delat: komandy GOLYMI strokami, kopirovat tselikom (A-28) =="
$seenFix = @{}
$i = 0
foreach ($fx in $fixes) {
  if ($seenFix.ContainsKey($fx.Command)) { continue }
  $seenFix[$fx.Command] = $true
  $i = $i + 1
  Write-Host ("  " + $i + ". " + $fx.Why)
  if ($fx.Note) { Write-Host ("     (" + $fx.Note + ")") }
  Write-Host $fx.Command
}
Write-Host ""
Write-Host "== NE TROGAT' =="
if ($working) {
  Write-Host ("    " + $working + "  <- rabochaya model")
} else {
  Write-Host ("    " + $mdir + "  <- katalog modeley")
}
Write-Host "    tools\llama  <- binarniki llama.cpp"
Write-Host "    soul\SOUL.md  <- harakter assistanta"
Write-Host "    core\.venv  <- okruzhenie Python"
Write-Host ""
Write-Host "Prishlite mne ves vyvod tselikom - ya skazhu, chto iz etogo mozhno udalit."
exit 0
