"""Предполётная проверка свободного места (поправка A-32).

19.10.2026 у оператора закончилось место на C:, и ``run_tests.cmd`` выдал
прогресс-бар из ``F``/``E`` с финалом ``OSError: [Errno 28] No space left on
device``. Код был здоров: падение - следствие полного диска. Но отчёт выглядел
как катастрофа, а настоящая причина пряталась в последней строке.

Правило A-17 («никакого молчаливого и непонятного отказа») означает здесь:
прогон обязан начаться с проверки места и оборваться одной понятной строкой
с голыми командами лечения (A-28), а не сотней красных тестов.

Запуск (из cmd, обычно это делает ``scripts\\run_tests.cmd``)::

    core\\.venv\\Scripts\\python.exe scripts\\disk_preflight.py
    scripts\\disk_preflight.py --json          # машиночитаемый ответ
    scripts\\disk_preflight.py --min-free-gb 8 # свой порог

Зависимостей нет вообще - только stdlib: скрипт обязан работать даже тогда,
когда окружение полусобрано, а ``httpx`` ещё не установлен.
"""

from __future__ import annotations

import argparse
import json
import shutil
import sys
import tempfile
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path

# AGENTS §6: единицы пишем явно. GB = 1000^3 (так их показывает HF API и так
# их считает оператор), GiB = 1024^3 (так считает PowerShell: 1GB = 1 GiB).
GB = 1000**3
GIB = 1024**3

# Порог для прогона тестов (A-32): pytest пишет .pytest_cache, tmp_path-фикстуры
# и отчёты; на полном диске это OSError 28 на каждом тесте.
MIN_FREE_GB = 2.0

# Проектный порог (A-3): модели, llama.cpp, venv и кэши Update. Ниже - работать
# можно, но место кончится снова; поэтому предупреждение, а не провал.
WARN_FREE_GB = 25.0

EXIT_OK = 0
EXIT_NO_SPACE = 3

REPO = Path(__file__).resolve().parents[1]

# Команды лечения печатаются голыми строками cmd (A-28): их копируют дословно.
FIXES = (
    r"scripts\diag_disk.cmd",
    r"scripts\cleanup.cmd",
)


@dataclass(frozen=True)
class Target:
    """Одно устройство: каталог-представитель, st_dev и свободные GB."""

    path: str
    device: int
    free_gb: float

    def as_dict(self) -> dict[str, object]:
        return {"path": self.path, "device": self.device, "free_gb": self.free_gb}


@dataclass(frozen=True)
class DiskReport:
    ok: bool
    exit_code: int
    free_gb: float
    targets: tuple[Target, ...]
    lines: tuple[str, ...]
    fixes: tuple[str, ...]


def probe_paths() -> list[Path]:
    """Что измеряем: каталог проекта и %TEMP% (туда pytest пишет фикстуры)."""
    paths = [REPO]
    tmp = Path(tempfile.gettempdir())
    if tmp not in paths:
        paths.append(tmp)
    return paths


def free_gb(path: str | Path) -> float:
    """Свободное место устройства в десятичных GB (1000^3)."""
    return shutil.disk_usage(str(path)).free / GB


def label_of(path: Path) -> str:
    """Короткая подпись устройства: буква диска на Windows, корень иначе."""
    drive = path.drive
    return drive.rstrip("\\/") if drive else path.anchor or str(path)


def collect_targets(paths: Sequence[str | Path] | None = None) -> tuple[Target, ...]:
    """По одному измерению на устройство: два каталога на C: - это одна строка."""
    chosen = [Path(p) for p in (paths if paths is not None else probe_paths())]
    seen: dict[int, Target] = {}
    for path in chosen:
        try:
            device = path.stat().st_dev
            free = free_gb(path)
        except OSError:
            # Каталога нет (перенесли проект, %TEMP% указан чужой) - измеряем
            # корень текущего диска, иначе проверка молча пропустит устройство.
            try:
                device = Path.cwd().stat().st_dev
                free = free_gb(Path.cwd())
            except OSError:
                continue
            path = Path.cwd()
        if device in seen:
            # На том же устройстве берём худшее число - оно и есть запас места.
            if free < seen[device].free_gb:
                seen[device] = Target(str(path), device, free)
            continue
        seen[device] = Target(str(path), device, free)
    return tuple(sorted(seen.values(), key=lambda t: t.free_gb))


def build_report(
    min_free_gb: float = MIN_FREE_GB,
    warn_free_gb: float = WARN_FREE_GB,
    paths: Sequence[str | Path] | None = None,
) -> DiskReport:
    """Вердикт по худшему из устройств: [OK], [WARN] или [FAIL] с лечением."""
    targets = collect_targets(paths)
    lines: list[str] = []

    if not targets:
        return DiskReport(
            ok=False,
            exit_code=EXIT_NO_SPACE,
            free_gb=0.0,
            targets=(),
            lines=(
                "[FAIL] Не удалось измерить свободное место ни на одном устройстве.",
                "Проверьте, что каталог проекта и %TEMP% существуют.",
            ),
            fixes=FIXES,
        )

    worst = targets[0]
    free = worst.free_gb
    label = label_of(Path(worst.path))
    shown = f"{free:.1f}"

    for target in targets:
        lines.append(
            f"    {label_of(Path(target.path)) or target.path} - свободно {target.free_gb:.1f} GB"
        )

    if free < min_free_gb:
        lines.insert(
            0,
            f"[FAIL] Свободно {shown} GB ({label}), нужно {min_free_gb:.1f} GB.",
        )
        lines.append("")
        lines.append("Тесты на таком диске падают пачками с OSError 28")
        lines.append("(No space left on device) - это диск, а не код.")
        lines.append("Команды ниже копируйте по одной в окно cmd:")
        return DiskReport(
            ok=False,
            exit_code=EXIT_NO_SPACE,
            free_gb=free,
            targets=targets,
            lines=tuple(lines),
            fixes=FIXES,
        )

    if free < warn_free_gb:
        lines.insert(
            0,
            f"[WARN] Свободно {shown} GB ({label}) - меньше порога проекта "
            f"{warn_free_gb:.1f} GB (A-3).",
        )
        lines.append("Тесты пройдут, но место снова кончится: уберите мусор заранее.")
        return DiskReport(
            ok=True,
            exit_code=EXIT_OK,
            free_gb=free,
            targets=targets,
            lines=tuple(lines),
            fixes=FIXES,
        )

    lines.insert(
        0,
        f"[OK] Свободно {shown} GB ({label}). Порог тестов {min_free_gb:.1f} GB, "
        f"порог проекта {warn_free_gb:.1f} GB (A-3).",
    )
    return DiskReport(
        ok=True,
        exit_code=EXIT_OK,
        free_gb=free,
        targets=targets,
        lines=tuple(lines),
        fixes=(),
    )


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Проверка свободного места перед прогоном тестов (A-32)"
    )
    parser.add_argument("--min-free-gb", type=float, default=MIN_FREE_GB)
    parser.add_argument("--warn-free-gb", type=float, default=WARN_FREE_GB)
    parser.add_argument(
        "--path",
        action="append",
        default=None,
        help="измерить указанный каталог (можно несколько раз)",
    )
    parser.add_argument("--json", action="store_true", help="машиночитаемый ответ")
    args = parser.parse_args(argv if argv is not None else sys.argv[1:])

    report = build_report(
        min_free_gb=args.min_free_gb, warn_free_gb=args.warn_free_gb, paths=args.path
    )

    if args.json:
        print(
            json.dumps(
                {
                    "ok": report.ok,
                    "exit_code": report.exit_code,
                    "free_gb": round(report.free_gb, 3),
                    "min_free_gb": args.min_free_gb,
                    "warn_free_gb": args.warn_free_gb,
                    "targets": [t.as_dict() for t in report.targets],
                    "fixes": list(report.fixes),
                },
                ensure_ascii=False,
            )
        )
        return report.exit_code

    for line in report.lines:
        print(line)
    # A-28: команда лечения - всегда отдельная строка без префиксов и отступа.
    for fix in report.fixes:
        print(fix)
    return report.exit_code


if __name__ == "__main__":
    raise SystemExit(main())
