@echo off
REM ============================================================
REM  Citlali: samodiagnostika okruzheniya (obertka dlya doctor.ps1)
REM  Tolko ASCII: kirillitsa v .cmd lomayet kodovuyu stranitsu konsoli.
REM  Skript NICHEGO ne kachaet i ne udalyaet - tolko smotrit i
REM  pechataet tochnye komandy lecheniya (A-17).
REM ============================================================
setlocal EnableExtensions
cd /d "%~dp0.."
REM A-31: PowerShell 5.1 pechataet kirillitsu v kodstranitse okna (OEM cp866),
REM a ne v UTF-8: v fayle posle '>' i v testakh russkiy tekst prevrashchayetsya
REM v truhu. Zdes my sami vklyuchayem UTF-8, a posle vyborki RC vozvrashchayem
REM oknu byvshuyu kodstranitsu - povedeniye okna ne menyaetsya.
set "OLDCP="
for /f "tokens=2 delims=:" %%a in ('chcp') do set "OLDCP=%%a"
set "OLDCP=%OLDCP: =%"
chcp 65001 > nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0doctor.ps1" %*
set RC=%errorlevel%
if defined OLDCP chcp %OLDCP% > nul
echo.
echo Kod vozvrata: %RC%
if not "%RC%"=="0" (
  echo.
  echo Chto delat':
  echo   1. Skopiruyte ves' vyvod vyshe i prishlite mne - ya razberu po razdelam.
  echo   2. Komandy lecheniya pechatayutsya otdel'noy GOLOY strokoy -
  echo      kopiruyte ikh TSELIKOM, vmeste so slovom komandy ^(del, setx, scripts\...^).
  echo      Esli skopirovat' tolko put' k faylu, cmd primet ego za komandu i
  echo      nichego ne sdelaet ^(A-28^).
  echo   3. Povtorite: scripts\doctor.cmd   ^(on idempotenten, mozhno zvat' chasto^)
  echo   4. Esli propali binarniki ili modeli - ne udalyayte papku proekta:
  echo      scripts\01_bootstrap.cmd -SkipModel   ^(binarniki, 1 minuta iz kesha^)
  echo      scripts\01_bootstrap.cmd -Only qwen3.5-9b   ^(tolko rabochaya model'^)
)
endlocal & exit /b %RC%
