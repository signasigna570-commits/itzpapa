﻿<#
.SYNOPSIS
  Citlali: самодиагностика окружения перед запуском (A-17, A-27).

.DESCRIPTION
  Проверяет всё, без чего не запустятся scripts\run_llama.cmd и
  scripts\run_core.cmd, и для каждой проблемы печатает ТОЧНУЮ команду лечения.

  Скрипт ничего не скачивает, не удаляет и не правит: он только смотрит.
  Команды удаления он печатает как текст — решение всегда за оператором
  (в v1 у ассистента инструмента удаления нет, A-4, и у скриптов тоже).

  Разделы:
    1. переменная CITLALI_MODELS_DIR и свободное место
    2. llama.cpp: tools\llama\llama-server.exe + CUDA-библиотеки
    3. модели GGUF: сверка побайтовая с scripts\bootstrap.json
    4. config.toml: BOM, абсолютные пути, существование файлов
    5. soul\SOUL.md и его лимит знаков
    6. core\.venv и импорты зависимостей
    7. порты 8080 / 8787: слушает ли кто-нибудь сейчас
    8. мусор, который ест место (недокачанные GGUF, кэш загрузки)

  Код возврата: 0 — запускать можно; 1 — есть критичные проблемы;
  2 — скрипт не смог сам себя проверить (нет bootstrap.json и т.п.).

.EXAMPLE
  scripts\doctor.cmd
  powershell -NoProfile -ExecutionPolicy Bypass -File scripts\doctor.ps1
#>

$ErrorActionPreference = "Continue"

# Ловушка 21 (A-31): Windows PowerShell 5.1 пишет текст в консоль в OEM-кодировке
# (у оператора cp866), а не в UTF-8, - даже когда окно уже переключено в
# `chcp 65001`: .NET кэширует кодировку консоли при старте процесса. Поэтому
# 19.10.2026 четыре теста читали вывод doctor как UTF-8 и получали труху вместо
# кириллицы, а перенаправление `> file.txt` портило отчёт оператору.
# Здесь мы фиксируем UTF-8 ТОЛЬКО когда кодстраница консоли уже 65001 - тогда
# вывод совпадает и на экране, и в файле. При иной кодстранице консоль остаётся
# как есть, а весь текст doctor обязан обходиться знаками своей кодстраницы:
# гарант test_ps1_string_literals_survive_oem_codepage (эм-тире там нет).
if ($PSVersionTable.PSVersion.Major -lt 6) {
  try {
    $script:cp = [Console]::GetConsoleOutputCP()
    if ($script:cp -eq 65001) {
      [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
    }
  } catch {
    $script:cp = 0   # консоли нет (перехват вывода) - оставляем как есть
  }
} else {
  $script:cp = 65001   # PowerShell 7 всегда пишет UTF-8
}

$repo = Split-Path -Parent $PSScriptRoot
$bootPath = Join-Path $PSScriptRoot "bootstrap.json"
if (-not (Test-Path -LiteralPath $bootPath)) {
  Write-Host "[FAIL] нет scripts\bootstrap.json - не с чем сверять модели." -ForegroundColor Red
  exit 2
}
$boot = Get-Content -LiteralPath $bootPath -Raw -Encoding UTF8 | ConvertFrom-Json

$script:criticals = New-Object System.Collections.Generic.List[string]
$script:criticalFixes = New-Object System.Collections.Generic.List[string]
$script:warnings = New-Object System.Collections.Generic.List[string]
$script:warnFixes = New-Object System.Collections.Generic.List[string]
$script:critical = 0
$script:warnCount = 0

function Write-Section([string]$Title) {
  Write-Host ""
  Write-Host "=== $Title ===" -ForegroundColor Cyan
}

function Write-Ok([string]$Msg) {
  Write-Host "    [OK]   $Msg" -ForegroundColor Green
}

function Write-Info([string]$Msg) {
  Write-Host "    [..]   $Msg"
}

function Write-Bad([string]$Msg, [string]$Fix, [bool]$IsCritical = $true) {
  # A-28: команду лечения печатаем голой строкой, без приклеенного префикса.
  # 19.10 оператор четырежды вставил в cmd один путь вместо `del "путь"` —
  # файл так и не удалился, а он решил, что сломал стенд. Всё, что оператор
  # копирует, обязано копироваться дословно и целиком.
  if ($IsCritical) {
    Write-Host "    [FAIL] $Msg" -ForegroundColor Red
    $script:critical = $script:critical + 1
    $script:criticals.Add($Msg)
    $script:criticalFixes.Add($Fix)
  } else {
    Write-Host "    [WARN] $Msg" -ForegroundColor Yellow
    $script:warnCount = $script:warnCount + 1
    $script:warnings.Add($Msg)
    $script:warnFixes.Add($Fix)
  }
  if ($Fix) {
    Write-Host "           лечить - скопируйте строку ниже целиком:" -ForegroundColor Yellow
    Write-Host $Fix -ForegroundColor Yellow
  }
}

function Get-EnvVar([string]$Name) {
  # setx пишет переменную в реестр: в уже открытом окне её может не быть,
  # поэтому смотрим процесс, потом уровни User и Machine.
  $v = (Get-Item -Path "Env:$Name" -ErrorAction SilentlyContinue)
  if ($v -and $v.Value) { return $v.Value }
  $v = [Environment]::GetEnvironmentVariable($Name, "User")
  if ($v) { return $v }
  $v = [Environment]::GetEnvironmentVariable($Name, "Machine")
  if ($v) { return $v }
  return ""
}

# T0.36: единицы десятичные (AGENTS пар. 6: GB = 1000^3). Литерал GB в
# PowerShell равен 1024^3, поэтому отчёт показывал число на 7% меньше
# фактического и расходился с disk_preflight.py на том же диске (ловушка 23).
$OneGB = 1e9
$OneMB = 1e6
$OneKB = 1e3

function Format-Gb([long]$Bytes) {
  if ($Bytes -lt $OneGB) { return ("{0:N1} MB" -f ($Bytes / $OneMB)) }
  return ("{0:N2} GB" -f ($Bytes / $OneGB))
}

# ------------------------------------------------- 1. каталог моделей и диск
Write-Section "1. Переменные окружения и диск"
$envModels = Get-EnvVar "CITLALI_MODELS_DIR"
if ($envModels) {
  Write-Ok "CITLALI_MODELS_DIR = $envModels"
  if (-not (Test-Path -LiteralPath $envModels)) {
    Write-Bad "каталога $envModels нет на диске - модели упрутся в models\ внутри проекта" "mkdir $envModels" $false
  }
} else {
  Write-Bad "CITLALI_MODELS_DIR не задана - модели окажутся внутри проекта и погибнут вместе с папкой (A-26). После команды откройте НОВОЕ окно cmd" "setx CITLALI_MODELS_DIR C:\citlali-models" $false
}

# Кодстраницу печатаем не для красоты: по ней видно, почему русский текст может
# выглядеть кашей в перенаправленном выводе или в тестах (ловушка 21, A-31).
$cpNow = 0
try { $cpNow = [Console]::GetConsoleOutputCP() } catch { $cpNow = 0 }
$encNow = "?"
try { $encNow = [Console]::OutputEncoding.WebName } catch { $encNow = "?" }
if ($cpNow -eq 65001) {
  Write-Ok ("кодстраница консоли 65001, вывод ${encNow} - русский текст переживёт перенаправление в файл")
} else {
  Write-Info ("кодстраница консоли ${cpNow}, вывод ${encNow} - после chcp 65001 отчёт станет UTF-8 (A-31)")
}

$drive = (Split-Path -Qualifier $repo)
$d = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$drive'" -ErrorAction SilentlyContinue
if ($d) {
  $freeGb = [math]::Round($d.FreeSpace / $OneGB, 1)
  if ($freeGb -lt 25) {
    Write-Bad "свободно $freeGb GB на $drive - нужно минимум 25 (A-3); что именно ест место, покажет раздел 8 ниже" "scripts\cleanup.cmd" $false
  } else {
    Write-Ok "свободно $freeGb GB на $drive"
  }
}

# ------------------------------------------------------------- 2. llama.cpp
Write-Section "2. llama.cpp (бинарники)"
$llamaRel = ($boot.llama.dir -replace '/', '\')
$llamaDir = Join-Path $repo $llamaRel
$llamaExe = Join-Path $llamaDir "llama-server.exe"
if (Test-Path -LiteralPath $llamaExe) {
  # Размер печатаем так, чтобы "0 MB" было невозможно: у оператора doctor
  # напечатал "(0 MB)" для живого exe — кругление до 0.1 MB превращало малое
  # значение в ноль и выглядело как поломка. Меньше мегабайта — пишем байты,
  # а подозрительно лёгкий exe объявляем критичной проблемой (битая распаковка).
  $exeLen = [long](Get-Item -LiteralPath $llamaExe).Length
  if ($exeLen -lt $OneMB) { $sizeTxt = "$exeLen байт" } else { $sizeTxt = ("{0:N1} MB" -f ($exeLen / $OneMB)) }
  Write-Ok "$llamaRel\llama-server.exe ($sizeTxt)"
  if ($exeLen -lt (100 * $OneKB)) {
    Write-Bad "llama-server.exe весит всего $exeLen байт - распаковка побита" "scripts\01_bootstrap.cmd -SkipModel" $true
  }
  $cudaDll = @(Get-ChildItem -LiteralPath $llamaDir -Filter "ggml-cuda*.dll" -File -ErrorAction SilentlyContinue)
  $cudart = @(Get-ChildItem -LiteralPath $llamaDir -Filter "cudart64*.dll" -File -ErrorAction SilentlyContinue)
  if ($cudaDll.Count -gt 0 -and $cudart.Count -gt 0) {
    Write-Ok "CUDA-сборка: $($cudaDll[0].Name) + $($cudart[0].Name) на месте"
  } else {
    Write-Bad "нет ggml-cuda*.dll или cudart64*.dll - модель уедет на CPU (2-5 tok/s)" "scripts\01_bootstrap.cmd -SkipModel" $true
  }
} else {
  Write-Bad "нет $llamaRel\llama-server.exe" "scripts\01_bootstrap.cmd -SkipModel" $true
}

# ------------------------------------------------------------- 3. модели
Write-Section "3. Модели GGUF (сверка с bootstrap.json)"
$dirs = New-Object System.Collections.Generic.List[string]
if ($envModels) { $dirs.Add($envModels) }
$dirs.Add((Join-Path $repo ($boot.models_dir -replace '/', '\')))

$selected = ""
$cfgPath = Join-Path $env:APPDATA "Citlali\config.toml"
if (Test-Path -LiteralPath $cfgPath) {
  $hit = Select-String -LiteralPath $cfgPath -Pattern '^model_file\s*=\s*"(.+)"' | Select-Object -First 1
  if ($hit) { $selected = $hit.Matches[0].Groups[1].Value.Replace('/', '\') }
}
if ($selected -and -not [System.IO.Path]::IsPathRooted($selected)) {
  $selected = Join-Path $repo $selected
}

# Критична только РАБОЧАЯ модель (та, что в config.toml). Остальные кандидаты
# нужны лишь для повторного A/B, поэтому их отсутствие — справка, а не ошибка:
# иначе doctor советовал бы качать 5 GB модели, которая не используется.
$selectedLeaf = ""
if ($selected) { $selectedLeaf = Split-Path -Path $selected -Leaf }

foreach ($m in $boot.models) {
  $expected = [long]0
  if ($m.size_bytes) { $expected = [long]$m.size_bytes }
  $isWorking = ($selectedLeaf -and ($m.file -eq $selectedLeaf))
  $tag = ""
  if ($isWorking) { $tag = "  <- рабочая" }
  $found = $null
  $foundLen = [long]0
  foreach ($dir in $dirs) {
    if (-not (Test-Path -LiteralPath $dir)) { continue }
    $cand = Join-Path $dir $m.file
    if (Test-Path -LiteralPath $cand) {
      $found = $cand
      $foundLen = (Get-Item -LiteralPath $cand).Length
      break
    }
  }
  if (-not $found) {
    if (-not $isWorking) {
      Write-Info "$($m.name): $($m.file) не скачана - не нужна, A/B завершён 19.10"
    }
    continue
  }
  if ($expected -gt 0 -and $foundLen -ne $expected) {
    if ($isWorking) { continue }   # вердикт по рабочей модели — одним блоком ниже
    Write-Bad ("{0}: файл неполный - {1} байт из {2}; bootstrap докачает с места обрыва" -f $m.name, $foundLen, $expected) "scripts\01_bootstrap.cmd -Only $($m.name)" $false
    continue
  }
  Write-Ok ("{0,-12} {1} байт  {2}{3}" -f $m.name, $foundLen, $found, $tag)
}

if (-not $selected) {
  Write-Bad "в config.toml нет model_file - непонятно, какая модель рабочая" "scripts\pick_model.cmd qwen3.5-9b" $true
} elseif (-not (Test-Path -LiteralPath $selected)) {
  Write-Bad "рабочая модель из config.toml не найдена: $selected" "scripts\pick_model.cmd qwen3.5-9b" $true
} else {
  $selLen = (Get-Item -LiteralPath $selected).Length
  $selExp = [long]0
  foreach ($m in $boot.models) {
    if ($m.file -eq $selectedLeaf -and $m.size_bytes) { $selExp = [long]$m.size_bytes }
  }
  if ($selExp -gt 0 -and $selLen -ne $selExp) {
    Write-Bad ("рабочая модель неполная: {0} байт из {1} - {2}. Если файл удаляли, копия может быть в Корзине: scripts\restore_models.cmd" -f $selLen, $selExp, $selected) "scripts\01_bootstrap.cmd" $true
  } else {
    Write-Ok ("рабочая модель полная: {0} байт - {1}" -f $selLen, $selected)
  }
}

# ------------------------------------------------------------ 4. config.toml
Write-Section "4. Конфиг %APPDATA%\Citlali\config.toml"
if (Test-Path -LiteralPath $cfgPath) {
  Write-Ok "файл есть: $cfgPath"
  $bytes = [System.IO.File]::ReadAllBytes($cfgPath)
  if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
    Write-Bad "в конфиге BOM - tomllib такой файл не читает (A-18)" "scripts\setup_config.cmd -Force" $true
  } else {
    Write-Ok "BOM отсутствует"
  }
  $soulHit = Select-String -LiteralPath $cfgPath -Pattern '^soul_file\s*=\s*"(.+)"' | Select-Object -First 1
  if ($soulHit) {
    $soulVal = $soulHit.Matches[0].Groups[1].Value
    if ($soulVal -match '\\') {
      Write-Bad "soul_file содержит обратные слэши: $soulVal (A-18 - только прямые)" "scripts\setup_config.cmd" $false
    }
    $soulPath = $soulVal.Replace('/', '\')
    if (-not [System.IO.Path]::IsPathRooted($soulPath)) { $soulPath = Join-Path $repo $soulPath }
    if (Test-Path -LiteralPath $soulPath) { Write-Ok "soul_file ведёт на существующий файл: $soulPath" }
    else { Write-Bad "soul_file указывает на несуществующий файл: $soulPath" "scripts\setup_config.cmd" $true }
  } else {
    Write-Bad "в конфиге нет ключа soul_file" "scripts\setup_config.cmd -Force" $true
  }
  $bakCount = @(Get-ChildItem -LiteralPath (Split-Path -Parent $cfgPath) -Filter "config.toml.bak-*" -File -ErrorAction SilentlyContinue).Count
  if ($bakCount -gt 0) { Write-Info "бэкапов конфига: $bakCount (это нормально, они не мешают)" }
} else {
  Write-Bad "config.toml не найден" "scripts\setup_config.cmd" $true
}

# --------------------------------------------------------------- 5. SOUL.md
Write-Section "5. Характер (soul\SOUL.md)"
$soulFile = Join-Path $repo "soul\SOUL.md"
if (Test-Path -LiteralPath $soulFile) {
  $soulText = Get-Content -LiteralPath $soulFile -Raw -Encoding UTF8
  # A-28: git на Windows кладёт SOUL.md с CRLF, а ядро читает файл в текстовом
  # режиме Python, где \r\n превращается в \n (universal newlines). Без
  # нормализации doctor считал 5433 знака там, где ядро видело 5348 (85 строк),
  # и лимит 5600 проверялся по числу, которого в промпте не бывает.
  # Отчёт обязан показывать ровно то, что увидит ядро.
  $soulText = $soulText -replace "`r`n", "`n"
  $len = $soulText.Length
  if ($len -gt 5600) {
    Write-Bad "SOUL.md = $len знаков, лимит 5600 (A-10 ред.3) - ядро откажется стартовать, сокращайте раздел примеров" "" $false
  } else {
    Write-Ok "SOUL.md = $len знаков из 5600"
  }
} else {
  Write-Bad "нет soul\SOUL.md - ядро не стартует (SoulNotFoundError)" "git checkout -- soul/SOUL.md" $true
}

# ------------------------------------------------------------ 6. core\.venv
Write-Section "6. Python-окружение core\.venv"
$venvPy = Join-Path $repo "core\.venv\Scripts\python.exe"
if (Test-Path -LiteralPath $venvPy) {
  $out = (& $venvPy -c "import fastapi, uvicorn, pydantic, httpx, aiosqlite; print('deps ok')" 2>&1 | Out-String).Trim()
  if ($LASTEXITCODE -eq 0) {
    Write-Ok "venv на месте, зависимости импортируются"
  } else {
    Write-Bad "venv есть, но импорты падают: $out" "scripts\setup_python.cmd" $true
  }
} else {
  Write-Bad "нет core\.venv\Scripts\python.exe" "scripts\setup_python.cmd" $true
}

# --------------------------------------------------------------- 7. порты
Write-Section "7. Порты (кто слушает прямо сейчас)"
$ns = (& netstat -ano -p tcp 2>&1 | Out-String)
foreach ($pair in @(@{ Port = 8080; Who = "llama-server"; Cmd = "scripts\run_llama.cmd" },
                    @{ Port = 8787; Who = "Citlali Core"; Cmd = "scripts\run_core.cmd" })) {
  $port = $pair.Port
  if ($ns -match "127\.0\.0\.1:$port\s+\S+\s+LISTENING") {
    Write-Ok "порт $port слушается - $($pair.Who) запущен"
  } else {
    Write-Info "порт $port свободен - $($pair.Who) не запущен (запуск: $($pair.Cmd))"
  }
}

# --------------------------------------------------------------- 8. мусор
Write-Section "8. Что ест место"
$repoModels = Join-Path $repo ($boot.models_dir -replace '/', '\')
if (Test-Path -LiteralPath $repoModels) {
  $junk = @(Get-ChildItem -LiteralPath $repoModels -Filter *.gguf -File -ErrorAction SilentlyContinue)
  if ($junk.Count -gt 0) {
    $sum = [long](($junk | Measure-Object Length -Sum).Sum)
    if (-not $sum) { $sum = 0 }
    foreach ($j in $junk) {
      $exp = [long]0
      $specName = ""
      foreach ($m in $boot.models) {
        if ($m.file -eq $j.Name -and $m.size_bytes) { $exp = [long]$m.size_bytes; $specName = [string]$m.name }
      }
      # Полная копия во внешнем каталоге? Тогда файл в models\ — чистый мусор,
      # его можно удалять. Если копии нет — удаление съест прогресс докачки,
      # поэтому советуем перенос, а не del.
      $copyOk = $false
      if ($envModels) {
        $other = Join-Path $envModels $j.Name
        if (Test-Path -LiteralPath $other) {
          $otherLen = (Get-Item -LiteralPath $other).Length
          if ($exp -eq 0 -or $otherLen -eq $exp) { $copyOk = $true }
        }
      }
      if ($copyOk) {
        Write-Bad "models\$($j.Name): $(Format-Gb $j.Length) - дубль, полная копия лежит в $envModels" "del `"$($j.FullName)`"" $false
      } elseif ($exp -gt 0 -and $j.Length -ne $exp) {
        Write-Bad ("models\{0}: {1} - НЕДОКАЧАН ({2} из {3} байт), полной копии нет: удалять нельзя, пропадёт прогресс" -f $j.Name, (Format-Gb $j.Length), $j.Length, $exp) $(if ($specName) { "scripts\01_bootstrap.cmd -Only $specName" } else { "scripts\move_models.cmd" }) $false
      } else {
        Write-Bad "models\$($j.Name): $(Format-Gb $j.Length) - модель лежит внутри проекта (A-26)" "scripts\move_models.cmd" $false
      }
    }
    Write-Info "итого в models\: $(Format-Gb $sum)"
  } else {
    Write-Ok "в models\ пусто - модели живут вне проекта (A-26)"
  }
} else {
  Write-Ok "каталога models\ в проекте нет - так и задумано (A-26)"
}

$tmpDl = Join-Path $env:TEMP "citlali-dl"
if (Test-Path -LiteralPath $tmpDl) {
  $tmpSum = [long]((Get-ChildItem -LiteralPath $tmpDl -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum)
  if (-not $tmpSum) { $tmpSum = 0 }
  if ($tmpSum -gt 100MB) {
    Write-Bad "кэш загрузки $tmpDl занимает $(Format-Gb $tmpSum)" "scripts\cleanup.cmd" $false
  } else {
    Write-Info "кэш загрузки: $(Format-Gb $tmpSum)"
  }
}

foreach ($extra in @(".compare", ".eval")) {
  $p = Join-Path $repo $extra
  if (Test-Path -LiteralPath $p) {
    $s = [long]((Get-ChildItem -LiteralPath $p -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum)
    if (-not $s) { $s = 0 }
    Write-Info "$($extra): $(Format-Gb $s) (результаты замеров, можно оставить)"
  }
}

# --------------------------------------------------------------- итог
function Write-List($Items, $Fixes, [string]$Header, [string]$Color) {
  if ($Items.Count -eq 0) { return }
  Write-Host ""
  if ($Header) { Write-Host $Header -ForegroundColor $Color }
  for ($i = 0; $i -lt $Items.Count; $i = $i + 1) {
    Write-Host ("  {0}. {1}" -f ($i + 1), $Items[$i])
    # Команда — отдельной строкой и без отступа: её берут выделением строки.
    if ($Fixes[$i]) { Write-Host $Fixes[$i] -ForegroundColor $Color }
  }
}

Write-Host ""
Write-Host "==============================================" -ForegroundColor Cyan
if ($script:critical -eq 0) {
  Write-Host "ИТОГ: запускать можно. Критичных проблем нет." -ForegroundColor Green
  Write-List $script:warnings $script:warnFixes "Не критично, но порядок стоит навести:" "Yellow"
  Write-Host ""
  Write-Host "Дальше по окнам (каждое - отдельно, не закрывать до конца замера):" -ForegroundColor Cyan
  Write-Host "  окно A:  scripts\run_llama.cmd" -ForegroundColor Cyan
  Write-Host "  окно B:  scripts\run_core.cmd" -ForegroundColor Cyan
  Write-Host "  окно C:  scripts\bench.cmd" -ForegroundColor Cyan
  exit 0
}

Write-Host "ИТОГ: критичных проблем - $($script:critical). Сначала лечение:" -ForegroundColor Red
Write-List $script:criticals $script:criticalFixes "" "Red"
if ($script:warnings.Count -gt 0) {
  Write-Host ""
  Write-Host "Плюсом предупреждений: $($script:warnings.Count) - старту не мешают, список в разделах выше." -ForegroundColor Yellow
}
Write-Host ""
Write-Host "После лечения повторите: scripts\doctor.cmd" -ForegroundColor Cyan
exit 1
