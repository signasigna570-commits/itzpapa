@echo off
REM ============================================================
REM  Citlali: skachat' modeli bez HF API (tolko curl.exe)
REM
REM  Zachem otdel'no: HF API s nekotorikh IP otdaet 401/308,
REM  no SAMO SKACHIVANIE po resolve-ssylkam pri etom rabotaet.
REM  Zdes' URL zashity vnutri, poetomu skript ne zavisit ot API.
REM
REM  Dokachka: curl -C - prodolzhaet s mesta obryva.
REM  Uzhe skachannyy fayl: curl skazhet "range not satisfiable"
REM  i ostavit fayl kak est' - eto normal'no.
REM
REM  Kuda kachaem (A-26): modeli u operatora propadali VMESTE s papkoy
REM  proekta. Poetomu katalog mozhno vynesti naruzhu peremennoy
REM  CITLALI_MODELS_DIR (napr. C:\citlali-models); bez nee - models\.
REM
REM  Isp.:  scripts\download_models.cmd
REM         scripts\download_models.cmd hf-mirror.com
REM ============================================================
setlocal EnableExtensions
cd /d "%~dp0.."

set "HOST=huggingface.co"
if not "%~1"=="" set "HOST=%~1"

set "MD=models"
if defined CITLALI_MODELS_DIR set "MD=%CITLALI_MODELS_DIR%"
if not exist "%MD%" mkdir "%MD%"
echo [Citlali] katalog modeley: %MD%

echo.
echo === 1/3  Qwen3-14B-Q4_K_M.gguf  (9.00 GB) ===
curl.exe -L --fail --retry 5 --retry-delay 5 -C - -o "%MD%\Qwen3-14B-Q4_K_M.gguf" https://%HOST%/Qwen/Qwen3-14B-GGUF/resolve/main/Qwen3-14B-Q4_K_M.gguf

echo.
echo === 2/3  Qwen3-8B-Q4_K_M.gguf  (5.03 GB) ===
curl.exe -L --fail --retry 5 --retry-delay 5 -C - -o "%MD%\Qwen3-8B-Q4_K_M.gguf" https://%HOST%/Qwen/Qwen3-8B-GGUF/resolve/main/Qwen3-8B-Q4_K_M.gguf

echo.
echo === 3/3  Qwen3.5-9B-Q4_K_M.gguf  (5.68 GB) ===
curl.exe -L --fail --retry 5 --retry-delay 5 -C - -o "%MD%\Qwen3.5-9B-Q4_K_M.gguf" https://%HOST%/unsloth/Qwen3.5-9B-GGUF/resolve/main/Qwen3.5-9B-Q4_K_M.gguf

echo.
echo === Itog: chto lezhit v %MD% ===
dir "%MD%\*.gguf" 2>nul | findstr /i ".gguf"

REM Vse resheniya - odnostrochnye if s goto. Bloki "if (...) else (...)"
REM s vlozhennymi echo i spetsial'nymi simvolami v batch lomayutsya tixo:
REM   operator videl ": was unexpected at this time" posredi uspeshnoy zakachki.
REM Odnoznachnost' vazhnee kompaktnosti (A-17).
set "MISSING=0"
if not exist "%MD%\Qwen3-14B-Q4_K_M.gguf" set "MISSING=1"
if not exist "%MD%\Qwen3-8B-Q4_K_M.gguf" set "MISSING=1"
if not exist "%MD%\Qwen3.5-9B-Q4_K_M.gguf" set "MISSING=1"
if not "%MISSING%"=="0" goto MISSING

echo.
echo [OK] Vse tri modeli na meste. Tochnye razmery v baytah, HF API ot 18.10.2026:
echo        Qwen3-14B-Q4_K_M.gguf    9001752960
echo        Qwen3-8B-Q4_K_M.gguf     5027783488
echo        Qwen3.5-9B-Q4_K_M.gguf   5680522464
echo      Sver'te s vyvodom dir vyshe. Sovpadenie = fayl tsel.
echo.
echo === Propisyvayu puti v config.toml ===
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup_config.ps1"
echo.
echo Konfig obnovlen. Dalee - scripts\eval_character.cmd
endlocal
exit /b 0

:MISSING
echo.
echo [WARN] Kakogo-to fayla net.
echo    1. Povtorite etot skript - dokachaetsya s mesta obryva.
echo    2. Esli snova obryv - scripts\download_models.cmd hf-mirror.com
echo    3. Esli i zerkalo ne rabotaet - skachayte brauzerom i polozhite GGUF v %MD%
endlocal
exit /b 1
