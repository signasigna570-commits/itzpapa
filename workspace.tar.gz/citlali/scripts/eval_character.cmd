@echo off
REM ============================================================
REM  Citlali: provokatsionnyy test haraktera (priemochnyy kriteriy #3)
REM
REM  Isp.:  scripts\eval_character.cmd
REM         scripts\eval_character.cmd qwen-card      (drugoy preset semplirovaniya)
REM         scripts\eval_character.cmd all            (vse presety x vse modeli, A/B)
REM         scripts\eval_character.cmd default 4096   (preset + kontekst)
REM
REM  Presety: default | qwen-card | expressive  (sm. SAMPLING_PRESETS v
REM  scripts\eval_character.py). "all" gonit kazhduyu model' kazhdym presetom.
REM
REM  Server podnimaetsya na portu 8091+ (ne meshaet 8080 i 8090).
REM ============================================================
setlocal EnableExtensions
cd /d "%~dp0.."

set "PY=python"
if exist "core\.venv\Scripts\python.exe" set "PY=core\.venv\Scripts\python.exe"

set "MD=models"
if defined CITLALI_MODELS_DIR set "MD=%CITLALI_MODELS_DIR%"

set "PRESET=%~1"
if "%PRESET%"=="" set "PRESET=default"
set "CTX=%~2"
if "%CTX%"=="" set "CTX=8192"

if /i "%PRESET%"=="all" (
  "%PY%" scripts\eval_character.py --models-dir "%MD%" --ctx %CTX% --all-presets
) else (
  "%PY%" scripts\eval_character.py --models-dir "%MD%" --ctx %CTX% --preset %PRESET%
)
set RC=%errorlevel%

echo.
if not "%RC%"=="0" (
  echo Kod vozvrata %RC%. Prishlite mne stroki [FAIL] vyshe.
) else (
  echo Prishlite mne itogovuyu tablicu "ITOG PO HARAKTERU" i neskol'ko otvetov
  echo kazhoy modeli - po nim vidno, derzhit li model' rol' i ne sukhayat li otvety.
  echo Polnye otvety lezhat v kataloge .eval v formate JSON.
)
endlocal & exit /b %RC%
