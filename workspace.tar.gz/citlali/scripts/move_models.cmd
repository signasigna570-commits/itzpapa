@echo off
REM ============================================================
REM  Citlali: perebrat' modeli GGUF iz models\ vne proekta (A-26)
REM  bez povtornoy zakachki 19.7 GB. Obertka dlya move_models.ps1.
REM
REM  Zachem skript, a ne ruchnoy "move": posle perenosa razmery
REM  sveryayutsya pobaityavo s bootstrap.json - inache povrezhdenie
REM  molcha uedet v novyy katalog.
REM
REM  Isp.:  scripts\move_models.cmd
REM  Pered zapuskom:  setx CITLALI_MODELS_DIR C:\citlali-models
REM  i otkryt' novoe okno, chtoby peremennaya primenilas'.
REM ============================================================
setlocal EnableExtensions
cd /d "%~dp0.."

if not defined CITLALI_MODELS_DIR goto NOENV
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0move_models.ps1"
endlocal & exit /b %errorlevel%

:NOENV
echo [FAIL] Peremennaya CITLALI_MODELS_DIR ne zadana.
echo        Vypolnite:  setx CITLALI_MODELS_DIR C:\citlali-models
echo        Zatem otkroyte novoe okno i povtorite:  scripts\move_models.cmd
endlocal
exit /b 2
