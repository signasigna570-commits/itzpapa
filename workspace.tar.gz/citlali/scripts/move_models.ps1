﻿<#
.SYNOPSIS
  Citlali: перенести модели GGUF из models\ в каталог CITLALI_MODELS_DIR.

.DESCRIPTION
  Зачем (A-26): содержимое папки проекта у оператора четыре раза пропадало,
  а модели — это 19.7 GB и ~6 минут закачки. Вне проекта они выживают.

  Шаги:
    1. каждый *.gguf из models\ переносится в CITLALI_MODELS_DIR
       (в пределах одного тома Move-Item мгновенен — это переименование);
    2. если в назначении уже лежит файл с тем же именем: размер совпал —
       дубликат из models\ удаляется; не совпал — оба файла остаются
       нетронутыми, скрипт предупреждает и завершается ошибкой;
    3. самопроверка (A-17): размеры всех моделей из bootstrap.json
       сверяются побайтово, в models\ не должно остаться *.gguf.

  После успеха: scripts\pick_model.cmd qwen3.5-9b — и конфиг укажет
  на модель уже во внешнем каталоге.

.EXAMPLE
  powershell -NoProfile -ExecutionPolicy Bypass -File scripts\move_models.ps1
#>

$ErrorActionPreference = "Continue"

$repo = Split-Path -Parent $PSScriptRoot
$src = Join-Path $repo "models"
$dst = $env:CITLALI_MODELS_DIR

if (-not $dst) {
  Write-Host "[FAIL] CITLALI_MODELS_DIR не задана." -ForegroundColor Red
  Write-Host "       Выполните:  setx CITLALI_MODELS_DIR C:\citlali-models"
  Write-Host "       Затем откройте новое окно и повторите запуск."
  exit 2
}

$bootPath = Join-Path $PSScriptRoot "bootstrap.json"
if (-not (Test-Path -LiteralPath $bootPath)) {
  Write-Host "[FAIL] нет scripts/bootstrap.json - не с чем сверить размеры." -ForegroundColor Red
  exit 3
}
$boot = Get-Content -LiteralPath $bootPath -Raw -Encoding UTF8 | ConvertFrom-Json
$expected = @{}
foreach ($m in $boot.models) {
  if ($m.file -and $m.size_bytes) { $expected[[string]$m.file] = [long]$m.size_bytes }
}

if (-not (Test-Path -LiteralPath $dst)) {
  New-Item -ItemType Directory -Force -Path $dst | Out-Null
  Write-Host "[Citlali] создан каталог: $dst"
}

# ------------------------------------------------------------------ перенос
$moved = 0
$warn = 0
if (-not (Test-Path -LiteralPath $src)) {
  Write-Host "[Citlali] каталога models в проекте нет - переносить нечего."
} else {
  $found = @(Get-ChildItem -LiteralPath $src -Filter *.gguf -File -ErrorAction SilentlyContinue)
  if ($found.Count -eq 0) {
    Write-Host "[Citlali] в models нет *.gguf - переносить нечего."
  }
  foreach ($f in $found) {
    $target = Join-Path $dst $f.Name
    if (Test-Path -LiteralPath $target) {
      $t = Get-Item -LiteralPath $target
      if ($t.Length -eq $f.Length) {
        Write-Host ("[Citlali] {0}: копия уже в назначении - убираю дубликат из models" -f $f.Name)
        Remove-Item -LiteralPath $f.FullName -Force
        $moved++
      } else {
        Write-Host ("[WARN] {0}: в назначении файл другого размера - не трогаю ни тот, ни другой." -f $f.Name) -ForegroundColor Yellow
        $warn++
      }
      continue
    }
    if ((Split-Path -Qualifier $f.FullName) -ne (Split-Path -Qualifier $dst)) {
      Write-Host ("[Citlali] {0}: другой том - это полноценное копирование, не мгновенно..." -f $f.Name)
    }
    Move-Item -LiteralPath $f.FullName -Destination $target
    $moved++
    Write-Host ("[Citlali] перенесено: {0}" -f $f.Name)
  }
}

# --------------------------------------------- самопроверка размеров (A-17)
Write-Host ""
Write-Host ("=== Itog: chto lezhit v {0} ===" -f $dst)
$fail = $warn
foreach ($name in ($expected.Keys | Sort-Object)) {
  $p = Join-Path $dst $name
  if (-not (Test-Path -LiteralPath $p)) {
    Write-Host ("[FAIL] {0}: файла нет" -f $name) -ForegroundColor Red
    $fail++
    continue
  }
  $actual = (Get-Item -LiteralPath $p).Length
  $want = $expected[$name]
  if ($actual -eq $want) {
    Write-Host ("[OK]   {0}  {1} байт - сходится с bootstrap.json" -f $name, $actual)
  } else {
    Write-Host ("[FAIL] {0}  {1} байт, ожидалось {2} - файл битый или недокачан" -f $name, $actual, $want) -ForegroundColor Red
    $fail++
  }
}

if (Test-Path -LiteralPath $src) {
  $left = @(Get-ChildItem -LiteralPath $src -Filter *.gguf -File -ErrorAction SilentlyContinue)
  if ($left.Count -gt 0) {
    Write-Host "[WARN] в models остались *.gguf - перенос неполный:" -ForegroundColor Yellow
    foreach ($f in $left) { Write-Host ("       {0}" -f $f.Name) }
    $fail++
  }
}

Write-Host ""
if ($fail -ne 0) {
  Write-Host "[FAIL] перенос не завершён - смотрите строки выше." -ForegroundColor Red
  Write-Host "       Починить: scripts\download_models.cmd - докачает недостающее"
  Write-Host "       сразу во внешний каталог (curl -C - продолжает с места обрыва)."
  exit 1
}
Write-Host ("[OK] все модели на месте и сверены побайтово. Перенесено файлов: {0}" -f $moved)
Write-Host "     Дальше: scripts\pick_model.cmd qwen3.5-9b"
exit 0
