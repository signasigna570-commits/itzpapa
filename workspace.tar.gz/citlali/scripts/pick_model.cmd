@echo off
REM ============================================================
REM  Citlali: vybrat' rabochuyu model' odnoy komandoy
REM
REM  Isp.:  scripts\pick_model.cmd qwen3-14b
REM         scripts\pick_model.cmd qwen3-8b
REM         scripts\pick_model.cmd qwen3.5-9b
REM
REM  Propisyvaet model_file v %APPDATA%\Citlali\config.toml
REM  (cherez setup_config.ps1, s samoproverkoy puti).
REM  Katalog modeley: CITLALI_MODELS_DIR, esli zadana, inache models\ (A-26).
REM ============================================================
setlocal EnableExtensions
cd /d "%~dp0.."

set "WHO=%~1"
if "%WHO%"=="" goto USAGE

set "GGUF="
if /i "%WHO%"=="qwen3-14b" set "GGUF=Qwen3-14B-Q4_K_M.gguf"
if /i "%WHO%"=="qwen3-8b" set "GGUF=Qwen3-8B-Q4_K_M.gguf"
if /i "%WHO%"=="qwen3.5-9b" set "GGUF=Qwen3.5-9B-Q4_K_M.gguf"

if "%GGUF%"=="" goto USAGE

set "MD=models"
if defined CITLALI_MODELS_DIR set "MD=%CITLALI_MODELS_DIR%"
REM Otnositel'nyy MD razreshitsya ot kornya repo (my zdes' posle cd),
REM absolyutnyy - kak est'. setup_config.ps1 privedet put' k absolyutnomu
REM cherez Resolve-Path, poetomu podstanovki podstrok v batch ne nuzhny.

if not exist "%MD%\%GGUF%" (
  echo [FAIL] %MD%\%GGUF% ne naiden. Snachala scripts\download_models.cmd
  exit /b 2
)

set "CITLALI_MODEL=%MD%\%GGUF%"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup_config.ps1" -Force
if errorlevel 1 (
  echo [FAIL] setup_config.ps1 ne propisal model'. Prishlite vyvod.
  exit /b 3
)

echo.
echo [OK] Rabochaya model': %GGUF%
echo      Proverka: scripts\run_core.cmd, potom v drugom okne scripts\bench.cmd
endlocal
exit /b 0

:USAGE
echo Dostupnye imena: qwen3-14b, qwen3-8b, qwen3.5-9b
echo Primer: scripts\pick_model.cmd qwen3.5-9b
endlocal
exit /b 1
