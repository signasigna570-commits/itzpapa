@echo off
REM ============================================================
REM  Citlali: proba razrezhennyh faylov (obertka dlya
REM  probe_sparse.ps1). Tolko ASCII: kirillitsa v .cmd lomayet
REM  kodovuyu stranitsu konsoli (lovushka 2).
REM
REM  Zachem: 20.10.2026 testy poiska modeley zapisali v
REM  %TEMP%\pytest-of-User 63.5 GB "besplatnyh" zaglushek GGUF -
REM  fh.truncate() na NTFS vydelayet mesto tselikom (lovushka 25).
REM  Proba sozdayet fayl 5 GB v %TEMP% i smotrit, skolko bayt tom
REM  vydelil na samom dele. Sam fayl ona zhe i udalyaet; bolshe
REM  nichego ne udalyaet (A-17).
REM
REM  Isp.:  scripts\probe_sparse.cmd       - proba na 5 GB
REM         scripts\probe_sparse.cmd 1     - proba na 1 GB (bystree)
REM
REM  Kody vozvrata: 0 - tom derzhit razrezhennye fayly,
REM                 1 - fayl zanyal mesto tselikom,
REM                 2 - proba ne zapustilas (net okruzheniya Python).
REM ============================================================
setlocal
cd /d "%~dp0.."

if "%~1"=="" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0probe_sparse.ps1"
) else (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0probe_sparse.ps1" -SizeGb %1
)
set "RC=%errorlevel%"
endlocal & exit /b %RC%
