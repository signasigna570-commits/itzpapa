﻿<#
.SYNOPSIS
  Citlali: proba razrezhennyh faylov - tom operatora derzhit zaglushki besplatno?

.DESCRIPTION
  20.10.2026 otchet diag_disk pokazal u operatora [63.51 GB] v AppData\Local\Temp:
  trinadtsat GGUF po 4-8 GB vnutri pytest-of-User\pytest-6..8. Ikh zapisali nashi zhe
  testy poiska modeley: fh.truncate(size) v pesochnitse (ext4) daet razrezhennyy fayl
  (nol blokov na diske), a na NTFS on zhe vydelayaet mesto tselikom - okolo 24 GB za
  progon, pytest hranit poslednie neskolko progono (lovushka 25).

  Lecchenie - core/tests/sparsefile.py: na Windows fayl pomechaetsya razrezhennym
  (FSCTL_SET_SPARSE) i diapazon zanulyaetsya (FSCTL_SET_ZERO_DATA). Eta proba
  provoryaet, chto na konkretnom tome operatora eto deystvitelno tak: sozdayet fayl
  s dlinoy 5 GB v %TEMP% i smotrit, skolko bayt tom vydalil.

  Skript NICHEGO ne udalyaet, krome sobstvennogo vremennoho fayla (ego zhe
  sozdal); katalog proekta i modeli ne trogayut.

.PARAMETER SizeGb
  Razmer probnoho fayla v GB (po umolchaniyu 5 - poryadka razmera GGUF).

.EXAMPLE
  scripts\probe_sparse.cmd
  scripts\probe_sparse.cmd 1
#>

[CmdletBinding()]
param([double]$SizeGb = 5)

$ErrorActionPreference = "Continue"
$repo = Split-Path -Parent $PSScriptRoot
$core = Join-Path $repo "core"
$py = Join-Path $core ".venv\Scripts\python.exe"
if (-not (Test-Path -LiteralPath $py)) { $py = "python" }

$bytes = [long]($SizeGb * 1e9)
Write-Host "############################################################"
Write-Host "#  Citlali: proba razrezhennyh faylov (nichego ne udalyaet)"
Write-Host "############################################################"
Write-Host ("    tom:       " + $env:TEMP)
Write-Host ("    fayl:      " + $bytes + " bayt (st_size)")
Write-Host ""

Push-Location $core
try {
  $lines = & $py "-m" "tests.sparse_probe" ("--size=" + $bytes) 2>&1
} finally {
  Pop-Location
}

$verdict = "UNKNOWN"
$allocated = -1
foreach ($line in $lines) {
  $text = [string]$line
  if ($text -match "^(dir|fs|requested_size|logical_size|allocated|free_before|free_after|free_delta|ratio|error)=(.*)$") {
    Write-Host ("    " + $Matches[1] + " = " + $Matches[2])
    if ($Matches[1] -eq "allocated") { $allocated = [long]$Matches[2] }
  } elseif ($text -match "^SPARSE=(OK|FAIL)$") {
    $verdict = $Matches[1]
  } elseif ($text.Trim().Length -gt 0) {
    Write-Host ("    python: " + $text)
  }
}

Write-Host ""
if ($verdict -eq "OK") {
  $mb = [math]::Round($allocated / 1e6, 2)
  Write-Host ("[OK] Tom derzhit razrezhennye fayly: pod fayl " + $bytes + " bayt vydeleno " + $mb + " MB.")
  Write-Host "     Zaglushki GGUF v testah besplatny - Temp ne razduvaetsya (T0.38)."
  exit 0
}
if ($verdict -eq "FAIL") {
  Write-Host "[FAIL] Fayl s dlinoy 5 GB zanyal mesto tselikom: testy poiska modeley"
  Write-Host "       zapisali by desyatki GB v %TEMP%. Testy propustyatsya sami (skipif),"
  Write-Host "       no prishlite mne vyvod vyshe - budem reshat, kuda klast zaglushki."
  exit 1
}
Write-Host "[FAIL] Proba ne otrabotala: python ne zapustil ili ne napechatal SPARSE=."
Write-Host "       Lechenie (sozdaet okruzhenie zanovo):"
Write-Host "scripts\setup_python.cmd"
exit 2
