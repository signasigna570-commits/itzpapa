﻿<#
.SYNOPSIS
  Citlali: напечатать абсолютный путь к рабочей модели GGUF (одной строкой).

.DESCRIPTION
  Порядок поиска:
    1. $env:CITLALI_MODEL            — явное указание;
    2. model_file из config.toml     — если файл существует;
    3. крупнейший .gguf в $env:CITLALI_MODELS_DIR;
    4. крупнейший .gguf в <репозиторий>\models.

  Ничего не печатает и возвращает 1, если модели нет нигде.
  Отдельный файл, а не инлайн-PowerShell внутри .cmd: вложенные кавычки
  и скобки в батче ломают парсинг (дефект A-26, run_llama.cmd падал с
  "was unexpected at this time").
#>

$ErrorActionPreference = "Continue"
$repo = Split-Path -Parent $PSScriptRoot

if ($env:CITLALI_MODEL -and (Test-Path -LiteralPath $env:CITLALI_MODEL)) {
  Write-Output (Resolve-Path -LiteralPath $env:CITLALI_MODEL).Path
  exit 0
}

$cfg = Join-Path $env:APPDATA "Citlali\config.toml"
if (Test-Path -LiteralPath $cfg) {
  $hit = Select-String -LiteralPath $cfg -Pattern '^model_file\s*=\s*"(.+)"' | Select-Object -First 1
  if ($hit) {
    $v = $hit.Matches[0].Groups[1].Value.Replace('/', '\')
    if (-not [System.IO.Path]::IsPathRooted($v)) { $v = Join-Path $repo $v }
    if (Test-Path -LiteralPath $v) {
      Write-Output $v
      exit 0
    }
  }
}

$dirs = New-Object System.Collections.Generic.List[string]
if ($env:CITLALI_MODELS_DIR) { $dirs.Add($env:CITLALI_MODELS_DIR) }
$dirs.Add((Join-Path $repo "models"))

foreach ($d in $dirs) {
  if (-not (Test-Path -LiteralPath $d)) { continue }
  $gguf = Get-ChildItem -LiteralPath $d -Filter *.gguf -File -ErrorAction SilentlyContinue |
    Sort-Object Length -Descending | Select-Object -First 1
  if ($gguf) {
    Write-Output $gguf.FullName
    exit 0
  }
}

exit 1
