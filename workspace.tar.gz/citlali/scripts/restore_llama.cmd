@echo off
REM ============================================================
REM  Citlali: obnovit' binarniki llama.cpp posle udaleniya papki
REM  (obertka dlya 01_bootstrap.ps1 -SkipModel)
REM
REM  Modeli NE trogaet: ih vosstanavlivaet restore_models.cmd
REM  Isp.:  scripts\restore_llama.cmd
REM ============================================================
setlocal
cd /d "%~dp0.."

if exist "tools\llama\llama-server.exe" (
  echo [OK] tools\llama\llama-server.exe uzhe na meste - nichego delat' ne nuzhno.
  exit /b 0
)

echo [Citlali] binarnikov net - rasshikovuyu ili skachayu zanovo ~650 MB
echo           (modeli pri etom ne tragayutsya)
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp001_bootstrap.ps1" -SkipModel
set RC=%errorlevel%

echo.
if exist "tools\llama\llama-server.exe" (
  echo [OK] llama-server.exe na meste.
) else (
  echo [FAIL] llama-server.exe tak i ne poyavilsya. Kod vozvrata %RC%.
)
endlocal & exit /b %RC%
