@echo off
REM ============================================================
REM  Citlali: vernut' modeli iz Korziny v models\ bez zakachki 19.7 GB
REM  (obertka dlya restore_models.ps1)
REM
REM  Isp.:  scripts\restore_models.cmd         - pokazat' i vosstanovit'
REM         scripts\restore_models.cmd dry     - tol'ko pokazat', chto naideno
REM ============================================================
setlocal
cd /d "%~dp0.."

if /i "%~1"=="dry" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0restore_models.ps1" -WhatIf
) else (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0restore_models.ps1"
)
endlocal & exit /b %errorlevel%
