﻿<#
.SYNOPSIS
  Citlali: вернуть модели из Корзины в models\ — без повторной закачки 19.7 GB.

.DESCRIPTION
  Корзина Windows хранит каждый удалённый файл парой:
    $I<метка>  — метаданные (исходный путь, имя, дата удаления)
    $R<метка>  — само содержимое файла

  Скрипт перебирает $I-файлы, читает из них исходный путь, и если файл был
  удалён из каталога models этого репозитория — переносит соответствующий
  $R-файл обратно под настоящим именем. Копия выбирается самая свежая.

  Оператор удалял папку проекта через Проводник трижды, поэтому в Корзине
  оказалось три полных комплекта моделей (55.7 GB). Восстанавливается один.

.PARAMETER WhatIf
  Ничего не переносить, только показать, что найдено.

.EXAMPLE
  powershell -NoProfile -ExecutionPolicy Bypass -File scripts\restore_models.ps1 -WhatIf
  powershell -NoProfile -ExecutionPolicy Bypass -File scripts\restore_models.ps1
#>

[CmdletBinding()]
param(
  [switch]$WhatIf
)

$ErrorActionPreference = "Continue"

$repo = Split-Path -Parent $PSScriptRoot
$modelsDir = Join-Path $repo "models"

if (-not (Test-Path -LiteralPath $modelsDir)) {
  New-Item -ItemType Directory -Force -Path $modelsDir | Out-Null
  Write-Host "[Citlali] создан каталог $modelsDir"
}

# T0.36: единицы десятичные (AGENTS пар. 6: GB = 1000^3). Литерал PowerShell
# GB равен 1024^3, а размеры в bootstrap.json и в отчётах оператора - десятичные.
$OneGB = 1e9

function Get-FreeGb([string]$Path) {
  $drive = Split-Path -Qualifier $Path
  $d = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$drive'"
  return [math]::Round($d.FreeSpace / $OneGB, 1)
}

Write-Host ""
Write-Host ("Свободно на {0}: {1} GB" -f (Split-Path -Qualifier $repo), (Get-FreeGb $repo))
Write-Host ""

# ------------------------------------------------------------------ поиск
$binRoot = "C:\`$Recycle.Bin"
if (-not (Test-Path -LiteralPath $binRoot)) {
  Write-Host "[FAIL] Корзина не найдена: $binRoot" -ForegroundColor Red
  exit 1
}

$wantedDir = ($modelsDir + "\").ToLowerInvariant()
$found = @{}
$script:Scanned = 0
$script:Skipped = 0
$script:GgufInBin = 0

Get-ChildItem -LiteralPath $binRoot -Directory -Force -ErrorAction SilentlyContinue | ForEach-Object {
  $sidDir = $_.FullName
  Get-ChildItem -LiteralPath $sidDir -Filter '$I*' -File -Force -ErrorAction SilentlyContinue | ForEach-Object {
    $meta = $_
    try {
      # Формат $I (Windows 10+, версия 2):
      #   0..7   int64  version (=2)
      #   8..15  int64  размер файла
      #  16..23  int64  FILETIME удаления
      #  28..    UTF-16LE путь, завершённый нулём
      # В версии 1 путь начинался с байта 24. Первая реализация читала с 24
      # и поэтому получала мусор вместо пути — скрипт «не видел» ни одного файла.
      $bytes = [System.IO.File]::ReadAllBytes($meta.FullName)
      if ($bytes.Length -lt 28) { $script:Skipped++ ; return }
      $version = [BitConverter]::ToInt64($bytes, 0)
      $pathOffset = 28
      if ($version -lt 2) { $pathOffset = 24 }
      if ($bytes.Length -le $pathOffset) { $script:Skipped++; return }
      $deleted = [DateTime]::FromFileTime([BitConverter]::ToInt64($bytes, 16))
      $orig = [System.Text.Encoding]::Unicode.GetString(
        $bytes, $pathOffset, $bytes.Length - $pathOffset
      ).TrimEnd([char]0)
      $script:Scanned++
    } catch {
      $script:Skipped++
      return
    }
    if (-not $orig) { return }
    if (-not $orig.ToLowerInvariant().EndsWith(".gguf")) { return }
    $script:GgufInBin++
    if (-not $orig.ToLowerInvariant().StartsWith($wantedDir)) { return }

    $rPath = Join-Path $sidDir ($meta.Name -replace '^\$I', '$R')
    if (-not (Test-Path -LiteralPath $rPath)) { return }

    $name = Split-Path $orig -Leaf
    $prev = $found[$name]
    if ($null -eq $prev -or $deleted -gt $prev.Deleted) {
      $found[$name] = [PSCustomObject]@{
        Name    = $name
        RPath   = $rPath
        Meta    = $meta.FullName
        Deleted = $deleted
        Bytes   = (Get-Item -LiteralPath $rPath -Force).Length
      }
    }
  }
}

Write-Host ("Просканировано I-записей Корзины: {0} (битых пропущено: {1}), из них GGUF: {2}" -f $script:Scanned, $script:Skipped, $script:GgufInBin)
Write-Host ""

if ($found.Count -eq 0) {
  Write-Host "[WARN] Не удалось сопоставить GGUF с путём $modelsDir" -ForegroundColor Yellow
  Write-Host "       Ищу в Корзине любые .gguf по маске содержимого (`$R*)..."
  $loose = @()
  Get-ChildItem -LiteralPath $binRoot -Directory -Force -ErrorAction SilentlyContinue | ForEach-Object {
    $loose += Get-ChildItem -LiteralPath $_.FullName -Filter '$R*' -File -Force -ErrorAction SilentlyContinue |
      Where-Object { $_.Length -gt (1 * $OneGB) }
  }
  if ($loose.Count -eq 0) {
    Write-Host "[FAIL] В Корзине вообще нет больших файлов - модели придётся скачать заново:" -ForegroundColor Red
    Write-Host "           scripts\download_models.cmd"
    exit 2
  }
  Write-Host ""
  Write-Host "Найдено кандидатов (свежайший на каждое имя берётся по размеру/дате):"
  foreach ($f in ($loose | Sort-Object Length -Descending)) {
    Write-Host ("    {0,7:N2} GB  {1}" -f ($f.Length / $OneGB), $f.FullName)
  }
  $needGb = [math]::Round((($loose | Measure-Object Length -Sum).Sum) / $OneGB, 1)
  $freeGb = Get-FreeGb $repo
  $useMove = $freeGb -lt ($needGb + 5)
  Write-Host ""
  Write-Host ("Нужно {0} GB, свободно {1} GB -> {2}" -f $needGb, $freeGb, $(if ($useMove) { "ПЕРЕНОШУ (места впритык)" } else { "КОПИРУЮ (оригиналы останутся в Корзине)" }))
  Write-Host "Имена подбираю по размеру: 9 GB -> 14B, 5.6 GB -> 3.5-9B, 4.6 GB -> 8B"
  foreach ($f in ($loose | Sort-Object Length -Descending)) {
    $bytes = [long]$f.Length
    $name = $null
    if ($bytes -gt (7.5 * $OneGB)) { $name = "Qwen3-14B-Q4_K_M.gguf" }
    elseif ($bytes -gt (5.0 * $OneGB)) { $name = "Qwen3.5-9B-Q4_K_M.gguf" }
    elseif ($bytes -gt (4.0 * $OneGB)) { $name = "Qwen3-8B-Q4_K_M.gguf" }
    if (-not $name) { Write-Host "    [skip] $($f.Name): размер не похож ни на одну из моделей"; continue }
    $dest = Join-Path $modelsDir $name
    if (Test-Path -LiteralPath $dest) { Write-Host "    [skip] $name уже на месте"; continue }
    try {
      if ($useMove) {
        Move-Item -LiteralPath $f.FullName -Destination $dest -Force -ErrorAction Stop
      } else {
        Copy-Item -LiteralPath $f.FullName -Destination $dest -Force -ErrorAction Stop
      }
      Write-Host ("    [ok]   {0} -> {1}" -f $name, $dest) -ForegroundColor Green
    } catch {
      Write-Host ("    [FAIL] {0}: {1}" -f $name, $_.Exception.Message) -ForegroundColor Red
    }
  }
  Write-Host ""
  Write-Host "ВНИМАНИЕ: имена подобраны по размеру. Обязательно сверьте байты:"
  Write-Host "    Qwen3-14B-Q4_K_M.gguf    9001752960"
  Write-Host "    Qwen3.5-9B-Q4_K_M.gguf   5680522464"
  Write-Host "    Qwen3-8B-Q4_K_M.gguf     5027783488"
  Get-ChildItem -LiteralPath $modelsDir -Filter *.gguf | ForEach-Object {
    Write-Host ("    факт: {0,-28} {1,14:N0}" -f $_.Name, $_.Length)
  }
  exit 0
}

# ------------------------------------------------------------------ отчёт
Write-Host "Найдено в Корзине:"
foreach ($k in ($found.Keys | Sort-Object)) {
  $f = $found[$k]
  Write-Host ("    {0,-28} {1,7:N2} GB   удалён {2:yyyy-MM-dd HH:mm}" -f $f.Name, ($f.Bytes / $OneGB), $f.Deleted)
}
Write-Host ""

if ($WhatIf) {
  Write-Host "[dry] Ничего не переносил. Запустите без -WhatIf для восстановления." -ForegroundColor Cyan
  exit 0
}

# -------------------------------------------------------------- восстановление
$restored = 0
foreach ($k in ($found.Keys | Sort-Object)) {
  $f = $found[$k]
  $dest = Join-Path $modelsDir $f.Name

  if (Test-Path -LiteralPath $dest) {
    $existing = (Get-Item -LiteralPath $dest).Length
    if ($existing -eq $f.Bytes) {
      Write-Host ("    [skip] {0} уже на месте ({1:N0} байт)" -f $f.Name, $existing)
      $restored++
      continue
    }
    Write-Host ("    [warn] {0} уже существует, но размер {1} != {2} - перезаписываю" -f $f.Name, $existing, $f.Bytes) -ForegroundColor Yellow
    Remove-Item -LiteralPath $dest -Force
  }

  try {
    Move-Item -LiteralPath $f.RPath -Destination $dest -Force -ErrorAction Stop
    Remove-Item -LiteralPath $f.Meta -Force -ErrorAction SilentlyContinue
    Write-Host ("    [ok]   {0} -> {1}" -f $f.Name, $dest) -ForegroundColor Green
    $restored++
  } catch {
    Write-Host ("    [FAIL] {0}: {1}" -f $f.Name, $_.Exception.Message) -ForegroundColor Red
    Write-Host "           Если отказано в доступе - запустите cmd от имени администратора."
  }
}

# ------------------------------------------------------------------ проверка
Write-Host ""
Write-Host "Что теперь в models\:"
Get-ChildItem -LiteralPath $modelsDir -Filter *.gguf -Force | ForEach-Object {
  Write-Host ("    {0,-28} {1,14:N0} байт   {2,6:N2} GB" -f $_.Name, $_.Length, ($_.Length / $OneGB))
}
Write-Host ""
Write-Host ("Свободно на {0}: {1} GB (стало больше, потому что файл переехал из Корзины)" -f (Split-Path -Qualifier $repo), (Get-FreeGb $repo))
Write-Host ""
if ($restored -ge 1) {
  Write-Host "Дальше:" -ForegroundColor Cyan
  Write-Host "    scripts\restore_llama.cmd     - вернуть бинарники llama.cpp (или scripts\01_bootstrap.cmd)"
  Write-Host "    scripts\setup_config.ps1      - прописать пути в конфиг"
  Write-Host "    scripts\eval_character.cmd    - тест характера"
} else {
  Write-Host "[FAIL] Ничего не восстановлено." -ForegroundColor Red
  exit 1
}
