@echo off
REM ============================================================
REM  Citlali: zapusk Python-yadra (Core) v dev-rezhime
REM  Pervyy zapusk sozdayot .venv i stavit zavisimosti.
REM ============================================================
setlocal EnableExtensions
cd /d "%~dp0..\core"

if not exist ".venv\Scripts\python.exe" (
  echo [Citlali] venv ne naiden - podgotavlivayu okruzhenie...
  call "%~dp0setup_python.cmd"
  if errorlevel 1 (
    echo [FAIL] okruzhenie ne podgotovleno.
    exit /b 1
  )
)
call ".venv\Scripts\activate.bat"

REM Konfig: %APPDATA%\Citlali\config.toml (sozdayotsya iz core/config.default.toml).
REM V dev-rezhime SOUL.md lezhit v repozitorii, poetomu v konfig pishem ABSOLYUTNYY put'
REM (skript setup_config.ps1). Inache put' reshitsya otnositel'no %%APPDATA%%\Citlali
REM i yadro molcha pereyklyuchitsya na zaglushku haraktera.
set "CITLALI_SOUL=%~dp0..\soul\SOUL.md"
set "CITLALI_DEFAULT_CONFIG=%~dp0..\core\config.default.toml"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup_config.ps1"
if errorlevel 1 (
  echo [FAIL] ne udalos' podgotovit' konfig. Prishlite vyvod vyshe.
  exit /b 4
)

set "CITLALI_LOG_LEVEL=%CITLALI_LOG_LEVEL%"
if "%CITLALI_LOG_LEVEL%"=="" set "CITLALI_LOG_LEVEL=INFO"

echo [Citlali] Core: http://127.0.0.1:8787  (healthz: /healthz)
echo.
python -m app.main

endlocal
