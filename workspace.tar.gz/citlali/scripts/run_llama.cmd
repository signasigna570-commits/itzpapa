@echo off
REM ============================================================
REM  Citlali: zapusk llama-server v dev-rezhime
REM  Isp.: scripts\run_llama.cmd [put_k_modeli.gguf] [kontekst]
REM  Bez argumentov put' opredelyaet scripts\resolve_model.ps1:
REM    CITLALI_MODEL -> model_file iz config.toml ->
REM    krupneyshiy GGUF v CITLALI_MODELS_DIR ili models\.
REM
REM  Pochemu otdel'nyy .ps1, a ne powershell -Command vnutri .cmd (A-26):
REM  vlozhennye kavychki i ")" v stroke s PowerShell lomayut razbor
REM  bloka "if ( ... )" - operator poluchal
REM  "... was unexpected at this time" na pustoy komande.
REM ============================================================
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0.."

set "LLAMA_DIR=tools\llama"
set "MODEL=%~1"
set "CTX=%~2"
if "%CTX%"=="" set "CTX=8192"

if not defined MODEL for /f "delims=" %%m in ('powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0resolve_model.ps1"') do set "MODEL=%%m"

if not defined MODEL (
  echo [FAIL] Ne opredelen put' k modeli.
  echo        Skachat': scripts\download_models.cmd
  echo        Vybrat':  scripts\pick_model.cmd qwen3.5-9b
  exit /b 2
)
REM otnositel'nyy put' ot kornya repo -> absolyutnyy
if not exist "!MODEL!" if exist "%CD%\!MODEL!" set "MODEL=%CD%\!MODEL!"
if not exist "!MODEL!" (
  echo [FAIL] Fayl modeli ne naiden: !MODEL!
  echo        Modeli zhit' vne proekta: setx CITLALI_MODELS_DIR C:\citlali-models
  exit /b 2
)
if not exist "%LLAMA_DIR%\llama-server.exe" (
  echo [FAIL] %LLAMA_DIR%\llama-server.exe ne naiden. Snachala scripts\01_bootstrap.cmd
  exit /b 2
)

echo [Citlali] llama-server
echo   model'  : !MODEL!
echo   kontekst: !CTX!
echo   adres   : http://127.0.0.1:8080  ^(health: /health^)
echo   ostanovka: Ctrl+C
echo.

"%CD%\%LLAMA_DIR%\llama-server.exe" -m "!MODEL!" --host 127.0.0.1 --port 8080 -ngl 99 -c !CTX! -fa 1 -np 2 --cache-reuse 256 --jinja --reasoning off --reasoning-budget 0

endlocal
