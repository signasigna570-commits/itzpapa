@echo off
REM ============================================================
REM  Citlali: unit-testy yadra (TDD-vorota). Krasnye = ne kommitim.
REM  Sam sozdayet core\.venv, esli ego net (scripts\setup_python.cmd).
REM ============================================================
setlocal EnableExtensions
cd /d "%~dp0..\core"

if not exist ".venv\Scripts\python.exe" (
  echo [Citlali] venv ne naiden - podgotavlivayu okruzhenie...
  call "%~dp0setup_python.cmd"
  if errorlevel 1 (
    echo [FAIL] okruzhenie ne podgotovleno, testy ne zapustit'.
    exit /b 1
  )
)

set "PY=.venv\Scripts\python.exe"

REM A-32: proverka mesta DO pytest. 19.10.2026 polnyy disk C: dal operatoru
REM desyatki F/E i OSError 28 v konce - vypadet odna ponyatnaya stroka.
echo.
echo === svobodnoe mesto na diske ===
"%PY%" "%~dp0disk_preflight.py"
if errorlevel 1 (
  echo [FAIL] Testam nekuda pisat: snachala vernite mesto, potom povtorite progon.
  echo Komandy lecheniya napechatany vyshe - kopiruyte ikh po odnoy stroke.
  exit /b 3
)

echo.
echo === pytest ===
REM A-28: bez '-q' zdes' - on uzhe v addopts pyproject.toml. Dvoinoy -q pryachet
REM stroku "N passed", i operatoru nechego sverit' s ozhidaemym chislom testov.
"%PY%" -m pytest
set "RC_TEST=%errorlevel%"

echo.
echo === ruff (lint): app + tests + scripts ===
"%PY%" -m ruff check app tests ../scripts --output-format=concise
set "RC_LINT=%errorlevel%"

echo.
echo === ruff format --check ===
"%PY%" -m ruff format --check app tests ../scripts
set "RC_FMT=%errorlevel%"

echo.
echo Itog: pytest=%RC_TEST% lint=%RC_LINT% format=%RC_FMT%
if "%RC_TEST%"=="0" if "%RC_LINT%"=="0" if "%RC_FMT%"=="0" (
  echo [OK] Vse zelenoe - mozhno kommitit'.
  exit /b 0
)
echo [FAIL] Est' padeniya. Prishlite mne ves' vyvod vyshe tselikom.
if not "%RC_TEST%"=="0" exit /b %RC_TEST%
if not "%RC_LINT%"=="0" exit /b %RC_LINT%
exit /b %RC_FMT%
