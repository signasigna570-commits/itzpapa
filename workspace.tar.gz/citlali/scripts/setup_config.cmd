@echo off
REM ============================================================
REM  Citlali: sozdat'/pochinit' config.toml (obertka dlya setup_config.ps1)
REM
REM  Isp.:  scripts\setup_config.cmd
REM         scripts\setup_config.cmd -Force
REM
REM  Zachem obertka: iz cmd fayl .ps1 ne zapuskaetsya - Windows otkryvaet
REM  ego v bloknote. Vse komandy lecheniya, kotorye pechataet doctor.cmd,
REM  obyazany vypolnyat'sya v tom zhe okne, gde ikh pokazali (A-28).
REM  Tolko ASCII: kirillitsa v .cmd lomayet kodovuyu stranitsu konsoli.
REM ============================================================
setlocal
cd /d "%~dp0.."

REM Proverka, chto konfiguratsiya popadyot v vernyy katalog.
if not defined APPDATA (
  echo [FAIL] APPDATA ne opredelena - ne ponyatno, kuda klast' config.toml.
  echo        Zapustite iz obychnogo okna cmd, ne iz-sluzhebnoy sredy.
  endlocal & exit /b 2
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup_config.ps1" %*
set RC=%errorlevel%
echo.
if "%RC%"=="0" (
  echo [OK] config.toml gotov: %APPDATA%\Citlali\config.toml
) else (
  echo [FAIL] setup_config.ps1 vernul %RC%. Skopiruyte ves' vyvod vyshe i prishlite mne.
)
echo Kod vozvrata: %RC%
endlocal & exit /b %RC%
