﻿<#
.SYNOPSIS
  Citlali: подготовить %APPDATA%\Citlali\config.toml (создать, долить недостающие
  ключи, прописать абсолютные пути к SOUL.md и модели, проверить результат).

.DESCRIPTION
  Почему это отдельный скрипт, а не строчка внутри .cmd:
  правка TOML из cmd требует трёх уровней экранирования кавычек и обратных
  слэшей — там неизбежно ломается. Здесь замена построчная, без regex-подстановки.

  Три дефекта, которые этот скрипт обязан исключать (A-17):
  1. soul_file обязан быть АБСОЛЮТНЫМ путём. При относительном он разрешится
     от %APPDATA%\Citlali, и ядро потеряет характер.
  2. Файл пишется UTF-8 БЕЗ BOM: tomllib отказывается читать TOML с BOM.
  3. Если в существующем конфиге нет нужного ключа (конфиг создан старой
     версией шаблона), ключ ДОБАВЛЯЕТСЯ в свою секцию, а не игнорируется.
     Именно так оператор получил soul=FALLBACK при «успешном» прогоне скрипта.

.PARAMETER Force
  Пересоздать config.toml из core\config.default.toml. Старый файл сохраняется
  рядом как config.toml.bak-<метка времени>.

.INPUTS
  Переменные окружения (их выставляют run_core.cmd / 01_bootstrap.ps1):
    CITLALI_SOUL            путь к soul\SOUL.md
    CITLALI_DEFAULT_CONFIG  путь к core\config.default.toml
    CITLALI_MODEL           (необязательно) путь к .gguf
    CITLALI_MODELS_DIR      (необязательно) каталог моделей вне проекта (A-26)

.EXAMPLE
  powershell -NoProfile -ExecutionPolicy Bypass -File scripts\setup_config.ps1
  powershell -NoProfile -ExecutionPolicy Bypass -File scripts\setup_config.ps1 -Force
#>

[CmdletBinding()]
param(
  [switch]$Force
)

$ErrorActionPreference = "Stop"

$repoRoot = Split-Path -Parent $PSScriptRoot
$appDir = Join-Path $env:APPDATA "Citlali"
$cfgPath = Join-Path $appDir "config.toml"

# ------------------------------------------------------------------ источники
$template = $env:CITLALI_DEFAULT_CONFIG
if (-not $template) { $template = Join-Path $repoRoot "core\config.default.toml" }
if (-not (Test-Path -LiteralPath $template)) {
  Write-Host "[FAIL] Не найден шаблон конфига: $template" -ForegroundColor Red
  exit 1
}

$soul = $env:CITLALI_SOUL
if (-not $soul) { $soul = Join-Path $repoRoot "soul\SOUL.md" }
if (-not (Test-Path -LiteralPath $soul)) {
  Write-Host "[FAIL] Не найден SOUL.md: $soul" -ForegroundColor Red
  Write-Host "       Без него ядро не стартует (A-17): характер - не опция."
  exit 1
}
$soul = (Resolve-Path -LiteralPath $soul).Path

New-Item -ItemType Directory -Force -Path $appDir | Out-Null

# --------------------------------------------------------- создать/пересоздать
$created = $false
if ($Force -or -not (Test-Path -LiteralPath $cfgPath)) {
  if ((Test-Path -LiteralPath $cfgPath) -and $Force) {
    $bak = "$cfgPath.bak-" + (Get-Date -Format "yyyyMMdd-HHmmss")
    Copy-Item -LiteralPath $cfgPath -Destination $bak -Force
    Write-Host "[Citlali] старый конфиг сохранён: $bak" -ForegroundColor Yellow
  }
  Copy-Item -LiteralPath $template -Destination $cfgPath -Force
  $created = $true
}

# ------------------------------------------------------------------ функции
function Read-Lines([string]$Path) {
  return @([System.IO.File]::ReadAllText($Path) -split "\r?\n")
}

function Get-TomlValue {
  param([string[]]$Lines, [string]$Key)
  foreach ($line in $Lines) {
    $t = $line.TrimStart()
    if ($t.StartsWith("#")) { continue }
    if (-not $t.StartsWith($Key)) { continue }
    $rest = $t.Substring($Key.Length).TrimStart()
    if (-not $rest.StartsWith("=")) { continue }
    $raw = $rest.Substring(1).Trim().Trim('"')
    return $raw.Replace("\\", "\")   # TOML basic string: '\\' -> '\'
  }
  return $null
}

function Set-TomlString {
  param([string[]]$Lines, [string]$Key, [string]$Value)

  # Путь пишем ПРЯМЫМИ слэшами (C:/dev/citlali/soul/SOUL.md). Тогда в TOML не
  # нужно экранирование вовсе: ни "\\", ни случайных "\0"/"\n" внутри пути.
  # Python-ядро приводит '/' к '\' на Windows (app/config.py: expand_path),
  # а скрипты, читающие конфиг сырым текстом, получают готовый валидный путь.
  # Никакой regex-подстановки: в PowerShell "\s" внутри двойных кавычек теряет
  # слэш (backtick-escape), и паттерн молча перестаёт совпадать (A-17, пункт 2).
  $entry = $Key + ' = "' + $Value.Replace("\", "/") + '"'
  $found = $false
  $out = New-Object System.Collections.Generic.List[string]
  foreach ($line in $Lines) {
    $t = $line.TrimStart()
    if (-not $found -and -not $t.StartsWith("#") -and $t.StartsWith($Key)) {
      $rest = $t.Substring($Key.Length).TrimStart()
      if ($rest.StartsWith("=")) {
        $out.Add($entry)
        $found = $true
        continue
      }
    }
    $out.Add($line)
  }

  if (-not $found) {
    # Ключа нет (конфиг от старого шаблона) — добавляем в конец его секции.
    # Раньше мы здесь просто предупреждали, и оператор получал soul=FALLBACK
    # при зелёном выводе скрипта. Так быть не должно.
    $section = ""
    foreach ($kv in $Defaults) {
      if ($kv.ContainsKey($Key)) { $section = $kv.Section; break }
    }
    $insertAt = -1
    if ($section) {
      $inSection = $false
      for ($i = 0; $i -lt $out.Count; $i++) {
        $t = $out[$i].TrimStart()
        if ($t -eq "[$section]") { $inSection = $true; $insertAt = $i + 1; continue }
        if ($inSection -and $t.StartsWith("[") -and $t.EndsWith("]")) { break }
        if ($inSection -and $t -ne "") { $insertAt = $i + 1 }
      }
    }
    if ($insertAt -lt 0) {
      $out.Add("")
      $out.Add("# ключ добавлен скриптом setup_config.ps1 (его не было в старом конфиге)")
      $out.Add($entry)
      Write-Host "[Citlali] ключ '$Key' добавлен в конец файла (секция [$section] не найдена)" -ForegroundColor Yellow
    } else {
      $out.Insert($insertAt, $entry)
      Write-Host "[Citlali] ключ '$Key' добавлен в секцию [$section]" -ForegroundColor Yellow
    }
  }
  return $out.ToArray()
}

# какие ключи в каких секциях живут (чтобы добавлять недостающее в правильное место)
$Defaults = @(
  @{ Section = "paths"; Key = "data_dir" },
  @{ Section = "paths"; Key = "soul_file" },
  @{ Section = "paths"; Key = "db_file" },
  @{ Section = "paths"; Key = "log_dir" },
  @{ Section = "paths"; Key = "model_file" },
  @{ Section = "paths"; Key = "llama_dir" },
  @{ Section = "core"; Key = "host" },
  @{ Section = "core"; Key = "port" },
  @{ Section = "core"; Key = "log_level" },
  @{ Section = "llama"; Key = "base_url" },
  @{ Section = "llama"; Key = "ctx_size" }
)

# --------------------------------------------- sanitizatsiya data_dir (A-20)
# Esli v konfige data_dir ukazan putём druoy OS (~/.local/share/... ili /tmp/...),
# yadro sozdast bazu ne v %APPDATA%. Ubirayem klyuch sovsém: pust' vozmet
# znachenie po umolchaniyu dlya etoy OS.
$cleaned = New-Object System.Collections.Generic.List[string]
$dropped = $false
foreach ($line in $lines) {
  $t = $line.TrimStart()
  if ($t.StartsWith("data_dir")) {
    $rest = $t.Substring("data_dir".Length).TrimStart()
    if ($rest.StartsWith("=")) {
      $val = $rest.Substring(1).Trim().Trim('"')
      if ($val -like "~*" -or $val -like "/*") {
        Write-Host "[Citlali] data_dir = '$val' - eto put' ne dlya Windows, klyuch ubran (A-20)" -ForegroundColor Yellow
        $dropped = $true
        continue
      }
    }
  }
  $cleaned.Add($line)
}
if ($dropped) { $lines = $cleaned.ToArray() }

# ------------------------------------------------------------- dolit' klyuchi
$lines = Read-Lines $cfgPath

# ключи шаблона, которых нет в существующем конфиге, — добираем из шаблона
$tplLines = Read-Lines $template
foreach ($kv in $Defaults) {
  if ($null -eq (Get-TomlValue -Lines $lines -Key $kv.Key)) {
    $tplValue = Get-TomlValue -Lines $tplLines -Key $kv.Key
    if ($null -ne $tplValue) {
      $lines = Set-TomlString -Lines $lines -Key $kv.Key -Value $tplValue
    }
  }
}

# -------------------------------------------------- проставить наши значения
$lines = Set-TomlString -Lines $lines -Key "soul_file" -Value $soul

$model = $env:CITLALI_MODEL
if (-not $model) {
  # УВАЖАЕМ УЖЕ СДЕЛАННЫЙ ВЫБОР (pick_model.cmd). Раньше скрипт при каждом
  # запуске перезаписывал model_file крупнейшим GGUF — и выбор оператора
  # silently терялся после любого download_models.cmd. Теперь: если текущий
  # model_file указывает на существующий файл — не трогаем.
  $current = Get-TomlValue -Lines $lines -Key "model_file"
  if ($current) {
    $curPath = $current.Replace("/", "\")
    if (-not [System.IO.Path]::IsPathRooted($curPath)) { $curPath = Join-Path $repoRoot $curPath }
    if (Test-Path -LiteralPath $curPath) {
      $model = $curPath
      Write-Host "[Citlali] model_file сохранён прежний выбор: $(Split-Path $curPath -Leaf)"
    }
  }
}
if ($model) {
  if (Test-Path -LiteralPath $model) { $model = (Resolve-Path -LiteralPath $model).Path }
  $lines = Set-TomlString -Lines $lines -Key "model_file" -Value $model
} else {
  # выбора нет — берём крупнейший GGUF: сначала из CITLALI_MODELS_DIR (модели
  # живут вне папки проекта, A-26), затем из models\ как разумный дефолт
  $modelsDirs = New-Object System.Collections.Generic.List[string]
  if ($env:CITLALI_MODELS_DIR) { $modelsDirs.Add($env:CITLALI_MODELS_DIR) }
  $modelsDirs.Add((Join-Path $repoRoot "models"))
  foreach ($modelsDir in $modelsDirs) {
    if (-not (Test-Path -LiteralPath $modelsDir)) { continue }
    $gguf = Get-ChildItem -LiteralPath $modelsDir -Filter *.gguf -ErrorAction SilentlyContinue |
      Sort-Object Length -Descending | Select-Object -First 1
    if ($gguf) {
      $lines = Set-TomlString -Lines $lines -Key "model_file" -Value $gguf.FullName
      Write-Host "[Citlali] model_file: взят крупнейший GGUF из $modelsDir -> $($gguf.Name)"
      break
    }
  }
}

$content = ($lines -join "`r`n")

# UTF-8 без BOM — критично для tomllib
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($cfgPath, $content, $utf8NoBom)

if ($created) { Write-Host "[Citlali] создан конфиг: $cfgPath" }
else { Write-Host "[Citlali] конфиг обновлён: $cfgPath" }

# ------------------------------------------------------------------ проверка
# Не верим себе на слово: читаем файл обратно (A-17).
$bytes = [System.IO.File]::ReadAllBytes($cfgPath)
if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
  Write-Host "[FAIL] В конфиге оказался BOM - Python его не прочитает." -ForegroundColor Red
  exit 1
}

$check = Read-Lines $cfgPath
$fail = $false

$soulExpected = $soul.Replace("\", "/")
$soulInFile = Get-TomlValue -Lines $check -Key "soul_file"
Write-Host "[Citlali] проверка soul_file  = $soulInFile"
if ($soulInFile -ne $soulExpected) {
  Write-Host "[FAIL] soul_file не совпадает с ожидаемым: $soulExpected" -ForegroundColor Red
  $fail = $true
} elseif (-not ($soulInFile -match "^[A-Za-z]:" -or $soulInFile.StartsWith("/"))) {
  Write-Host "[FAIL] soul_file не абсолютный - ядро разрешит его от %APPDATA% и потеряет характер." -ForegroundColor Red
  $fail = $true
} elseif (-not (Test-Path -LiteralPath $soulInFile)) {
  Write-Host "[FAIL] soul_file указывает на несуществующий файл." -ForegroundColor Red
  $fail = $true
}

$modelInFile = Get-TomlValue -Lines $check -Key "model_file"
Write-Host "[Citlali] проверка model_file = $modelInFile"
if (-not $modelInFile) {
  Write-Host "[WARN] model_file пуст - укажите путь к GGUF в настройках или в конфиге." -ForegroundColor Yellow
} elseif (-not (Test-Path -LiteralPath $modelInFile)) {
  Write-Host "[WARN] model_file указывает на несуществующий файл: скачайте модель (scripts\01_bootstrap.cmd)." -ForegroundColor Yellow
}

if ($fail) {
  Write-Host ""
  Write-Host "[FAIL] Конфиг не прошёл самопроверку. Ядро запускать нельзя." -ForegroundColor Red
  Write-Host "       Лечение: powershell -NoProfile -ExecutionPolicy Bypass -File scripts\setup_config.ps1 -Force"
  exit 1
}

Write-Host "[OK] конфиг готов: soul_file абсолютный, BOM отсутствует"
exit 0
