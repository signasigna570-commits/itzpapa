@echo off
REM ============================================================
REM  Citlali: podgotovka Python-okruzheniya yadra (core\.venv)
REM
REM  Pochemu otdel'nyy skript: ran'she run_tests.cmd zavisel ot
REM  "snachala zapustite run_core.cmd", i padal s "No module named pytest".
REM  Teper' venv sozdayotsya zdes', a run_core/run_tests ego ispol'zuyut.
REM
REM  Versiya Python: 3.11 ili 3.12 (provereno). Ishchem v poryadke:
REM    py -3.11 -> py -3.12 -> python (esli >= 3.11)
REM ============================================================
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0..\core"

if exist ".venv\Scripts\python.exe" (
  echo [OK] venv uzhe sozdan: %CD%\.venv
  ".venv\Scripts\python.exe" -c "import sys;print('     Python', sys.version.split()[0], sys.executable)"
  goto :DEPS
)

set "PYCMD="
py -3.11 -c "import sys" >nul 2>nul && set "PYCMD=py -3.11"
if not defined PYCMD py -3.12 -c "import sys" >nul 2>nul && set "PYCMD=py -3.12"
if not defined PYCMD (
  for /f "tokens=2 delims= " %%v in ('python -c "import sys;print(sys.version.split()[0])" 2^>nul') do set "SYSVER=%%v"
  if defined SYSVER (
    for /f "tokens=1,2 delims=." %%a in ("!SYSVER!") do (
      if %%a GEQ 3 if %%b GEQ 11 set "PYCMD=python"
    )
  )
)

if not defined PYCMD (
  echo [FAIL] Ne naiden Python 3.11 ili 3.12 ^(64-bit^).
  echo        Ustavovite: https://www.python.org/downloads/release/python-3119/
  echo        Pri ustanovke OBYAZATEL'NO otmet'te "Add python.exe to PATH".
  echo        Posle ustanovki otkroyte NOVOE okno cmd i povtorite.
  exit /b 2
)

echo [Citlali] sozdayu venv s pomoshch'yu: %PYCMD%
%PYCMD% -c "import sys;print('     Python', sys.version.split()[0], '| bits:', 64 if sys.maxsize>2**32 else 32)"
%PYCMD% -m venv .venv
if errorlevel 1 (
  echo [FAIL] ne udalos' sozdat' venv. Prishlite vyvod vyshe.
  exit /b 3
)

:DEPS
echo [Citlali] stavlyu zavisimosti ^(requirements-dev.txt^)
".venv\Scripts\python.exe" -m pip install --upgrade pip --quiet
if errorlevel 1 (
  echo [WARN] pip upgrade ne proshel - prodolzhayu
)
".venv\Scripts\python.exe" -m pip install -r requirements-dev.txt
if errorlevel 1 (
  echo [FAIL] ustanovka zavisimostey ne udalas'.
  echo        Esli net seti: skachayte wheel'y na drugoy mashine i stav'te offline.
  echo        Prishlite poslednie 20 strok vyvoda.
  exit /b 4
)

echo.
echo [OK] okruzhenie gotovo: %CD%\.venv
".venv\Scripts\python.exe" -c "import fastapi,pydantic,httpx,aiosqlite,pytest;print('     fastapi',fastapi.__version__,'| pydantic',pydantic.VERSION,'| httpx',httpx.__version__)"
echo.
echo Dalee: scripts\run_tests.cmd
endlocal
exit /b 0
