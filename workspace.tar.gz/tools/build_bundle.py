#!/usr/bin/env python3
"""Сборка артефактов обновления для оператора: git-bundle + zip.

Файл служебный, живёт ВНЕ репозитория citlali (в проект его не кладём).
Запуск:  python3 tools/build_bundle.py --out <путь>.bundle --zip <путь>.zip
"""
from __future__ import annotations

import argparse
import subprocess
import sys
import zipfile
from pathlib import Path

REPO_DEFAULT = str(Path.home() / "citlali")

EXCLUDE_DIRS = {
    ".git", ".venv", "node_modules", "__pycache__", ".pytest_cache",
    ".ruff_cache", ".arena", "build", "dist", "target", ".bench",
    ".compare", ".eval",
}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=REPO_DEFAULT)
    ap.add_argument("--out", required=True)
    ap.add_argument("--zip", required=True)
    args = ap.parse_args()
    repo = Path(args.repo)

    subprocess.run(["git", "bundle", "create", args.out, "HEAD", "main"], cwd=repo, check=True)
    subprocess.run(["git", "bundle", "verify", args.out], cwd=repo, check=True)

    head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=repo, capture_output=True, text=True, check=True
    ).stdout.strip()[:7]

    with zipfile.ZipFile(args.zip, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(repo.rglob("*")):
            if not p.is_file():
                continue
            rel = p.relative_to(repo)
            if any(part in EXCLUDE_DIRS for part in rel.parts):
                continue
            z.write(p, Path("citlali") / rel)

    print(f"rev={head} bundle={Path(args.out).stat().st_size} zip={Path(args.zip).stat().st_size}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
